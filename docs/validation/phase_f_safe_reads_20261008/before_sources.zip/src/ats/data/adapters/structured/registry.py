"""Controlled runtime registry for configured structured source adapters."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from ...catalog.structured import StructuredCatalog
from ...core.structured_models import CatalogStatus, FetchRequest


@dataclass(frozen=True)
class RuntimeSourceSpec:
    adapter_key: str
    factory: Callable[[], object] | None
    requires_entities: bool = False
    ingest_supported: bool = True
    discovery_group: str = ""
    note: str = ""


def _tw_mof():
    from ...sources.tw_mof import TaiwanMOFAdapter

    return TaiwanMOFAdapter()


def _kr_ecos():
    from ...sources.kr_ecos import KoreaECOSAdapter

    return KoreaECOSAdapter()


def _sec_companyfacts():
    from ...sources.company_financials import SECCompanyFactsAdapter

    return SECCompanyFactsAdapter()


def _company_disclosures():
    from ...sources.company_financials import CompanyDisclosuresAdapter

    return CompanyDisclosuresAdapter()


def _defeatbeta():
    from ...sources.company_financials import DefeatBetaStatementAdapter

    return DefeatBetaStatementAdapter()


def _yfinance_financials():
    from ...sources.company_financials import YFinanceFinancialStatementsAdapter

    return YFinanceFinancialStatementsAdapter()


def _consensus():
    from ...sources.market_consensus import YFinanceConsensusAdapter

    return YFinanceConsensusAdapter()


def _sacra_frontier_labs_revenue():
    from ...sources.frontier_ai_labs_revenue import SacraPublicCompanyProfilesAdapter

    return SacraPublicCompanyProfilesAdapter()


def _tickertrends_frontier_labs_revenue():
    from ...sources.frontier_ai_labs_revenue import TickerTrendsPublicResearchAdapter

    return TickerTrendsPublicResearchAdapter()


def _trendforce():
    from ...sources.trendforce import TrendForceDRAMAdapter

    return TrendForceDRAMAdapter()


def _factset_earnings_insight():
    from ...sources.factset_earnings_insight import FactSetEarningsInsightAdapter

    return FactSetEarningsInsightAdapter()


def _anthropic_economic_index():
    import os
    from pathlib import Path

    from ...sources.anthropic_economic_index import AnthropicEconomicIndexAdapter

    overrides = {}
    for environment_name, filename in (
        ("ATS_AEI_CLAUDE_AI_FILE", "aei_claude_ai_2026-06-26.csv"),
        ("ATS_AEI_1P_API_FILE", "aei_1p_api_2026-06-26.csv"),
    ):
        if value := os.environ.get(environment_name):
            overrides[filename] = Path(value)
    return AnthropicEconomicIndexAdapter(local_file_overrides=overrides)


def _census_btos():
    from ...sources.census_btos import CensusBTOSAdapter
    return CensusBTOSAdapter()


def _rps_genai_adoption():
    from ...sources.rps_genai_adoption import RPSGenAIAdoptionAdapter
    return RPSGenAIAdoptionAdapter()


def _ramp_ai_index():
    import os

    from ...sources.ramp_ai_index import RampAIIndexAdapter

    # Optional headless ingress populated by the desktop browser runner.  No
    # API key or network fallback is activated; absent files still fail closed.
    export_dir = os.environ.get("ATS_RAMP_OFFICIAL_EXPORT_DIR", "")
    if not export_dir:
        from ....config import REPO_ROOT
        export_dir = str(REPO_ROOT / "var" / "data" / "ramp_exports")
    return RampAIIndexAdapter(export_dir=export_dir)


def _openrouter_rankings():
    from ...sources.openrouter_rankings import OpenRouterRankingsAdapter

    return OpenRouterRankingsAdapter()


def _frontier_ai_capability():
    from ...sources.frontier_ai_capability import PublicBenchmarkAdapter

    return PublicBenchmarkAdapter()


def _frontier_ai_capability_official_lab():
    from ...sources.frontier_ai_capability import OfficialLabReleaseAdapter

    return OfficialLabReleaseAdapter()


_RUNTIMES: dict[str, RuntimeSourceSpec] = {
    "tw_mof": RuntimeSourceSpec("tw_mof", _tw_mof),
    "kr_ecos": RuntimeSourceSpec("kr_ecos", _kr_ecos),
    "sec_companyfacts": RuntimeSourceSpec(
        "sec_companyfacts", _sec_companyfacts, requires_entities=True),
    "company_disclosures": RuntimeSourceSpec(
        "company_disclosures", _company_disclosures, requires_entities=True),
    "defeatbeta_stock_statement": RuntimeSourceSpec(
        "defeatbeta_stock_statement", _defeatbeta, requires_entities=True),
    "yfinance_financials": RuntimeSourceSpec(
        "yfinance_financials", _yfinance_financials, requires_entities=True),
    "consensus": RuntimeSourceSpec("consensus", _consensus, requires_entities=True),
    "trendforce": RuntimeSourceSpec("trendforce", _trendforce),
    "factset_earnings_insight": RuntimeSourceSpec(
        "factset_earnings_insight", _factset_earnings_insight),
    "anthropic_economic_index": RuntimeSourceSpec(
        "anthropic_economic_index", _anthropic_economic_index, discovery_group="ai_adoption"),
    "census_btos": RuntimeSourceSpec("census_btos", _census_btos, discovery_group="ai_adoption"),
    "rps_genai_adoption": RuntimeSourceSpec("rps_genai_adoption", _rps_genai_adoption, discovery_group="ai_adoption"),
    "ramp_ai_index": RuntimeSourceSpec("ramp_ai_index", _ramp_ai_index,
                                       discovery_group="ai_adoption"),
    "openrouter_rankings": RuntimeSourceSpec(
        "openrouter_rankings", _openrouter_rankings,
        discovery_group="ai_commercialization"),
    "frontier_ai_capability": RuntimeSourceSpec(
        "frontier_ai_capability", _frontier_ai_capability,
        discovery_group="frontier_ai_capability"),
    "frontier_ai_capability_official_lab": RuntimeSourceSpec(
        "frontier_ai_capability_official_lab", _frontier_ai_capability_official_lab,
        discovery_group="frontier_ai_capability"),
    # Periodic discovery over two registered Sacra public pages.  TickerTrends is
    # a frozen one-time 2026H1 seed and is intentionally left out of every
    # discovery group so it can never re-baseline the main sequence.
    "sacra_frontier_labs_revenue": RuntimeSourceSpec(
        "sacra_frontier_labs_revenue", _sacra_frontier_labs_revenue,
        discovery_group="frontier_ai_labs_revenue"),
    "tickertrends_frontier_labs_revenue": RuntimeSourceSpec(
        "tickertrends_frontier_labs_revenue", _tickertrends_frontier_labs_revenue),
    "document_numeric_evidence": RuntimeSourceSpec(
        "document_numeric_evidence", None, ingest_supported=False,
        note="Evidence candidates enter through EvidenceWorkbench review, not remote fetch."),
}


def register_runtime(spec: RuntimeSourceSpec) -> None:
    """Register a controlled adapter factory (primarily for extensions and tests)."""
    _RUNTIMES[spec.adapter_key] = spec


def runtime_spec(source_id: str, *, catalog: StructuredCatalog | None = None) -> RuntimeSourceSpec | None:
    catalog = catalog or StructuredCatalog.load()
    row = (catalog.raw.get("sources", {}) or {}).get(source_id) or {}
    return _RUNTIMES.get(str(row.get("adapter", "")))


def validate_source_registration(source_id: str, *,
                                 catalog: StructuredCatalog | None = None) -> dict:
    """Validate the configuration/runtime/quality contract without network access."""
    catalog = catalog or StructuredCatalog.load()
    source_rows = catalog.raw.get("sources", {}) or {}
    dataset_rows = catalog.raw.get("datasets", {}) or {}
    row = source_rows.get(source_id)
    checks: list[dict] = []

    def check(name: str, passed: bool, reason: str = "") -> None:
        checks.append({"check": name, "passed": bool(passed),
                       "reason": "" if passed else reason})

    # A retired source id is checked *before* the active registry, otherwise it
    # would report `source_not_configured` and hide the real reason.  This is the
    # single fail-closed point shared by `ats data validate-source` and the
    # ReleaseManager publication gate, so neither can be bypassed by re-adding
    # the id to `sources` alone.
    tombstone = catalog.retired_source(source_id)
    if tombstone is not None:
        check("source_retired", False, "source_retired")
        return {"source_id": source_id, "valid": False, "checks": checks,
                "reason_codes": ["source_retired"],
                "retired_at": tombstone.retired_at.isoformat(),
                "reason": tombstone.reason,
                "disposition": tombstone.disposition.value,
                "successor": tombstone.successor}

    check("source_configured", row is not None, "source_not_configured")
    if row is None:
        return {"source_id": source_id, "valid": False, "checks": checks,
                "reason_codes": ["source_not_configured"]}

    runtime_excluded = row.get("catalog_status") == CatalogStatus.RUNTIME_EXCLUDED.value
    check("persistent_boundary", not runtime_excluded, "runtime_source_excluded")
    if runtime_excluded:
        return {"source_id": source_id, "adapter_key": str(row.get("adapter", "")),
                "datasets": [], "valid": False, "checks": checks,
                "reason_codes": ["runtime_source_excluded"]}
    implemented = row.get("catalog_status") not in {
        CatalogStatus.PLANNED.value, CatalogStatus.DEFERRED.value}
    check("implementation_status", implemented, "source_not_implemented")
    datasets = list(row.get("datasets") or [])
    check("datasets_declared", bool(datasets), "source_has_no_datasets")
    for dataset_id in datasets:
        dataset = dataset_rows.get(dataset_id)
        check(f"dataset:{dataset_id}:exists", dataset is not None,
              "dataset_not_configured")
        if dataset is None:
            continue
        references = [*(dataset.get("primary_sources") or []),
                      *(dataset.get("fallback_sources") or [])]
        check(f"dataset:{dataset_id}:references_source", source_id in references,
              "dataset_does_not_reference_source")
        check(f"dataset:{dataset_id}:quality", bool(dataset.get("quality")),
              "quality_thresholds_missing")
        check(f"dataset:{dataset_id}:acceptance_samples",
              bool(dataset.get("acceptance_samples") or dataset.get("entities")),
              "acceptance_samples_missing")

    budget = row.get("internal_request_budget") or {}
    check("request_budget", bool(budget), "request_budget_missing")
    adapter_key = str(row.get("adapter", ""))
    spec = _RUNTIMES.get(adapter_key)
    check("runtime_registered", spec is not None, "adapter_runtime_unregistered")
    if spec is not None:
        check("unified_ingestion_supported", spec.ingest_supported,
              "adapter_not_supported_by_unified_ingestion")
        if spec.ingest_supported:
            try:
                adapter = spec.factory() if spec.factory else None
            except Exception as exc:  # factory/config dependency failure
                check("adapter_constructible", False,
                      f"adapter_factory_failed:{type(exc).__name__}:{exc}")
            else:
                check("adapter_constructible", adapter is not None,
                      "adapter_factory_returned_none")
    reasons = [item["reason"] for item in checks if not item["passed"]]
    return {"source_id": source_id, "adapter_key": adapter_key,
            "datasets": datasets, "valid": not reasons, "checks": checks,
            "reason_codes": reasons}


def build_ingestion(source_id: str, *, entities: list[str] | None = None,
                    periods: list[str] | None = None,
                    query_scope: dict | None = None,
                    catalog: StructuredCatalog | None = None) -> tuple[object, FetchRequest]:
    catalog = catalog or StructuredCatalog.load()
    validation = validate_source_registration(source_id, catalog=catalog)
    if not validation["valid"]:
        raise ValueError(
            f"source {source_id} is not runnable: {', '.join(validation['reason_codes'])}")
    source = next(item for item in catalog.sources() if item.id == source_id)
    spec = runtime_spec(source_id, catalog=catalog)
    assert spec is not None and spec.factory is not None
    normalized_entities = [item.upper() for item in (entities or []) if item]
    if spec.requires_entities and not normalized_entities:
        raise ValueError(f"source {source_id} requires at least one --entity")
    requested_dataset = str((query_scope or {}).get("dataset_id", "")).strip()
    if requested_dataset:
        if requested_dataset not in source.datasets:
            raise ValueError(f"source {source_id} does not declare dataset {requested_dataset}")
        dataset_id = requested_dataset
    elif len(source.datasets) == 1:
        dataset_id = source.datasets[0]
    else:
        # Multi-dataset providers are run as independent jobs.  Keep a stable
        # default for release-check discovery while allowing callers to select
        # the spend slice explicitly through query_scope.dataset_id.
        dataset_id = source.datasets[0]
    return spec.factory(), FetchRequest(
        source_id=source_id, dataset_id=dataset_id,
        entities=normalized_entities, periods=periods or [],
        query_scope=query_scope or {})


def ingest_source(repository, source_id: str, *, entities: list[str] | None = None,
                  periods: list[str] | None = None, query_scope: dict | None = None,
                  catalog: StructuredCatalog | None = None, force: bool = False) -> dict:
    """Run one controlled source slice, honoring the source release gate."""
    from ...rollout_modes import source_mode
    from ...pipelines.structured.ingestion import IngestionPipeline

    mode = source_mode(source_id)
    if not force and mode not in {"shadow", "platform", "fallback"}:
        raise PermissionError(
            f"source {source_id} mode is {mode}; publish it or use --force for isolation")
    adapter, request = build_ingestion(
        source_id, entities=entities, periods=periods,
        query_scope=query_scope, catalog=catalog)
    result = IngestionPipeline(repository).run(adapter, request)
    return {**result, "source_id": source_id, "dataset_id": request.dataset_id,
            "source_mode": mode, "forced": force}
