"""Configuration loading.

Two layers:
  * Secrets  -> environment / .env (pydantic-settings BaseSettings)
  * AppConfig -> config/*.yaml (non-secret, version-controlled)

`get_config()` returns a cached merged view. Paths can be overridden via the
ATS_CONFIG_DIR env var (useful in tests).
"""

from __future__ import annotations

import functools
import logging
import os
import re
from pathlib import Path

import yaml
from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict

log = logging.getLogger("ats.config")

from .schemas.market import Ticker

REPO_ROOT = Path(__file__).resolve().parents[2]


def _config_dir() -> Path:
    return Path(os.environ.get("ATS_CONFIG_DIR", REPO_ROOT / "config"))


# --------------------------------------------------------------------------- #
# Secrets (.env / environment)
# --------------------------------------------------------------------------- #
class Secrets(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=os.environ.get("ATS_ENV_FILE", REPO_ROOT / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    anthropic_api_key: str = ""
    openai_api_key: str = ""
    openrouter_api_key: str = ""
    openai_base_url: str = ""
    # DeepSeek's own API, used directly rather than through OpenRouter. Added because
    # identical requests through the relay returned wildly different results — the same
    # document and prompt extracted [0, 33, 36] observations across three runs — and the
    # gateway was the common factor across two different models. Talking to the provider
    # removes one variable from that.
    deepseek_api_key: str = ""
    deepseek_base_url: str = "https://api.deepseek.com"

    fred_api_key: str = ""
    kr_ecos_api_key: str = ""      # 韩国银行 ECOS（可留空，走文档示例 key，每次 10 行）
    finnhub_api_key: str = ""
    fmp_api_key: str = ""          # FinancialModelingPrep — earnings-call transcripts
    tavily_api_key: str = ""
    gmail_address: str = ""            # newsletter inbox (IMAP enabled, 2FA + app password)
    gmail_app_password: str = ""       # https://myaccount.google.com/apppasswords
    gmail_imap_host: str = "imap.gmail.com"
    gmail_proxy: str = ""              # e.g. socks5://127.0.0.1:7897; default: proxy env vars
    sec_edgar_user_agent: str = "ats-bot example@example.com"
    reddit_client_id: str = ""
    reddit_client_secret: str = ""
    reddit_user_agent: str = "ats-bot/0.1"

    ibkr_host: str = "127.0.0.1"
    ibkr_port: int = 7497
    ibkr_client_id: int = 11
    ibkr_account: str = ""

    feishu_app_id: str = ""
    feishu_app_secret: str = ""
    feishu_chat_id: str = ""              # group/user chat that receives approval cards (app mode)
    feishu_verification_token: str = ""   # event callback verification (app mode)
    feishu_base_url: str = "https://open.feishu.cn"  # use open.larksuite.com for Lark
    # Group custom-bot mode (one-way push webhook + URL-button approval):
    feishu_bot_webhook: str = ""          # https://open.feishu.cn/open-apis/bot/v2/hook/<id>
    feishu_bot_secret: str = ""           # optional signing secret if the bot enables 签名校验
    feishu_approve_base: str = ""         # public base URL of `ats serve` (tunnel) for buttons
    feishu_approve_secret: str = ""       # HMAC secret protecting the GET approve links
    discord_bot_token: str = ""


# --------------------------------------------------------------------------- #
# App config (yaml)
# --------------------------------------------------------------------------- #
class LLMRoleConfig(BaseModel):
    provider: str | None = None
    model: str | None = None
    temperature: float | None = None
    max_tokens: int | None = None


class LLMConfig(BaseModel):
    default_provider: str = "anthropic"
    default_model: str = "claude-opus-4-8"
    temperature: float = 0.2
    max_tokens: int = 4096
    timeout_seconds: int = 120
    max_retries: int = 3
    routing: dict[str, LLMRoleConfig] = Field(default_factory=dict)

    def for_role(self, role: str) -> LLMRoleConfig:
        """Merge defaults with any per-role override."""
        override = self.routing.get(role) or LLMRoleConfig()
        return LLMRoleConfig(
            provider=override.provider or self.default_provider,
            model=override.model or self.default_model,
            temperature=override.temperature if override.temperature is not None else self.temperature,
            max_tokens=override.max_tokens or self.max_tokens,
        )


class RiskConfig(BaseModel):
    # L1 标的
    max_position_pct: float = 0.20
    max_sector_pct: float = 0.40          # GICS-sector backstop for non-universe holdings
    stop_loss_pct: float = 0.25           # per-position unrealized loss vs cost -> forced trim
    # L2 组合
    max_gross_leverage: float = 1.0
    max_single_order_usd: float = 25000
    cash_floor_pct: float = 0.05
    # L3 市场/因子
    beta_cap: float = 1.5                 # portfolio weighted beta ceiling
    cluster_corr_threshold: float = 0.7   # pairwise corr to join a cluster
    cluster_weight_cap: float = 0.75      # single correlated cluster ceiling (intentional concentration)
    # L4 亏损/回撤
    max_drawdown_pct: float = 0.15        # peak-to-trough -> de-risk mode
    daily_loss_limit_pct: float = 0.05    # single-day loss -> stop new buys
    # L5 尾部/压测
    max_stress_loss_pct: float = 0.25     # worst scenario loss vs NAV
    stress_market_shocks: list[float] = Field(default_factory=lambda: [-0.10, -0.20])
    ai_bubble_cluster_shock: float = -0.35  # extra shock applied to the top correlated cluster
    # 期权压测 vol 联动：与 stress_market_shocks 一一配对（跌市抬 vol，崩盘更真实）
    stress_vol_shocks: list[float] = Field(default_factory=lambda: [0.20, 0.50])
    ai_bubble_vol_shock: float = 0.80     # extra vol bump on the AI-cluster crash scenario
    # L6 事件
    max_event_loss_pct: float = 0.03      # single earnings gap: weight * expected_move <= this
    # L1 流动性（报告用）
    max_pct_adv: float = 0.10
    # --- 期权风控（BSM/Greeks 量化升级）------------------------------------------
    option_risk_free_rate: float = 0.045  # r for BSM greeks / repricing fallback
    max_margin_util_pct: float = 0.5      # init_margin/net_liq 硬上限（IBKR 权威源时硬阻单）
    min_excess_liquidity_pct: float = 0.10  # excess_liquidity/net_liq 硬下限（保证金垫太薄）
    max_net_vega_pct: float = 0.05        # |净 vega|/net_liq 提示阈（caution，不硬阻单）
    short_option_loss_mult: float = 2.0   # short 期权：亏损/收权利金 ≥ 此值 → caution
    # 现金等价物：symbol -> haircut（0=纯现金信用；1=完全当风险敞口）。美债 ETF/BRK-B 等
    # 按现金信用计入有效现金，不占单票/杠杆/beta/集中度限额。见 risk/assess.py。
    cash_equivalents: dict[str, float] = Field(default_factory=dict)
    # 执行授权网关（Phase B 7.4）：组合快照超过该秒数即视为过期，真实下单被拒绝
    # 并回到风险审查。配置缺键时回落默认 60。
    max_snapshot_age_seconds: float = 60.0


class AccountConfig(BaseModel):
    # Paper book size used for sizing until IBKR provides the live net liquidation.
    net_liquidation_usd: float = 100000.0


class BrokerConfig(BaseModel):
    # TWS live=7496, paper=7497; IB Gateway live=4001, paper=4002
    port: int | None = None       # None → fall back to IBKR_PORT in .env (default 7497)
    client_id: int | None = None  # None → fall back to IBKR_CLIENT_ID in .env (default 11)


class ChannelConfig(BaseModel):
    kind: str = "cli"


class JournalConfig(BaseModel):
    """Trade journal. `reconcile_at` is post-close ET: reqExecutions only returns the
    current day's executions, so a missed session cannot be recovered later."""

    enabled: bool = True
    reconcile_at: str = "16:10"                     # America/New_York
    horizons: list[int] = Field(default_factory=lambda: [1, 5, 20, 60])


class DailyStageConfig(BaseModel):
    """Independent switches for the stages inside the trading-day cascade.

    Missing keys deliberately default to ``True`` so existing deployments keep their
    historical all-on behaviour until they opt into a staged pause.
    """

    pead_event_triggers: bool = True
    macro_sector_event_triggers: bool = True
    news_backfill: bool = True
    pead_daily: bool = True
    technical_daily: bool = True
    intel_digest: bool = True
    performance_snapshot: bool = True
    perf_risk_digest: bool = True
    journal_marks: bool = True
    chief_daily: bool = True


class ScheduledJobConfig(BaseModel):
    """Independent switches for jobs outside the daily cascade.

    ``pead_observe_window`` controls only scheduler-triggered observation
    extraction. Explicit ``ats evidence observe`` runs remain available.
    """

    factset_weekly_ingest: bool = True
    weekly_review: bool = True
    journal_reconcile: bool = True
    pead_score_bmo: bool = True
    pead_score_amc: bool = True
    pead_observe_window: bool = True


class ScheduleConfig(BaseModel):
    # No `enabled` flag: it existed but was never read by start(), so settings.yaml
    # advertised `enabled: false` while the launchd job scheduled normally. Whether
    # the scheduler runs is decided by whether `ats schedule` is running.
    run_at: str = "16:15"          # daily cycle; PEAD score windows: config/pead.yaml
    timezone: str = "America/New_York"
    # Macro/sector weekly review: its OWN time/timezone, deliberately decoupled from
    # run_at/timezone above. It never touches the broker or NYSE sessions, so there is
    # no reason to tie it to ET — and doing so is actively wrong once the trigger's
    # local day and the ET calendar day disagree (e.g. Beijing Saturday 08:40 is still
    # Friday evening in New York). See scheduler._today_weekly().
    weekly_review_at: str = "10:30"
    weekly_review_tz: str = "America/New_York"
    # FactSet 的独立数据准备任务；必须早于同一时区的周度评审。
    factset_refresh_at: str = "08:10"
    factset_refresh_tz: str = "America/New_York"
    # Semantic release uses the final report dated within each calendar month.
    # Run after US close on month-end; the weekly legacy schedule remains a
    # rollback path while ATS_FACTSET_SCHEDULE_SEMANTIC is off.
    factset_month_end_at: str = "23:30"
    factset_month_end_tz: str = "America/New_York"
    # This host sleeps. A job whose trigger fires while the Mac is asleep only runs on
    # wake, and only if it is still inside this window — with the old 1 hour, every
    # overnight trigger was silently dropped. See scheduler.start().
    misfire_grace_hours: float = 6.0
    daily_stages: DailyStageConfig = Field(default_factory=DailyStageConfig)
    jobs: ScheduledJobConfig = Field(default_factory=ScheduledJobConfig)


class SectorBrief(BaseModel):
    label: str = ""
    supply_chain: str = ""


class AppConfig(BaseModel):
    environment: str = "paper"
    llm: LLMConfig = Field(default_factory=LLMConfig)
    risk: RiskConfig = Field(default_factory=RiskConfig)
    account: AccountConfig = Field(default_factory=AccountConfig)
    broker: BrokerConfig = Field(default_factory=BrokerConfig)
    channel: ChannelConfig = Field(default_factory=ChannelConfig)
    schedule: ScheduleConfig = Field(default_factory=ScheduleConfig)
    journal: JournalConfig = Field(default_factory=JournalConfig)
    tickers: list[Ticker] = Field(default_factory=list)
    sectors: dict[str, SectorBrief] = Field(default_factory=dict)

    @property
    def sectors_in_use(self) -> list[str]:
        return sorted({t.sector for t in self.tickers})


class Config(BaseModel):
    """Merged configuration handed to the rest of the system."""

    app: AppConfig
    secrets: Secrets

    model_config = {"arbitrary_types_allowed": True}


def _load_yaml(path: Path) -> dict:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def _load_risk_yaml() -> dict:
    """Return the single source of truth for all adjustable risk configuration."""
    return _load_yaml(_config_dir() / "risk.yaml")


def load_risk_yaml_section(key: str) -> dict:
    """One top-level section of risk.yaml (e.g. `layer_utilization`), or {}."""
    return _load_risk_yaml().get(key, {}) or {}


@functools.lru_cache(maxsize=1)
def get_config() -> Config:
    cfg_dir = _config_dir()
    settings_raw = _load_yaml(cfg_dir / "settings.yaml")
    watchlist_raw = _load_yaml(cfg_dir / "watchlist.yaml")
    merged = {**settings_raw, **watchlist_raw, "risk": _load_risk_yaml().get("limits", {})}
    return Config(app=AppConfig.model_validate(merged), secrets=Secrets())


def reset_config_cache() -> None:
    """Clear the cache (tests that point ATS_CONFIG_DIR elsewhere)."""
    get_config.cache_clear()
    load_entities.cache_clear()
    _alias_index.cache_clear()


def load_news_sources() -> dict:
    """Load config/data/news_sources.yaml (RSS feeds, X accounts, keyword filters)."""
    return _load_yaml(_config_dir() / "data" / "news_sources.yaml")


@functools.lru_cache(maxsize=1)
def load_entities() -> dict:
    """Load config/entities.yaml — the canonical witness-identity registry.

    Returns {canonical: {name, aliases, market, filings}}. Absent file is fine: every
    symbol then resolves to itself, which is the pre-registry behaviour.
    """
    return _load_yaml(_config_dir() / "entities.yaml").get("entities", {}) or {}


@functools.lru_cache(maxsize=1)
def _alias_index() -> dict[str, str]:
    idx: dict[str, str] = {}
    for canonical, meta in load_entities().items():
        idx[canonical.upper()] = canonical
        for alias in (meta or {}).get("aliases", []) or []:
            idx[str(alias).upper()] = canonical
    return idx


def canonical_entity(symbol: str) -> str:
    """Fold a ticker onto the company that speaks through it.

    Load-bearing for the corroboration gates: SK hynix trades as SKHY, HY9H and
    000660.KS, and one earnings call filed under three ids would read as three
    independent witnesses — defeating the stance-diversity gate from the inside, which
    is the least visible way for it to fail. Unknown symbols pass through unchanged.

    The `NAME (TICKER)` fallback exists because third-party prose names companies the
    way a journalist does, not the way a filing does. Measured after wiring up the news
    and newsletter sources (2026-08-18): `NVIDIA (NVDA)`, `MICRON (MU)`,
    `APPLIED MATERIALS (AMAT)` all arrived as fresh unresolvable entities — and an
    entity that resolves to nothing is not merely untidy, it is unreachable:
    `corroborate.assess_layer` gathers rows BY entity, so those readings can never enter
    any claim. Enumerating one alias per phrasing loses that race by construction; the
    parenthesised ticker is the publisher already telling us the answer.
    """
    key = (symbol or "").upper().strip()
    idx = _alias_index()
    if key in idx:
        return idx[key]
    # "NVIDIA (NVDA)" -> try NVDA, then the bare name. Only a trailing parenthetical of
    # ticker-shaped text; anything else is left alone rather than guessed at.
    m = re.fullmatch(r"(.+?)\s*\(([A-Z0-9.\-]{1,12})\)", key)
    if m:
        name, ticker = m.group(1).strip(), m.group(2)
        for cand in (ticker, name):
            if cand in idx:
                return idx[cand]
        return ticker            # unregistered, but at least stable across phrasings
    return symbol


def entity_meta(symbol: str) -> dict:
    """Registry record for a symbol (via its canonical id); {} when unregistered."""
    return load_entities().get(canonical_entity(symbol), {}) or {}


def load_pead_global() -> dict:
    """Load config/pead.yaml (targets, monitor switches, schedule windows)."""
    cfg = _load_yaml(_config_dir() / "pead.yaml")
    cfg.setdefault("targets", [])
    cfg.setdefault("observe", [])       # evidence-only coverage; never reaches the order path
    cfg.setdefault("monitor", {})
    cfg["monitor"].setdefault("enabled", True)
    cfg["monitor"].setdefault("lookback_days", 7)
    cfg["monitor"].setdefault("push_context_updates", False)
    cfg["monitor"].setdefault("materiality_threshold", 0.7)
    cfg["monitor"].setdefault("triage", {})
    t = cfg["monitor"]["triage"]
    t.setdefault("enabled", True)
    t.setdefault("min_score", 0.35)        # below: stored but kept out of the LLM context
    t.setdefault("fulltext_score", 0.65)   # at/above: fetch the article body
    t.setdefault("max_fulltext", 4)
    t.setdefault("fulltext_chars", 12000)
    cfg.setdefault("research", {})
    r = cfg["research"]
    r.setdefault("enabled", True)
    r.setdefault("lookback_days", 2)
    r.setdefault("max_articles_per_run", 8)
    r.setdefault("article_chars", 40000)
    r.setdefault("min_confidence_event", 0.6)   # >= this -> synthetic event into pead_events
    r.setdefault("push_threshold", 0.8)         # >= this -> immediate Feishu push
    cfg.setdefault("schedule", {})
    cfg["schedule"].setdefault("prep_days_before", 3)
    cfg["schedule"].setdefault("score_after", True)
    # Two score windows a day, in America/New_York: after the close for amc prints
    # (so the Boss can approve overnight and fill at the next open), late morning for
    # bmo prints. A print whose session is unknown is attempted in both.
    cfg["schedule"].setdefault("score_windows", {"bmo": "11:00", "amc": "20:00"})
    cfg["schedule"].setdefault("score_lookback_days", 4)      # how far back to catch up
    cfg["schedule"].setdefault("transcript_upgrade_days", 4)  # v1 -> v2 retry window
    cfg["schedule"].setdefault("chief_after_score", True)     # one chief cycle per window
    # Kill-switch for the staged rollout: while false, the score windows are forced to
    # dry-run even when the daemon runs --live (see pead_score_window).
    cfg["schedule"].setdefault("score_windows_live", False)
    # Orders raised by the after-close window are approved overnight and submitted
    # before the open, so they are repriced as limits off the last close ± this much.
    cfg["schedule"].setdefault("overnight_limit_slippage_pct", 0.5)
    cfg.setdefault("score", {})
    # A chrome-stripped transcript is ~55K chars (~14K tokens) — fits whole in a
    # 200K context, so these caps are guardrails rather than routine clips.
    cfg["score"].setdefault("transcript_chars", 120000)
    cfg["score"].setdefault("documents_chars", 40000)
    # Opening size for a transcript-less v1: guidance and management tone are missing,
    # so the read is genuinely thinner. De-risking is never scaled (see agents decide).
    cfg["score"].setdefault("v1_size_factor", 0.5)
    cfg.setdefault("docs_root", "")
    cfg.setdefault("industry_notes", {})
    cfg["industry_notes"].setdefault("root", "")
    cfg["industry_notes"].setdefault("files", [])
    cfg["industry_notes"].setdefault("max_chars_per_file", 12000)
    cfg.setdefault("sector_review", {})
    sr = cfg["sector_review"]
    sr.setdefault("enabled", True)
    sr.setdefault("sectors", ["ai_hardware"])
    sr.setdefault("weekday", 5)          # 5 = Saturday (weekly scheduled run; own cron job,
                                          # decoupled from the mon-fri trading-day cascade)
    # Phase D (5.8): inject_prep / inject_monitor switches REMOVED, not defaulted —
    # sector conclusions never enter the PEAD prep/monitor context again.
    # Cross-section + chain evidence -> moat_pricing -> Chief. The kill switch for the
    # whole stage-3 path: off = the system behaves exactly as it did before.
    sr.setdefault("cross_section", True)
    sr.setdefault("feed_chief_basket", True)
    # 涌现命题归纳（阶段四）：证据驱动，不设 cron。门槛是确定性的——由未归属观测
    # 的积累触发，纯时间流逝不触发。产出只是给人看的待确认卡。
    cfg.setdefault("induction", {})
    ind = cfg["induction"]
    ind.setdefault("enabled", True)
    ind.setdefault("min_observations", 6)   # 够成形，不是零星噪音
    ind.setdefault("min_entities", 3)       # 跨来源，不是一家的自说自话
    ind.setdefault("cooldown_days", 30)     # 被拒的候选不得换个说法下周再来
    cfg.setdefault("macro_review", {})
    mr = cfg["macro_review"]
    mr.setdefault("enabled", True)
    mr.setdefault("name", "macro")
    mr.setdefault("weekday", 5)          # runs BEFORE sector on Saturdays (cascade)
    mr.setdefault("feed_sector", True)   # prepend macro regime into sector review context
    return cfg


def load_pead_config(symbol: str):
    """Merge config/pead/_defaults.yaml with config/pead/<SYM>.yaml -> PeadConfig."""
    from .schemas.pead import PeadConfig

    pead_dir = _config_dir() / "pead"
    base = _load_yaml(pead_dir / "_defaults.yaml")
    override = _load_yaml(pead_dir / f"{symbol.upper()}.yaml")
    merged = {**base, **override, "symbol": symbol.upper()}
    if not merged.get("signal_chain"):
        merged["signal_chain"] = _derive_signal_chain(symbol.upper())
    return PeadConfig.model_validate(merged)


def _derive_signal_chain(symbol: str) -> list[dict]:
    """Fallback peer list when a ticker's YAML doesn't curate a `signal_chain`.

    Otherwise a newly-added PEAD target silently ships with an empty cross-symbol
    section (see MSFT's original stub, which had no signal_chain and always
    rendered "跨标的信号链（暂无数据）"). Peers come from whichever sector layer the
    symbol belongs to, all tagged role=peer — we don't guess upstream/downstream
    direction here; a curated YAML entry (like MSFT/NVDA/TSM) always overrides this.
    """
    try:
        sector_cfg = load_sector_config()
    except Exception:
        return []
    for layer in sector_cfg.layers:
        if any(t.symbol == symbol for t in layer.tickers):
            return [{"symbol": t.symbol, "role": "peer"}
                    for t in layer.tickers if t.symbol != symbol]
    return []


def is_pead_target(symbol: str) -> bool:
    """True if the symbol is a TRADABLE PEAD target: full scoring, may reach the order path.

    Strictly `config/pead.yaml: targets`. A per-ticker file is optional (missing means
    "use the _defaults scorecard") and — importantly — is NOT evidence of coverage:
    treating a leftover file as coverage is what made MSFT/AMZN look tracked (tagged
    [PEAD] in the sector review, consensus fetched) while no scheduler loop ever
    touched them. Coverage is now declared, not inferred from the filesystem.
    """
    return symbol.upper() in {s.upper() for s in load_pead_global().get("targets", [])}


def pead_observe_list() -> list[str]:
    """Evidence-only coverage: earnings are read for chain evidence, never scored/traded."""
    return [str(s).upper() for s in load_pead_global().get("observe", [])]


def is_pead_covered(symbol: str) -> bool:
    """True if the symbol is covered at all — tradable target OR evidence-only observe.

    Use this for *display/enrichment* decisions (sector [PEAD] tag, consensus fetch).
    Use `is_pead_target` for anything that can lead to an order.
    """
    sym = symbol.upper()
    return is_pead_target(sym) or sym in set(pead_observe_list())


def load_technical_config(name: str = "technical"):
    """Load config/technical.yaml -> TechnicalConfig.

    Only `universe`/`review` get per-key setdefaults here. The strategy
    thresholds deliberately do NOT: their one authoritative home is
    agents/technical/strategy.py, merged key-by-key at use time. Defaulting them
    in two places is exactly how a code default silently stops taking effect
    (same reasoning as the macro `regime` block further down).
    """
    from .schemas.technical import TechnicalConfig

    raw = _load_yaml(_config_dir() / f"{name}.yaml")
    if not raw:
        raise FileNotFoundError(f"config/{name}.yaml not found")
    raw.setdefault("universe", {})
    u = raw["universe"]
    u.setdefault("include_holdings", True)
    u.setdefault("include_pead_targets", True)
    u.setdefault("exclude", ["SGOV", "SHV", "BIL"])
    u.setdefault("min_bars", 200)
    raw.setdefault("params", {})          # empty -> strategy.py defaults apply
    raw.setdefault("review", {})
    raw["review"].setdefault("history_days", 420)
    raw["review"].setdefault("chief_block_chars", 1200)
    return TechnicalConfig.model_validate(raw)


def load_sector_config(name: str = "ai_hardware"):
    """Load sector structure and inject its caps from the central risk.yaml."""
    from .schemas.sector import SectorConfig

    raw = _load_yaml(_config_dir() / "sectors" / f"{name}.yaml")
    if not raw:
        raise FileNotFoundError(f"config/sectors/{name}.yaml not found")
    risk_yaml = _load_risk_yaml()
    cap_config = (risk_yaml.get("sector_layer_caps", {}).get(name, {}) or {})
    layer_keys = [layer.get("key") for layer in raw.get("layers", [])]
    for layer in raw.get("layers", []):
        caps = cap_config.get(layer.get("key"), {}) or {}
        if "weight_cap" in caps:
            layer["weight_cap"] = caps["weight_cap"]
        if "weight_cap_hard" in caps:
            layer["weight_cap_hard"] = caps["weight_cap_hard"]

    # Caps and layers must line up both ways. A layer with no cap silently falls back to
    # the conservative default in cross_section (0.10) — which is safe but invisible, and
    # a cap left behind by a renamed layer is a guard that stopped guarding anything.
    for key in layer_keys:
        if key not in cap_config:
            log.warning("sector %s: layer %r has no weight_cap in risk.yaml "
                        "sector_layer_caps — its cross-section budget falls back to the "
                        "conservative default", name, key)
    for key in cap_config:
        if key not in layer_keys:
            log.warning("sector %s: risk.yaml declares a cap for %r, which is not a layer "
                        "in this sector (stale after a rename?)", name, key)

    groups_cfg = (risk_yaml.get("layer_groups", {}).get(name, {}) or {})
    groups = []
    for gkey, gval in groups_cfg.items():
        members = list((gval or {}).get("layers") or [])
        unknown = [m for m in members if m not in layer_keys]
        if unknown:
            log.warning("sector %s: layer_group %r names unknown layers %s — they are "
                        "dropped from the group ceiling", name, gkey, unknown)
            members = [m for m in members if m in layer_keys]
        groups.append({"key": gkey, "label": (gval or {}).get("label", ""),
                       "layers": members,
                       "weight_cap": (gval or {}).get("weight_cap", 1.0),
                       "weight_cap_hard": (gval or {}).get("weight_cap_hard")})
    raw["layer_groups"] = groups
    raw.setdefault("snapshot", {})
    raw["snapshot"].setdefault("momentum_days", [20, 60])
    raw["snapshot"].setdefault("consensus_for", "pead_targets")
    raw["snapshot"].setdefault("sleep_between_tickers", 0.8)
    raw.setdefault("review", {})
    r = raw["review"]
    r.setdefault("static_notes_chars", 36000)
    # 各层 structure_notes 汇总给 sector_analyst。2026-08-15 从 24000 提到 32000：
    # 半导体设备.md 改写后九份笔记合计 22.9k，只剩 4.5% 余量，而**截断是静默的**且切的是
    # 拼接顺序最后一份（L6）的尾部——正好是「常见误判」那节。上限只封顶不设目标，
    # 提高它本身不增加 prompt 长度。
    # 2026-08-18 从 32000 提到 44000：芯片设计.md 改写后九份已实测到 30.7k（上一条注释里
    # 的 22.9k 当天就被那次改写作废了），余量只剩 4%；再挂上新增的 L1 Token经济.md（6.0k）
    # 会到 36.7k，**正好复现上一次要避免的那次静默截断**。同一个坑第二次踩，说明单靠注释
    # 里的一个数字盯不住——真正的护栏是 assemble._kb_criteria 里那条超限 warning。
    r.setdefault("kb_criteria_chars", 44000)
    r.setdefault("insights_per_ticker", 3)
    r.setdefault("events_lookback_days", 14)
    r.setdefault("events_min_triage", 0.6)
    r.setdefault("dossier_excerpt_chars", 350)
    # Chain-evidence corroboration thresholds (docs/CHAIN_EVIDENCE.md §4). Config, not
    # constants: they are judgement calls about how much evidence is "enough".
    r.setdefault("corroboration", {})
    c = r["corroboration"]
    c.setdefault("min_clusters", 2)         # independent evidence clusters for a verdict
    c.setdefault("min_stance_classes", 2)   # 3 sell-side notes are ONE witness class
    c.setdefault("min_confidence", 0.5)     # drop low-confidence extractions
    for layer in raw.get("layers", []):     # claims carry their layer for reporting
        for claim in layer.get("claims", []) or []:
            claim.setdefault("layer", layer.get("key", ""))
    return SectorConfig.model_validate(raw)


def load_instrument_risk_registry():
    """Load execution-instrument -> economic-risk metadata.

    Missing metadata is intentionally valid: the registry resolves an unknown security
    to its own normalized symbol with a 1x multiplier.
    """
    from .schemas.instruments import InstrumentRiskRegistry

    raw = _load_risk_yaml()
    return InstrumentRiskRegistry.model_validate({"instruments": raw.get("instruments", {})})


def load_risk_policy():
    """Load hard survival/state policy kept separate from strategy settings."""
    from .schemas.risk import RiskPolicy

    raw = _load_risk_yaml()
    return RiskPolicy.model_validate({
        "option_survival": raw.get("option_survival", {}),
        "directive": raw.get("directive", {}),
    })


def load_events() -> list:
    """Load config/events.yaml -> [CalendarEvent]. Missing/empty file -> []."""
    from .schemas.events import CalendarEvent

    raw = _load_yaml(_config_dir() / "events.yaml")
    return [CalendarEvent.model_validate(e) for e in (raw.get("events") or [])] if raw else []


def load_macro_config(name: str = "macro"):
    """Load config/macro.yaml -> MacroConfig (with sub-dict defaults)."""
    from .schemas.macro_strategy import MacroConfig

    raw = _load_yaml(_config_dir() / f"{name}.yaml")
    if not raw:
        raise FileNotFoundError(f"config/{name}.yaml not found")
    raw.setdefault("search", {})
    raw["search"].setdefault("max_results_per_query", 4)
    raw["search"].setdefault("recency_days", 21)
    raw["search"].setdefault("max_chars_per_result", 1800)
    raw.setdefault("review", {})
    raw["review"].setdefault("max_context_chars", 60000)
    # Regime thresholds intentionally get no per-key setdefault here: the values
    # live in config/macro.yaml (tunable without a code change) and fall back to
    # agents/macro/regime.DEFAULTS key-by-key at merge time. Duplicating them in
    # a third place is exactly how a code default silently stops taking effect.
    raw.setdefault("regime", {})
    return MacroConfig.model_validate(raw)
