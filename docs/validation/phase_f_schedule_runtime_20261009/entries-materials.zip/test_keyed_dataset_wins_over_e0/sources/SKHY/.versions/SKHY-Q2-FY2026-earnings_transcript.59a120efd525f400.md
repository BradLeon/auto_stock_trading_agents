---
symbol: SKHY
period: Q2 FY2026
doc_type: earnings_transcript
document_key: Q2 FY2026
source: defeatbeta
source_url: ''
fetched_at: '2026-10-09T01:04:56+00:00'
sha256: 59a120efd525f40018cb606f4c945029c28a3723ccd7382748eacf68564918d9
chars: 2646
external_id: defeatbeta:SKHY:2026-07-29
title: SKHY Q2 FY2026 earnings call transcript
published_at: '2026-07-29'
related_entities: SKHY
completeness: full
truncation_reason: ''
carrier_format: structured_text
mime_source: ''
---

## Prepared Remarks

**Operator:** Welcome to the SK hynix Q2 2026 earnings call. Welcome to the SK hynix Q2 2026 earnings call. Welcome to the SK hynix Q2 2026 earnings call. Welcome to the SK hynix Q2 2026 earnings call. Welcome to the SK hynix Q2 2026 earnings call. Welcome to the SK hynix Q2 2026 earnings call. Welcome to the SK hynix Q2 2026 earnings call. Welcome to the SK hynix Q2 2026 earnings call.

**Chief Executive Officer:** These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks.

**Chief Financial Officer:** Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved.

## Questions and Answers

**Operator:** We will now begin the question-and-answer session. We will now begin the question-and-answer session. We will now begin the question-and-answer session. We will now begin the question-and-answer session. We will now begin the question-and-answer session. We will now begin the question-and-answer session. We will now begin the question-and-answer session. We will now begin the question-and-answer session.

**Analyst:** Could you discuss AI demand and capacity? Could you discuss AI demand and capacity? Could you discuss AI demand and capacity? Could you discuss AI demand and capacity? Could you discuss AI demand and capacity? Could you discuss AI demand and capacity? Could you discuss AI demand and capacity? Could you discuss AI demand and capacity?

**Chief Executive Officer:** AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust.

**Operator:** Thank you. This concludes the call. Thank you. This concludes the call. Thank you. This concludes the call. Thank you. This concludes the call. Thank you. This concludes the call. Thank you. This concludes the call. Thank you. This concludes the call. Thank you. This concludes the call.