"""Runtime entrypoints (CLI, scheduler)."""
