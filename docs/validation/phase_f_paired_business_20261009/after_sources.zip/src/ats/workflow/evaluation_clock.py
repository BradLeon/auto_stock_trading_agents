"""Logical evaluation time for isolated replay; source timestamps remain untouched."""
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime

_POINT = ContextVar("evaluation_time", default=None)


def now(tz=None):
    point = _POINT.get()
    if point is None:
        return datetime.now(tz)
    if tz is None:
        return point.astimezone().replace(tzinfo=None)
    return point.astimezone(tz)


@contextmanager
def at(point):
    from .isolation import verified_isolation_root
    if point.tzinfo is None or verified_isolation_root() is None:
        raise PermissionError("logical clock requires timezone and complete isolation")
    token = _POINT.set(point)
    try:
        yield
    finally:
        _POINT.reset(token)
