"""Provider-neutral domain contracts for persistent structured research data."""

from __future__ import annotations

from datetime import date, datetime, timezone
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator


__all__ = [
    "AdapterArtifact", "AdapterBatch", "AdapterFailure", "AdmissionResult",
    "ArtifactDescriptor", "CatalogStatus", "DataSnapshot", "DerivationDefinition",
    "EntityRelationInput", "EvidenceCandidateInput", "EvidenceLink", "FetchRequest", "IngestionStatus",
    "MetricDefinition", "NativeRecord", "ObservationInput", "ObservationVintage",
    "Persistence", "ProviderMapping", "QualityStatus", "RawArtifact", "RetiredSource",
    "RetirementDisposition", "SeriesIdentity",
    "ReferenceEntityInput", "SnapshotItem", "SourceSelection", "StructuredDataset", "StructuredSource",
    "VerificationStatus", "DiscoveryResult", "ReleaseCandidate", "DiscoveryStatus",
]


class Persistence(str, Enum):
    PERSISTENT = "persistent"
    RUNTIME = "runtime"


class CatalogStatus(str, Enum):
    CURRENT = "current"
    CURRENT_PARTIAL = "current_partial"
    PLANNED = "planned"
    RUNTIME_EXCLUDED = "runtime_excluded"
    DEFERRED = "deferred"


class QualityStatus(str, Enum):
    ACCEPTED = "accepted"
    WARNING = "warning"
    CONFLICT = "conflict"
    QUARANTINED = "quarantined"


class VerificationStatus(str, Enum):
    NEEDS_EVIDENCE = "needs_evidence"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    SUPERSEDED = "superseded"


class IngestionStatus(str, Enum):
    RUNNING = "running"
    SUCCEEDED = "succeeded"
    NO_CHANGE = "no_change"
    ZERO_MATCH = "zero_match"
    NOT_YET_PUBLISHED = "not_yet_published"
    NO_COVERAGE = "no_coverage"
    STALE = "stale"
    UNREACHABLE = "unreachable"
    UNAUTHORIZED = "unauthorized"
    NOT_PDF = "not_pdf"
    PARSE_FAILED = "parse_failed"
    VALIDATION_FAILED = "validation_failed"
    PARTIAL = "partial"
    EXPORT_UNREADABLE = "export_unreadable"
    ACCESS_REQUIRED = "access_required"
    METHODOLOGY_DRIFT = "methodology_drift"
    SOURCE_CONFLICT = "source_conflict"


class DiscoveryStatus(str, Enum):
    """Outcome of a source metadata check, separate from an ingestion run."""

    NEW_RELEASE = "new_release"
    NO_CHANGE = "no_change"
    NOT_YET_PUBLISHED = "not_yet_published"
    QUESTION_NOT_FIELDED = "question_not_fielded"
    METHODOLOGY_BREAK = "methodology_break"
    UNREACHABLE = "unreachable"
    VALIDATION_FAILED = "validation_failed"
    SUCCEEDED = "succeeded"
    EXPORT_UNREADABLE = "export_unreadable"
    ACCESS_REQUIRED = "access_required"
    METHODOLOGY_DRIFT = "methodology_drift"
    SOURCE_CONFLICT = "source_conflict"
    PARTIAL = "partial"


def _aware(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None:
        raise ValueError("structured timestamps must be timezone-aware")
    return value.astimezone(timezone.utc)


class StructuredSource(BaseModel):
    id: str
    provider: str
    adapter: str
    persistence: Persistence = Persistence.PERSISTENT
    catalog_status: CatalogStatus = CatalogStatus.PLANNED
    cadence: str = ""
    retention: str = "source_policy"
    datasets: list[str] = Field(default_factory=list)
    upstream: str = ""
    constraints: dict[str, Any] = Field(default_factory=dict)

    @model_validator(mode="after")
    def runtime_has_no_datasets(self):
        if self.catalog_status == CatalogStatus.RUNTIME_EXCLUDED:
            if self.persistence != Persistence.RUNTIME or self.datasets:
                raise ValueError("runtime/excluded sources must be runtime with no datasets")
        return self


class RetirementDisposition(str, Enum):
    """What happened to a retired source's stored data."""

    PURGED = "purged"                  # rows and exclusive blobs physically deleted
    RETAINED_ORPHAN = "retained_orphan"  # rows intentionally kept, sourced from nothing


class RetiredSource(BaseModel):
    """Machine-readable tombstone for a source id that has been retired.

    A tombstone is not an active source configuration: it carries no adapter,
    dataset or rollout mode, and no collection, publication or query path reads
    it as a live source.  It exists so a retired id cannot be silently
    re-registered, so the stored-data decision is auditable, and so any orphan
    rows left in the database have an explanation.
    """

    id: str
    retired_at: date
    reason: str
    disposition: RetirementDisposition
    prior_catalog_status: str = ""
    prior_rollout_mode: str = ""
    disposition_at: date | None = None
    successor: str = ""
    spec_removed: bool = False


class StructuredDataset(BaseModel):
    id: str
    catalog_status: CatalogStatus = CatalogStatus.PLANNED
    expected_cadence: str = ""
    primary_sources: list[str] = Field(default_factory=list)
    fallback_sources: list[str] = Field(default_factory=list)
    core_metrics: list[str] = Field(default_factory=list)
    quality: dict[str, Any] = Field(default_factory=dict)
    entities: list[str] = Field(default_factory=list)
    acceptance_samples: list[str] = Field(default_factory=list)


class MetricDefinition(BaseModel):
    id: str
    value_type: str = "number"
    unit_family: str
    cadence: str = ""
    period_basis: str | list[str] = ""
    adjustment: str = ""
    derived: bool = False
    description: str = ""
    version: str = "v1"
    entity_scope: list[str] = Field(default_factory=list)
    required_dimensions: list[str] = Field(default_factory=list)


class ProviderMapping(BaseModel):
    provider: str
    provider_field: str
    metric_id: str
    version: str = "v1"
    dimensions: dict[str, Any] = Field(default_factory=dict)


class ArtifactDescriptor(BaseModel):
    source_id: str
    dataset_id: str
    fetched_at: datetime
    query_scope: dict[str, Any] = Field(default_factory=dict)
    source_url: str = ""
    source_version: str = ""
    media_type: str = "application/octet-stream"
    retention: str = "source_policy"
    storage_mode: str = "full"
    pointer: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)

    _fetched_at_aware = field_validator("fetched_at")(_aware)


class RawArtifact(BaseModel):
    id: str
    blob_id: str
    content_hash: str
    relative_path: str = ""
    bytes: int = 0
    descriptor: ArtifactDescriptor


class SeriesIdentity(BaseModel):
    source_id: str
    dataset_id: str
    entity_id: str
    metric_id: str
    unit: str
    currency: str = ""
    period_basis: str = ""
    adjustment: str = ""
    dimensions: dict[str, Any] = Field(default_factory=dict)

    @field_validator("entity_id")
    @classmethod
    def entity_upper(cls, value: str) -> str:
        value = value.strip().upper()
        if not value:
            raise ValueError("entity_id is required")
        return value


class ObservationInput(BaseModel):
    series: SeriesIdentity
    period: str
    value: float
    period_start: str = ""
    period_end: str = ""
    event_time: datetime | None = None
    published_at: datetime | None = None
    known_at: datetime
    fetched_at: datetime
    artifact_id: str = ""
    quality_status: QualityStatus = QualityStatus.ACCEPTED
    quality: dict[str, Any] = Field(default_factory=dict)
    raw: dict[str, Any] = Field(default_factory=dict)

    _event_aware = field_validator("event_time")(_aware)
    _published_aware = field_validator("published_at")(_aware)
    _known_aware = field_validator("known_at")(_aware)
    _fetched_aware = field_validator("fetched_at")(_aware)

    @model_validator(mode="after")
    def time_order(self):
        if self.known_at > self.fetched_at:
            raise ValueError("known_at cannot be later than fetched_at")
        if self.published_at and self.published_at > self.known_at:
            raise ValueError("published_at cannot be later than known_at")
        if not self.period.strip():
            raise ValueError("period is required")
        return self


class ObservationVintage(BaseModel):
    id: str
    series_id: str
    content_hash: str
    created: bool = True
    observation: ObservationInput


class FetchRequest(BaseModel):
    source_id: str
    dataset_id: str
    entities: list[str] = Field(default_factory=list)
    periods: list[str] = Field(default_factory=list)
    query_scope: dict[str, Any] = Field(default_factory=dict)

    @field_validator("entities")
    @classmethod
    def entities_upper(cls, values: list[str]) -> list[str]:
        return [value.upper() for value in values]


class ReleaseCandidate(BaseModel):
    """An immutable upstream release identity found during read-only discovery."""

    identity: str
    period: str = ""
    urls: list[str] = Field(default_factory=list)
    methodology_fingerprint: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class DiscoveryResult(BaseModel):
    """Auditable result of checking a source without necessarily downloading it."""

    source_id: str
    dataset_id: str
    checked_at: datetime
    status: DiscoveryStatus
    latest_upstream_identity: str = ""
    latest_available_period: str = ""
    candidates: list[ReleaseCandidate] = Field(default_factory=list)
    diagnostics: dict[str, Any] = Field(default_factory=dict)

    _checked_aware = field_validator("checked_at")(_aware)


class NativeRecord(BaseModel):
    entity_id: str
    provider_field: str
    period: str
    value: Any
    unit: str = ""
    currency: str = ""
    period_basis: str = ""
    adjustment: str = ""
    period_start: str = ""
    period_end: str = ""
    event_time: datetime | None = None
    published_at: datetime | None = None
    dimensions: dict[str, Any] = Field(default_factory=dict)
    raw: dict[str, Any] = Field(default_factory=dict)
    slice_key: str = ""

    _event_time_aware = field_validator("event_time")(_aware)
    _published_at_aware = field_validator("published_at")(_aware)

    @field_validator("entity_id")
    @classmethod
    def native_entity_upper(cls, value: str) -> str:
        return (value or "").upper()


class AdapterArtifact(BaseModel):
    # Empty is retained only for legacy single-artifact adapters.  New multi-slice
    # adapters must provide a unique key and records/relations must reference it.
    artifact_key: str = ""
    payload: bytes | str | dict | list | None = None
    query_scope: dict[str, Any] = Field(default_factory=dict)
    source_url: str = ""
    source_version: str = ""
    media_type: str = "application/json"
    retention: str = "source_policy"
    storage_mode: str = "full"
    pointer: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class ReferenceEntityInput(BaseModel):
    """A provider reference entity that can be admitted before observations."""

    entity_id: str
    kind: str
    canonical_name: str
    aliases: list[str] = Field(default_factory=list)
    securities: list[dict[str, Any]] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("entity_id")
    @classmethod
    def reference_entity_upper(cls, value: str) -> str:
        value = value.strip().upper()
        if not value:
            raise ValueError("entity_id is required")
        return value


class EntityRelationInput(BaseModel):
    """Versioned, source-owned parent/child taxonomy relation."""

    parent_entity_id: str
    child_entity_id: str
    relation_type: str
    source_version: str
    known_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    slice_key: str = ""
    active: bool = True

    _relation_known_aware = field_validator("known_at")(_aware)

    @field_validator("parent_entity_id", "child_entity_id")
    @classmethod
    def relation_entity_upper(cls, value: str) -> str:
        value = value.strip().upper()
        if not value:
            raise ValueError("relation entity id is required")
        return value

    @field_validator("relation_type", "source_version")
    @classmethod
    def relation_required(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("relation type and source version are required")
        return value


class AdapterFailure(BaseModel):
    status: IngestionStatus
    message: str
    entity_id: str = ""
    slice_key: str = ""

    @model_validator(mode="after")
    def terminal_failure(self):
        if self.status in {IngestionStatus.RUNNING, IngestionStatus.SUCCEEDED,
                           IngestionStatus.NO_CHANGE}:
            raise ValueError("adapter failure requires a failure/gap status")
        return self


class AdapterBatch(BaseModel):
    source_id: str
    dataset_id: str
    status: IngestionStatus
    fetched_at: datetime
    records: list[NativeRecord] = Field(default_factory=list)
    artifacts: list[AdapterArtifact] = Field(default_factory=list)
    entities: list[ReferenceEntityInput] = Field(default_factory=list)
    relations: list[EntityRelationInput] = Field(default_factory=list)
    failures: list[AdapterFailure] = Field(default_factory=list)
    provider_metadata: dict[str, Any] = Field(default_factory=dict)

    _batch_fetched_aware = field_validator("fetched_at")(_aware)

    @model_validator(mode="after")
    def batch_is_coherent(self):
        if self.status == IngestionStatus.RUNNING:
            raise ValueError("adapter batches must have a terminal provider status")
        if self.status in {IngestionStatus.SUCCEEDED, IngestionStatus.PARTIAL} \
                and not (self.records or self.relations or self.failures):
            raise ValueError("successful/partial batch must contain records, relations or failures")
        keys = [item.artifact_key for item in self.artifacts if item.artifact_key]
        if len(keys) != len(set(keys)):
            raise ValueError("adapter artifact keys must be unique")
        return self


class AdmissionResult(BaseModel):
    candidate_id: str
    status: str
    reason_codes: list[str] = Field(default_factory=list)
    observation_id: str = ""
    metric_id: str = ""
    created: bool = False


class SourceSelection(BaseModel):
    selected: dict[str, Any] | None = None
    selected_source: str = ""
    selection_reason: str
    alternatives: list[dict[str, Any]] = Field(default_factory=list)
    conflict: bool = False


class DerivationDefinition(BaseModel):
    id: str
    version: str
    operation: str
    inputs: list[str]
    parameters: dict[str, Any] = Field(default_factory=dict)
    output_metric_id: str = ""


class EvidenceCandidateInput(BaseModel):
    entity: str
    metric_id: str
    value: float
    unit: str
    currency: str = ""
    period: str
    event_type: str
    event_date: str
    event_label: str = ""
    document_id: str
    version_id: str
    char_start: int = Field(ge=0)
    char_end: int = Field(ge=0)
    extraction_method: str
    source_tier: str
    confidence: float | None = Field(default=None, ge=0, le=1)
    published_at: datetime | None = None
    raw: dict[str, Any] = Field(default_factory=dict)

    _candidate_published_aware = field_validator("published_at")(_aware)

    @model_validator(mode="after")
    def event_and_span_shape(self):
        if not (self.period or self.event_date):
            raise ValueError("period or event_date is required")
        if self.char_end and self.char_end <= self.char_start:
            raise ValueError("char_end must exceed char_start when a span is supplied")
        return self


class EvidenceLink(BaseModel):
    observation_id: str = ""
    candidate_id: str = ""
    document_id: str
    version_id: str
    anchor_kind: str = "text_span"
    page_number: int | None = Field(default=None, ge=1)
    char_start: int = Field(default=0, ge=0)
    char_end: int = Field(default=0, ge=0)
    chart_id: str = ""
    region: tuple[float, float, float, float] | None = None
    extraction_method: str
    source_tier: str
    verification_status: VerificationStatus = VerificationStatus.NEEDS_EVIDENCE
    reviewer: str = ""
    reviewed_at: datetime | None = None

    _reviewed_aware = field_validator("reviewed_at")(_aware)

    @model_validator(mode="after")
    def valid_span_and_target(self):
        if self.anchor_kind not in {"text_span", "image_region"}:
            raise ValueError("anchor_kind must be text_span or image_region")
        if self.anchor_kind == "text_span" and self.char_end <= self.char_start:
            raise ValueError("text_span char_end must be greater than char_start")
        if self.anchor_kind == "image_region":
            if self.page_number is None or self.region is None:
                raise ValueError("image_region requires page_number and region")
            x0, y0, x1, y1 = self.region
            if not (0 <= x0 < x1 <= 1 and 0 <= y0 < y1 <= 1):
                raise ValueError("image region must be normalized [x0,y0,x1,y1]")
        if not (self.observation_id or self.candidate_id):
            raise ValueError("evidence must target an observation or candidate")
        return self


class SnapshotItem(BaseModel):
    observation_id: str
    selected_source: str
    selection_reason: str
    derivation_id: str = ""
    derivation_version: str = ""


class DataSnapshot(BaseModel):
    id: str = ""
    consumer: str
    purpose: str
    as_of: datetime
    created_at: datetime
    items: list[SnapshotItem] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)

    _as_of_aware = field_validator("as_of")(_aware)
    _created_aware = field_validator("created_at")(_aware)
