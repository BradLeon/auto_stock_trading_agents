# Spec Delta

## Purpose

为 Phase F 提供统一的影子运行与差异归因能力：在可重放的固定输入下让新旧分析、风控与调度路径并行运行并逐类比较差异，同时从进程能力层禁止新路径提交真实订单，使切流决策有可签核、可校验、不可事后改写的证据而不是主观判断。

## ADDED Requirements

### Requirement: 影子运行必须使用可重放的固定输入

影子运行 SHALL 使用可重放输入包，固定已发布数据引用、运行时行情与账户与历史状态、逻辑评估时间、规则版本以及模型与提示配置，保存各项 hash 及可恢复内容或不可变可解析引用。只有摘要 SHALL NOT 判为可重放。实际 runner SHALL 将同一输入与逻辑时钟注入新旧业务流程，保留双方 run IDs、实际读取与输出引用；SHALL NOT 以人工提供左右 JSON 代替执行。持久化 vintage 相同 SHALL NOT 被视为输入已固定。跨进程重放 SHALL 恢复同一输入，不重新查询变化中的运行时来源；模型输出差异仍按适用矩阵判断，不要求逐字确定性。

#### Scenario: 输入包只有 hash

- **WHEN** 运行时账户/行情面只有 hash，且没有可恢复内容或可解析不可变引用
- **THEN** 系统 SHALL 判输入包不可重放
- **AND** SHALL NOT 将其作为同输入影子证据

#### Scenario: A 的 Trader 行情权限用于影子重放

- **WHEN** Risk/Trader 按 A 契约在新旧双跑或跨进程重放中读取审批依据/执行校验价格
- **THEN** 双方 SHALL 经治理适配消费输入包内对应阶段的同一价格、来源、币种与实际 source_as_of，审批依据与执行校验报价分别可追溯
- **AND** SHALL NOT 重新查询变化中的 Provider；仅有相同逻辑评估时间而报价内容不同 SHALL NOT 判同输入

#### Scenario: 从真实双运行入口生成报告

- **WHEN** runner 对同一输入包执行新旧分析/风控
- **THEN** 报告 SHALL 关联双方实际 run IDs、输入与输出引用及逻辑时间
- **AND** 跨进程重放 SHALL 可核对同一输入，导入 JSON 的比较工具 SHALL 单列为工具验证

#### Scenario: 持久化 vintage 相同但运行时快照不同

- **WHEN** 两次影子运行的持久化数据 vintage 相同，但账户状态或运行时行情不同
- **THEN** 系统 SHALL 判定输入包不同并记录差异项
- **AND** 该两轮 SHALL NOT 被当作同输入下的路径比较

#### Scenario: 逻辑评估时间未固定

- **WHEN** 影子输入包未记录逻辑评估时间，而路径行为依赖当前时刻
- **THEN** 系统 SHALL 判定输入包不完整并拒绝将该轮用作一致性证据
- **AND** SHALL 报告缺失的固定项

#### Scenario: 规则或模型配置变更

- **WHEN** 两次运行之间规则版本或模型与提示配置发生变化
- **THEN** 系统 SHALL 记录该变化并使两轮不可直接比较
- **AND** SHALL NOT 将该变化归因为路径差异

### Requirement: 影子比较面必须按批次适用矩阵分级要求

系统 SHALL 以逐批适用矩阵声明必需比较面与输入固定程度。只消费持久化输入的纯研究批次 SHALL 固定持久化引用与投影 hash，运行时面 SHALL 显式不适用；实际消费 runtime 的研究任务 SHALL 固定其实际输入，SHALL NOT 仅因名为研究便省略。依赖时钟的路径 SHALL 固定逻辑时间；含决策/交易批次 SHALL 固定运行时、账户与逻辑时间。类别 SHALL 与实际 scope/触及路径相符。

#### Scenario: 纯研究读取批次不要求交易面比较

- **WHEN** 一个只涉及研究读取的批次执行影子比较
- **THEN** 该批次 SHALL NOT 被要求提供交易归因比较面
- **AND** 该批次的运行时相关面 SHALL 被显式标注为不适用

#### Scenario: 完整交易批次省略必要面

- **WHEN** 一个含决策与交易的批次缺少风控 verdict 或审批链比较面
- **THEN** 该批次 SHALL 判为证据不完整
- **AND** SHALL NOT 以其他批次已比较该面为由放行

#### Scenario: 批次类别与实际范围不符

- **WHEN** 一个被登记为纯研究读取的批次实际触及了决策或交易路径
- **THEN** 系统 SHALL 判该批次类别错误并要求按更高等级重做比较
- **AND** SHALL NOT 沿用较低等级的适用面集合

### Requirement: 影子差异必须覆盖六类比较面

影子差异报告 SHALL 至少覆盖：输入快照、调度遗漏（旧调度已触发而新调度未触发，或反之）、分析输出、风控 verdict 与 counterproposal、审批链（人工批准或拒绝与轮次）、交易归因。每类 SHALL 分别给出 matched、diverged 或 not-compared 的结论与差异明细，SHALL NOT 以汇总数字掩盖未比较或未接受的面。LLM 输出与角色重构引入的差异 SHALL 按矩阵声明的允许区间判定，SHALL NOT 以逐字相等为默认判据。

#### Scenario: 新调度遗漏了一次旧调度已触发的运行

- **WHEN** 同一触发在旧调度路径已执行而新调度路径未产生对应运行
- **THEN** 调度遗漏面 SHALL 记为 diverged 并列出该触发的标识与时间
- **AND** 该差异 SHALL 独立于分析输出一并进入报告

#### Scenario: 新旧同时遗漏

- **WHEN** 某触发在旧路径与新路径均未执行
- **THEN** 系统 SHALL 依据独立预期触发集合判定该遗漏并记为 diverged
- **AND** SHALL NOT 因双方差异一致而未发现该遗漏

#### Scenario: 某一面未比较

- **WHEN** 某类比较面因缺少可比数据而未执行
- **THEN** 报告 SHALL 将该面记为 not-compared 并说明原因
- **AND** SHALL NOT 省略该面或将其计为一致

#### Scenario: 合法语义变化超出允许区间

- **WHEN** 分析输出的差异属角色重构引入的合法变化但超出矩阵允许区间
- **THEN** 该面 SHALL 记为 diverged 且不得默认接受
- **AND** 接受该差异 SHALL 需由矩阵声明的权限方显式记录

### Requirement: 未接受的差异必须显式处置

任何 `diverged` 面 SHALL 在被引用前得到处置：经矩阵声明的权限方显式接受，或修正后重跑。系统 SHALL 记录处置人、时间与理由。未接受的差异 SHALL 使该报告不可作为该范围的通过证据。

#### Scenario: 存在未接受的风控差异

- **WHEN** 某批次的风控 verdict 面为 diverged 且未被显式接受
- **THEN** 该报告 SHALL NOT 被引为该范围的通过证据
- **AND** 系统 SHALL 报告该未接受差异

#### Scenario: 差异被接受

- **WHEN** 矩阵声明的权限方显式接受某 diverged 面并记录理由
- **THEN** 该报告 SHALL 可在满足其他条件时被引用
- **AND** 接受记录 SHALL 与报告关联且可审计

### Requirement: 切流必须校验所引用报告的适用性

切流 dry-run、CLI 与执行器 SHALL 强制提供报告校验能力并引用来自实际运行的报告，校验四项：签核有效且未被驳回或撤销、必需面无 `not-compared`、无未接受差异、报告仍适用于当前 scope 与当前代码与配置。空 ID、缺 checker、不可读或任一不满足 SHALL 拒绝并报告原因。正式生产切换 SHALL 在其适用报告生成和签核之后执行。

#### Scenario: 引用已撤销的报告

- **WHEN** 切流引用一份已被撤销的影子报告
- **THEN** 系统 SHALL 拒绝该次切流并指明报告已撤销
- **AND** SHALL NOT 因报告曾经通过而放行

#### Scenario: 报告范围与本次决策不匹配

- **WHEN** 报告的 scope 与本次切流的 scope 不同
- **THEN** 系统 SHALL 拒绝该次切流并报告范围不匹配
- **AND** SHALL NOT 以该报告覆盖本次决策范围

#### Scenario: 代码变更后报告失效

- **WHEN** 报告生成后相关代码或配置已变更
- **THEN** 系统 SHALL 拒绝该次切流并报告该报告不再适用
- **AND** SHALL 要求在变更后重新取证

### Requirement: 影子期必须从进程能力层禁止新路径真实下单

新路径在影子期 SHALL NOT 具备向券商提交真实订单的进程能力。该禁止 SHALL 由能力层实现并覆盖全部下单出口，SHALL NOT 仅依赖调用方自觉传入的模拟标志。缺少该能力的进程 SHALL 拒绝启动影子任务并报告缺失项。该禁令 SHALL 先于任何接入核验与影子运行可用。

#### Scenario: 影子任务尝试下单

- **WHEN** 影子运行中的新路径到达下单调用点
- **THEN** 系统 SHALL 拒绝该调用并记录为影子期禁止的真实下单尝试
- **AND** 该记录 SHALL 成为可审计的拒绝证据
- **AND** SHALL NOT 因订单被拒而将该次影子运行标记为失败

#### Scenario: 影子运行缺少能力禁令

- **WHEN** 部署的进程不具备禁止真实下单的能力
- **THEN** 影子任务 SHALL 拒绝启动
- **AND** 接入核验 SHALL 同样拒绝在此条件下开始
- **AND** 报告 SHALL 指出缺失的能力项

### Requirement: 下单禁止的验收以提交审计为主证据

影子期无未审批真实下单的验收 SHALL 以新路径的券商提交调用与拒绝审计记录、能力校验结果、隔离演练中的券商模拟接收记录为主要证据。真实成交账本未被污染 SHALL 作为另一条独立验收，二者不互相替代。真实只读核验 SHALL 按 route、账户与订单归因排除既存合法成交。意料之中的模拟提交被能力层阻断 SHALL 计为成功，意外真实提交尝试 SHALL 成为独立差异或批次停止条件。

#### Scenario: 没有实际影子订单或提交尝试

- **WHEN** 影子账本与提交审计为空，只有 helper 的模拟 fixture 测试
- **THEN** 影子期无真实下单与订单全链验收 SHALL 标为未测
- **AND** SHALL NOT 因生产 trades 无新增而判影子期验收完成

#### Scenario: 券商已接收但本地未落库

- **WHEN** 券商侧已接收一笔订单而本地成交账本无对应新增
- **THEN** 系统 SHALL 以提交调用审计为准判定存在真实下单尝试
- **AND** SHALL NOT 因账本无新增而认定无真实下单

#### Scenario: 旧路由合法成交使账本新增

- **WHEN** 影子期内旧活跃 route 产生合法成交，或切换前订单迟到成交
- **THEN** 该新增 SHALL 按 route 与订单归因排除于新路径越权之外
- **AND** 系统 SHALL NOT 因此判定新路径违反禁令

#### Scenario: 意外真实提交尝试

- **WHEN** 审计发现新路径出现一次未被能力层阻断的真实提交尝试
- **THEN** 系统 SHALL 将其记为独立差异并触发该批次停止条件
- **AND** SHALL NOT 归入常规差异明细

### Requirement: 影子订单与真实订单账本必须隔离

影子运行产生的订单意图 SHALL 写入独立影子账本，SHALL NOT 写入真实成交账本或参与持仓、绩效与资金对账。真实下单记录 SHALL NOT 出现在影子差异报告中充当已成交证据；影子意图 SHALL 保留可重建所需的全部归因字段。

#### Scenario: 影子意图进入真实成交账本

- **WHEN** 影子运行的订单意图被写入真实成交账本
- **THEN** 系统 SHALL 判失败并指出该写入
- **AND** 该记录 SHALL NOT 参与持仓、绩效与资金对账

#### Scenario: 影子归因可独立重建

- **WHEN** 审计方请求重建某次影子运行的下单意图
- **THEN** 系统 SHALL 能从影子账本重建该意图及其归因字段
- **AND** 重建 SHALL NOT 改变任何原始记录

### Requirement: 影子报告必须可签核且不可事后改写

每份影子差异报告 SHALL 包含生成时间、输入包 hash、覆盖范围、适用批次类别、逐面结论、差异明细、未比较项与未接受差异。报告 SHALL 为追加式记录，SHALL NOT 覆盖既有报告或修改其结论；签核、驳回与撤销 SHALL 作为新记录追加，并记录操作者与理由。补齐面后可重新签核，但 SHALL 保留此前结论。

#### Scenario: 驳回一份影子报告

- **WHEN** 审阅者驳回某份影子差异报告并给出理由
- **THEN** 系统 SHALL 追加一条驳回记录指向该报告
- **AND** 原报告的结论 SHALL 保持可读且不被改写

#### Scenario: 补齐后重新签核

- **WHEN** 某报告的必需面补齐后被重新签核
- **THEN** 系统 SHALL 追加新的签核记录并保留此前的 not-compared 结论
- **AND** 原报告 SHALL NOT 被覆盖
