"""Context Memory — SQLite structured store.

Persists each cycle's reports, decisions, trades, and performance so the Manager
can be fed prior outcomes and the Boss can pull a name's history on demand. The
semantic/vector layer (Chroma) is a later add; this is the structured backbone.

During the data-layer unification this module still initializes legacy data-layer
tables for backward compatibility. New data-layer repositories own those tables;
new data-layer schema must not be added here. Workflow memory remains the
long-term responsibility of :mod:`ats.memory`.
"""

from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from ..schemas.memory import PerformanceRecord

log = logging.getLogger("ats.memory.store")


class MissingDecisionChainError(Exception):
    """A SYSTEM order submission lacks its decision chain (§11, task 2.1).

    Raised by `save_trades` AFTER the gap has been registered in
    `ledger_exceptions`; the write itself is refused — a half-linked order
    that looks attributable but cannot be verified is worse than no row.
    """

_BASE_SCHEMA = """
CREATE TABLE IF NOT EXISTS cycles (
    cycle_id TEXT PRIMARY KEY, as_of TEXT, approval_status TEXT, manager_summary TEXT
);
CREATE TABLE IF NOT EXISTS decisions (
    cycle_id TEXT, symbol TEXT, action TEXT, notional_usd REAL, limit_price REAL,
    conviction REAL, rationale TEXT
);
CREATE TABLE IF NOT EXISTS trades (
    order_id TEXT, cycle_id TEXT, symbol TEXT, action TEXT, qty REAL, order_type TEXT,
    status TEXT, avg_fill_price REAL, submitted_at TEXT, rationale TEXT
);
CREATE TABLE IF NOT EXISTS performance (
    cycle_id TEXT, as_of TEXT, net_liquidation REAL, daily_pnl REAL, cumulative_pnl REAL,
    realized_pnl REAL, unrealized_pnl REAL, num_positions INTEGER, payload TEXT
);
CREATE TABLE IF NOT EXISTS pead_dossier (
    symbol TEXT, fiscal_label TEXT, phase TEXT, payload TEXT, updated_at TEXT,
    PRIMARY KEY (symbol, fiscal_label)
);
-- PK is (symbol, id), not id alone: one news item is legitimately relevant to
-- several targets (a peer headline is fetched once per target listing it in
-- signal_chain), so it must be storable under each. See _migrate_pead_events_pk.
CREATE TABLE IF NOT EXISTS pead_events (
    id TEXT, symbol TEXT, published_at TEXT, source TEXT,
    headline TEXT, url TEXT, processed INTEGER DEFAULT 0,
    PRIMARY KEY (symbol, id)
);
CREATE TABLE IF NOT EXISTS research_articles (
    id TEXT PRIMARY KEY, source TEXT, title TEXT, url TEXT,
    published_at TEXT, fetched_at TEXT, chars INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS research_insights (
    article_id TEXT, ticker TEXT, direction TEXT, impact_path TEXT,
    summary TEXT, evidence_quote TEXT, confidence REAL, created_at TEXT
);
CREATE TABLE IF NOT EXISTS sector_reviews (
    sector TEXT, as_of TEXT, regime TEXT, summary TEXT, payload TEXT,
    PRIMARY KEY (sector, as_of)
);
CREATE TABLE IF NOT EXISTS macro_reviews (
    name TEXT, as_of TEXT, regime TEXT, summary TEXT, payload TEXT,
    PRIMARY KEY (name, as_of)
);

CREATE TABLE IF NOT EXISTS technical_reviews (
    name TEXT, as_of TEXT, summary TEXT, payload TEXT,
    PRIMARY KEY (name, as_of)
);
CREATE TABLE IF NOT EXISTS fills (
    exec_id TEXT PRIMARY KEY, symbol TEXT, side TEXT, shares REAL, price REAL,
    time TEXT, realized_pnl REAL, commission REAL, order_id TEXT
);
CREATE TABLE IF NOT EXISTS risk_reviews (
    as_of TEXT PRIMARY KEY, risk_state TEXT, summary TEXT, payload TEXT
);
CREATE TABLE IF NOT EXISTS score_consumption (
    symbol TEXT, fiscal_label TEXT, consumed_at TEXT, cycle_id TEXT,
    PRIMARY KEY (symbol, fiscal_label)
);
-- One row per detected earnings print. Caches the resolved fiscal_label so the
-- quarter key cannot drift between the score write and a later Chief read (the
-- upstream calendars do revise quarter/year), and records which source decided
-- the session, for audit.
CREATE TABLE IF NOT EXISTS pead_periods (
    symbol TEXT, earnings_date TEXT, fiscal_label TEXT, quarter INTEGER, year INTEGER,
    session TEXT, session_source TEXT, at TEXT, eps_actual REAL, rev_actual REAL,
    label_source TEXT, detected_at TEXT,
    PRIMARY KEY (symbol, earnings_date)
);
-- Versioned score ledger. Two jobs: (1) the idempotency guard, so a symbol whose
-- session is unknown can be attempted in BOTH daily windows without double-scoring;
-- (2) the v1(no transcript) -> v2(with transcript) upgrade record. Note this is the
-- only reliable "when was it scored" signal — pead_dossier.updated_at is bumped by
-- the daily monitor and so never goes stale.
-- `final` = this score is the one the Chief may act on. A transcript-backed score is
-- final immediately; a transcript-less v1 is NOT (it is deliberately withheld from the
-- Chief while we retry for the transcript), and gets promoted at the upgrade deadline.
CREATE TABLE IF NOT EXISTS pead_score_runs (
    symbol TEXT, fiscal_label TEXT, version INTEGER, scored_at TEXT, earnings_date TEXT,
    has_transcript INTEGER DEFAULT 0, transcript_source TEXT, window TEXT,
    latency_hours REAL, total REAL, band TEXT, decision_summary TEXT,
    final INTEGER DEFAULT 0,
    PRIMARY KEY (symbol, fiscal_label, version)
);
-- ---------------------------------------------------------------------------
-- Trade journal
-- ---------------------------------------------------------------------------
-- One row per INTENT, not per fill. This matters: of the first 52 order rows,
-- 24 errored and 16 were cancelled — orders evaporating (IBKR down, approval
-- declined) is this system's most common real outcome, and a journal of fills
-- only would hide it completely.
CREATE TABLE IF NOT EXISTS journal_entries (
    entry_id TEXT PRIMARY KEY,            -- = trades.client_order_id
    cycle_id TEXT, as_of TEXT, symbol TEXT, action TEXT, source TEXT, setup TEXT,
    -- plan, pre-registered at decision time and never rewritten
    intended_notional REAL, intended_qty REAL, conviction REAL,
    order_type TEXT, limit_price REAL,
    stop_price REAL, target_price REAL, planned_horizon_days INTEGER,
    invalidation TEXT, planned_risk_usd REAL, risk_unit_source TEXT, rationale TEXT,
    -- regime SNAPSHOT (denormalised on purpose: a later review rewrite must not
    -- rewrite what we believed at the time)
    regime_risk_state TEXT,
    -- evidence quality — the agent-native "did I follow my plan"
    ev_score_total REAL, ev_score_band TEXT, ev_has_transcript INTEGER,
    ev_score_latency_h REAL, ev_expected_move_pct REAL,
    -- gates
    risk_notes_json TEXT,
    approval_status TEXT, approval_reviewer TEXT, approval_comment TEXT,
    approval_divergence TEXT,
    -- execution rollup
    submit_attempts INTEGER DEFAULT 0, terminal_status TEXT,
    filled_qty REAL, avg_fill_price REAL, slippage_bps REAL
);
-- Falsifiable claims, recorded when made. entry_id NULL = we predicted but did not
-- trade, which is exactly the sample that keeps calibration unbiased.
-- ref_date is the first session we could ACT on the claim (when the score was made),
-- NOT the print date. The earnings gap is not capturable — you cannot buy at the
-- pre-announcement close after seeing the result — and PEAD is by definition the
-- POST-announcement drift. print_date is kept alongside so the gap itself, a separate
-- and non-tradeable quantity, can still be measured.
CREATE TABLE IF NOT EXISTS predictions (
    prediction_id TEXT PRIMARY KEY, made_at TEXT, symbol TEXT,
    source TEXT, ref_key TEXT, kind TEXT,
    predicted_value REAL, predicted_band TEXT,
    ref_price REAL, ref_date TEXT, print_date TEXT,
    sector_etf TEXT, benchmark TEXT, entry_id TEXT
);
-- One row per horizon. All horizons are KEPT: short/long disagreement (right at
-- T+1, wrong at T+20 = right entry, wrong holding period) is the signal, not noise
-- to be collapsed into a single verdict.
CREATE TABLE IF NOT EXISTS prediction_outcomes (
    prediction_id TEXT, horizon_days INTEGER, as_of TEXT,
    realized_pct REAL, excess_vs_sector_pct REAL, excess_vs_bench_pct REAL,
    PRIMARY KEY (prediction_id, horizon_days)
);
-- One round trip: net position 0 -> nonzero -> back to 0. Adds/trims are LEGS of the
-- same episode, not new episodes — this is what fixes the old analytics counting a
-- scaled-out position as N trades. No separate episode_legs table: a leg IS a fill
-- plus which episode/entry it belongs to, so `fills.episode_id`/`fills.entry_id`
-- (below) carry that, and a second table would just be redundant (Occam).
CREATE TABLE IF NOT EXISTS trade_episodes (
    episode_id TEXT PRIMARY KEY, symbol TEXT, direction TEXT, origin TEXT,
    status TEXT,
    opened_at TEXT, closed_at TEXT, avg_entry REAL, avg_exit REAL,
    realized_pnl REAL, unrealized_pnl REAL, commission REAL, basis_source TEXT,
    holding_days INTEGER, r_multiple REAL, r_multiple_mtm REAL, risk_unit_source TEXT,
    mae_pct REAL, mfe_pct REAL, mae_source TEXT, excess_vs_sector_pct REAL,
    setup TEXT, primary_entry_id TEXT, exit_reason TEXT, exit_as_planned INTEGER,
    invalidation_triggered INTEGER, horizon_overdue_days INTEGER
);
-- Single-row bookkeeping, e.g. tracking_start_date: before it we did not observe,
-- which is NOT the same as "no trades happened".
CREATE TABLE IF NOT EXISTS journal_meta (key TEXT PRIMARY KEY, value TEXT);
CREATE INDEX IF NOT EXISTS idx_journal_symbol ON journal_entries(symbol);
CREATE INDEX IF NOT EXISTS idx_pred_symbol ON predictions(symbol);
CREATE INDEX IF NOT EXISTS idx_episode_symbol ON trade_episodes(symbol);
CREATE INDEX IF NOT EXISTS idx_insights_ticker ON research_insights(ticker);
CREATE INDEX IF NOT EXISTS idx_events_symbol ON pead_events(symbol);
CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol);
-- Chain evidence (docs/CHAIN_EVIDENCE.md). Not keyed by tradable symbol: an
-- observation is about an economic entity and a metric, and one fact can bear on
-- several claims across layers.
CREATE TABLE IF NOT EXISTS evidence_observations (
    id TEXT PRIMARY KEY, document_id TEXT, source_url TEXT,
    entity TEXT, source_entity TEXT, metric TEXT, concept TEXT, period TEXT,
    observation_type TEXT, stance TEXT, direction TEXT,
    value REAL, unit TEXT, evidence_span TEXT, observed_at TEXT,
    discovery_evidence INTEGER DEFAULT 0, extraction_confidence REAL DEFAULT 1.0
);
CREATE INDEX IF NOT EXISTS idx_obs_entity ON evidence_observations(entity, metric);
CREATE INDEX IF NOT EXISTS idx_obs_at ON evidence_observations(observed_at);
-- Failed extractions are kept: "could not read" and "says nothing" are different
-- states, and only the second may influence a verdict.
CREATE TABLE IF NOT EXISTS evidence_failures (
    document_id TEXT, entity TEXT, reason TEXT, at TEXT,
    PRIMARY KEY (document_id, entity)
);
-- Primary-source inventory. METADATA ONLY — the prose lives in `信息源/` where it can be
-- opened, searched and corrected by hand; copying it here would buy nothing a path does
-- not already give. What the table does buy: idempotence (skip a fetch), provenance
-- (which file did this observation come from), and an honest coverage report (who in the
-- witness roster we hold nothing for). `ok=0` rows are fetches that failed a guard —
-- kept on purpose so a wrong document is paid for once and never retried blindly.
CREATE TABLE IF NOT EXISTS source_documents (
    document_id TEXT PRIMARY KEY, entity TEXT, period TEXT, doc_type TEXT,
    source TEXT, source_url TEXT, local_path TEXT, sha256 TEXT,
    chars INTEGER, ok INTEGER DEFAULT 1, note TEXT, fetched_at TEXT,
    external_id TEXT, title TEXT, published_at TEXT,
    completeness TEXT DEFAULT 'full', truncation_reason TEXT, carrier_format TEXT,
    mime_source TEXT
);
CREATE INDEX IF NOT EXISTS idx_srcdoc_entity ON source_documents(entity, period);
-- Every automatically discovered body first lands here as an auditable candidate.
-- Accepted rows point at source_documents; quarantined rows may point at an isolated
-- raw file but never acquire a document version/chunk and are invisible by default.
CREATE TABLE IF NOT EXISTS document_candidates (
    candidate_id TEXT PRIMARY KEY, document_id TEXT, status TEXT,
    expected_entity TEXT, claimed_entity TEXT, target_period TEXT, claimed_period TEXT,
    expected_semantic TEXT, claimed_semantic TEXT, carrier_format TEXT,
    completeness TEXT, source TEXT, source_url TEXT, external_id TEXT, title TEXT,
    published_at TEXT, discovered_at TEXT, content_hash TEXT, chars INTEGER,
    raw_path TEXT, reason_codes TEXT, validation_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_doccandidate_status
    ON document_candidates(status, source, discovered_at);
CREATE TABLE IF NOT EXISTS earnings_events (
    event_id TEXT PRIMARY KEY, entity TEXT, report_date TEXT,
    fiscal_year INTEGER, fiscal_quarter INTEGER, status TEXT,
    evidence_json TEXT, conflicts_json TEXT, resolved_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_earnings_event_entity
    ON earnings_events(entity, report_date);
CREATE TABLE IF NOT EXISTS newsletter_cursors (
    mailbox TEXT, folder TEXT, sender TEXT, uidvalidity TEXT, last_uid INTEGER,
    last_message_id TEXT, watermark TEXT, updated_at TEXT,
    PRIMARY KEY (mailbox, folder, sender)
);
-- Immutable content versions behind the mutable source_documents inventory row.
-- A logical document may be corrected by its publisher or re-fetched after a parser
-- change; old bytes remain addressable so every downstream result can name the exact
-- input it used.
CREATE TABLE IF NOT EXISTS document_versions (
    version_id TEXT PRIMARY KEY, document_id TEXT, content_hash TEXT,
    local_path TEXT, chars INTEGER, source_url TEXT, fetched_at TEXT, created_at TEXT,
    UNIQUE(document_id, content_hash)
);
CREATE INDEX IF NOT EXISTS idx_docver_document
    ON document_versions(document_id, fetched_at);
-- One source asset may concern several companies. This association is catalog
-- metadata, not an extracted claim: it enables company-scoped discovery without
-- copying the publisher-owned body once per ticker.
CREATE TABLE IF NOT EXISTS document_entities (
    document_id TEXT, entity TEXT, relation TEXT DEFAULT 'mentioned',
    PRIMARY KEY (document_id, entity, relation)
);
CREATE INDEX IF NOT EXISTS idx_document_entity ON document_entities(entity, document_id);
-- Alternate provider identities for the same real-world story. This prevents Yahoo,
-- Finnhub and IBKR copies from becoming separate logical documents while preserving
-- every provider's provenance.
CREATE TABLE IF NOT EXISTS document_source_aliases (
    alias_id TEXT PRIMARY KEY, document_id TEXT, source TEXT, source_url TEXT,
    external_id TEXT, title TEXT, published_at TEXT, metadata_json TEXT, created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_document_alias_doc
    ON document_source_aliases(document_id, source);
CREATE TABLE IF NOT EXISTS document_chunks (
    chunk_id TEXT PRIMARY KEY, version_id TEXT, ordinal INTEGER,
    char_start INTEGER, char_end INTEGER, text TEXT, content_hash TEXT,
    UNIQUE(version_id, ordinal)
);
CREATE INDEX IF NOT EXISTS idx_chunk_version ON document_chunks(version_id, ordinal);
-- Per-consumer processing ledger. The processor version is part of the identity:
-- changing a prompt/model/schema is a legitimate reprocessing run, while a scheduler
-- retry of the same version must not spend money twice. Failed runs remain explicit;
-- they can be retried only by a new processor version or an intentional reset.
CREATE TABLE IF NOT EXISTS document_processing_runs (
    version_id TEXT, consumer TEXT, processor_version TEXT,
    status TEXT, started_at TEXT, completed_at TEXT,
    outputs INTEGER DEFAULT 0, note TEXT,
    PRIMARY KEY (version_id, consumer, processor_version)
);
CREATE INDEX IF NOT EXISTS idx_docproc_consumer
    ON document_processing_runs(consumer, status, completed_at);
CREATE TABLE IF NOT EXISTS data_migrations (
    key TEXT PRIMARY KEY, applied_at TEXT, note TEXT
);
-- Structured source catalog and immutable point vintages. Derived changes (yoy/mom,
-- thresholds, z-scores) do not live here; they are recomputed from accepted values.
CREATE TABLE IF NOT EXISTS data_sources (
    source_id TEXT PRIMARY KEY, kind TEXT, label TEXT, adapter TEXT,
    cadence TEXT, entity TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS ingestion_runs (
    run_id TEXT PRIMARY KEY, source_id TEXT, kind TEXT,
    started_at TEXT, completed_at TEXT, status TEXT,
    discovered INTEGER DEFAULT 0, accepted INTEGER DEFAULT 0,
    quarantined INTEGER DEFAULT 0, reason_codes TEXT,
    snapshot_updated_at TEXT, snapshot_lag_hours REAL, note TEXT
);
CREATE INDEX IF NOT EXISTS idx_ingestion_source
    ON ingestion_runs(source_id, started_at);
CREATE TABLE IF NOT EXISTS measurement_series (
    series_id TEXT PRIMARY KEY, source_id TEXT, series TEXT,
    label TEXT, entity TEXT, unit TEXT, cadence TEXT, updated_at TEXT,
    UNIQUE(source_id, series)
);
CREATE TABLE IF NOT EXISTS measurement_points (
    point_id TEXT PRIMARY KEY, series_id TEXT, period TEXT,
    value REAL, unit TEXT, published_at TEXT, fetched_at TEXT,
    content_hash TEXT, raw_payload TEXT,
    UNIQUE(series_id, period, content_hash)
);
CREATE INDEX IF NOT EXISTS idx_measurement_period
    ON measurement_points(series_id, period, fetched_at);
-- Neutral, re-checkable facts are shared. Their task interpretation is a separate,
-- versioned projection so PEAD, evidence and sector views cannot overwrite each other.
CREATE TABLE IF NOT EXISTS evidence_facts (
    fact_id TEXT PRIMARY KEY, document_id TEXT, document_version_id TEXT, source_url TEXT,
    entity TEXT, source_entity TEXT, metric TEXT, period TEXT,
    observation_type TEXT, value REAL, unit TEXT, evidence_span TEXT,
    observed_at TEXT, extraction_confidence REAL DEFAULT 1.0,
    discovery_evidence INTEGER DEFAULT 0, superseded_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_fact_entity ON evidence_facts(entity, metric);
CREATE INDEX IF NOT EXISTS idx_fact_document ON evidence_facts(document_id, source_entity);
CREATE TABLE IF NOT EXISTS evidence_fact_projections (
    projection_id TEXT PRIMARY KEY, fact_id TEXT, legacy_observation_id TEXT,
    profile TEXT, profile_version TEXT, concept TEXT, stance TEXT, direction TEXT,
    payload TEXT, created_at TEXT, superseded_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_fact_projection
    ON evidence_fact_projections(profile, profile_version, concept, fact_id);
CREATE TABLE IF NOT EXISTS task_projections (
    projection_id TEXT PRIMARY KEY, profile TEXT, profile_version TEXT,
    input_kind TEXT, input_ref TEXT, target_type TEXT, target_id TEXT,
    payload TEXT, created_at TEXT, expires_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_task_projection
    ON task_projections(profile, target_type, target_id, created_at);
-- Unified agent-output envelope (see ats.agent.task_projection). Independent from
-- `task_projections` on purpose: that table models evidence fact projections keyed by
-- profile/target, which is a different abstraction. This one is additive only —
-- `task_projections` keeps its columns, its readers and its results.
CREATE TABLE IF NOT EXISTS task_projection_envelopes (
    projection_id TEXT PRIMARY KEY,
    workflow_run_id TEXT, agent_run_id TEXT, agent_role TEXT,
    scope_kind TEXT, scope_id TEXT,
    as_of TEXT, valid_until TEXT,
    schema_name TEXT, schema_version TEXT,
    input_refs TEXT, data_vintage_refs TEXT,
    model_version TEXT, prompt_version TEXT,
    payload TEXT, content_hash TEXT, status TEXT,
    created_at TEXT, supersedes_projection_id TEXT
);
-- Content identity: a retry carrying the same role/scope/inputs/payload must not
-- produce a second row, and a changed input must be allowed to.
CREATE UNIQUE INDEX IF NOT EXISTS idx_envelope_content
    ON task_projection_envelopes(agent_role, scope_kind, scope_id, content_hash);
CREATE INDEX IF NOT EXISTS idx_envelope_lookup
    ON task_projection_envelopes(agent_role, scope_kind, scope_id, created_at);
CREATE INDEX IF NOT EXISTS idx_envelope_run
    ON task_projection_envelopes(workflow_run_id, agent_role);
-- Propositions the system induced but a human has not adopted. Deliberately a
-- separate table from claims: agents propose, only a person extends the axes.
CREATE TABLE IF NOT EXISTS claim_proposals (
    id TEXT PRIMARY KEY, signature TEXT, statement TEXT, layer_hint TEXT,
    kind TEXT, subject TEXT, status TEXT, created_at TEXT,
    reviewed_at TEXT, reviewer TEXT, rationale TEXT, payload TEXT
);
CREATE INDEX IF NOT EXISTS idx_proposal_sig ON claim_proposals(signature, status);
CREATE TABLE IF NOT EXISTS claim_assessments (
    claim_id TEXT, as_of TEXT, layer TEXT, verdict TEXT,
    support_score REAL, refute_score REAL, evidence_clusters INTEGER,
    stance_classes INTEGER, witnesses_expected INTEGER, witnesses_reported INTEGER,
    payload TEXT,
    PRIMARY KEY (claim_id, as_of)
);
"""

# ---------------------------------------------------------------------------
# Decision audit (docs/TARGET_WORKFLOW_DATAFLOW.md §12.3, Phase B).
# Five additive tables; no legacy table or column is touched. Kept as a separate
# module constant so `_migrate` can re-apply exactly this fragment on databases
# created before Phase B. Notes on the shape:
# - `decision_risk_reviews` is deliberately NOT the portfolio-level `risk_reviews`
#   (whose `as_of` primary key keeps its original semantics); decision-level
#   reviews are keyed to one revision hash.
# - `revision_source` marks how a revision came to exist: `chief` (produced by
#   the loop), `legacy_revision` (migrated, content fully recoverable) or
#   `legacy_unknown` (migrated with gaps — such a revision must never obtain
#   execution authorization).
# - `boss_approvals.idempotency_key` and `cycle_events.idempotency_key` are
#   UNIQUE: a replayed callback or a retried transition must land on the record
#   it already produced, never a second one. Keys exclude the request moment
#   (same principle as `TriggerContext.idempotency_key`).
# ---------------------------------------------------------------------------
_DECISION_AUDIT_DDL = """
CREATE TABLE IF NOT EXISTS decision_cycles (
    cycle_id TEXT PRIMARY KEY,
    trigger_source TEXT, trigger_id TEXT,
    research_snapshot TEXT,
    status TEXT,
    current_revision_no INTEGER,
    final_outcome TEXT,
    superseded_reason TEXT,
    created_at TEXT, updated_at TEXT
);
CREATE TABLE IF NOT EXISTS decision_revisions (
    cycle_id TEXT, revision_no INTEGER,
    decision_hash TEXT,
    parent_revision_no INTEGER,
    orders_json TEXT,
    rationale TEXT,
    input_refs TEXT,
    model_version TEXT, prompt_version TEXT,
    revision_source TEXT,
    legacy_ref TEXT,
    created_at TEXT,
    PRIMARY KEY (cycle_id, revision_no)
);
-- Same content resubmitted within one cycle is a no-op, not a new revision.
CREATE UNIQUE INDEX IF NOT EXISTS idx_decision_revision_hash
    ON decision_revisions(cycle_id, decision_hash);
CREATE INDEX IF NOT EXISTS idx_decision_revision_cycle
    ON decision_revisions(cycle_id, revision_no);
CREATE TABLE IF NOT EXISTS decision_risk_reviews (
    review_id TEXT PRIMARY KEY,
    cycle_id TEXT, revision_no INTEGER, decision_hash TEXT,
    ruleset_version TEXT,
    portfolio_snapshot_id TEXT, market_as_of TEXT,
    verdict TEXT,
    violations_json TEXT, allowed_boundary_json TEXT,
    before_metrics_json TEXT, after_metrics_json TEXT,
    notes TEXT, created_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_decision_review_revision
    ON decision_risk_reviews(cycle_id, revision_no);
CREATE TABLE IF NOT EXISTS boss_approvals (
    approval_id TEXT PRIMARY KEY,
    cycle_id TEXT, revision_no INTEGER, decision_hash TEXT,
    decision TEXT, reviewer TEXT, comment TEXT, channel TEXT,
    idempotency_key TEXT NOT NULL,
    created_at TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_boss_approvals_idempotency
    ON boss_approvals(idempotency_key);
CREATE TABLE IF NOT EXISTS cycle_events (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    cycle_id TEXT, event_type TEXT, actor TEXT,
    from_status TEXT, to_status TEXT,
    idempotency_key TEXT NOT NULL,
    payload TEXT, error TEXT,
    created_at TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_cycle_events_idempotency
    ON cycle_events(cycle_id, idempotency_key);
CREATE INDEX IF NOT EXISTS idx_cycle_events_cycle
    ON cycle_events(cycle_id, created_at);
"""

_CLERK_LEDGER_DDL = """
-- Phase C (§11): the Clerk/ledger tables. Every column except the primary key
-- is nullable BY RULING (design D3): history rows, manual orders and
-- unattributable fills have no decision chain to fill, and a NOT NULL would
-- force fabricated values. Enforcement lives in write paths, not the schema.
CREATE TABLE IF NOT EXISTS ledger_exceptions (
    exception_id TEXT PRIMARY KEY,        -- deterministic: kind + subject + window
    kind TEXT,                            -- unattributed_fill / broken_link /
                                          -- reconciliation_gap / position_cash_discrepancy /
                                          -- attempt_count_mismatch
    subject_key TEXT,                     -- what the exception is about (fill id, window, symbol)
    cycle_id TEXT, symbol TEXT,
    window_start TEXT, window_end TEXT, as_of TEXT,
    basis TEXT,                           -- evidence / reasoning behind the exception
    detail_json TEXT,                     -- both sides' values, broker identities, etc.
    status TEXT,                          -- open / resolved
    first_seen_at TEXT, last_seen_at TEXT, resolved_at TEXT,
    created_at TEXT, updated_at TEXT
);
-- Same exception rediscovered is an update of last_seen, not a second row.
CREATE UNIQUE INDEX IF NOT EXISTS idx_ledger_exceptions_subject
    ON ledger_exceptions(kind, subject_key);
CREATE INDEX IF NOT EXISTS idx_ledger_exceptions_kind
    ON ledger_exceptions(kind, status);
CREATE TABLE IF NOT EXISTS clerk_runs (
    run_id TEXT PRIMARY KEY,              -- idempotency key: kind+window+as_of, no request moment
    kind TEXT,                            -- reconcile / marks / episodes / predictions / performance / full
    window_start TEXT, window_end TEXT, as_of TEXT,
    status TEXT,                          -- running / completed / failed
    counts_json TEXT, error TEXT,
    started_at TEXT, finished_at TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_clerk_runs_window
    ON clerk_runs(kind, window_start, window_end, as_of);
CREATE TABLE IF NOT EXISTS ledger_read_models (
    model_id TEXT PRIMARY KEY,            -- kind + period + method_version
    kind TEXT,                            -- performance / attribution
    period TEXT, as_of TEXT,
    method_version TEXT, source_facts_hash TEXT,
    payload TEXT, rebuilt_at TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_ledger_read_models_key
    ON ledger_read_models(kind, period, method_version);
CREATE INDEX IF NOT EXISTS idx_ledger_read_models_asof
    ON ledger_read_models(kind, as_of);
"""

_SCHEMA = _BASE_SCHEMA + _DECISION_AUDIT_DDL + _CLERK_LEDGER_DDL

_DECISION_AUDIT_TABLES = frozenset({
    "decision_cycles", "decision_revisions", "decision_risk_reviews",
    "boss_approvals", "cycle_events",
})

_CLERK_LEDGER_TABLES = frozenset({
    "ledger_exceptions", "clerk_runs", "ledger_read_models",
})


class TradingMemory:
    def __init__(self, db_path: str | Path, *, initialize: bool = True):
        self.path = str(db_path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        # Cached CLI/server instances retain their historic cross-thread behavior.
        # Dispatcher workers use ``initialize=False`` and receive one connection per
        # task, created and consumed on that task's thread.
        self.conn = sqlite3.connect(self.path, check_same_thread=not initialize, timeout=30)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA busy_timeout=30000")
        if self.path != ":memory:":
            self.conn.execute("PRAGMA journal_mode=WAL")
        # Set before any migration runs: `_migrate` reaches into the data layer (to
        # resolve document versions for the legacy backfill), and the delegation
        # helpers read this cache.
        self._data: object | None = None
        self._closed = False
        self._task_scoped = not initialize
        if initialize:
            self.initialize()

    def initialize(self) -> None:
        """Run the legacy schema bootstrap and migrations explicitly.

        This includes a deliberate retirement of data-owned tables, so it must run
        at process/bootstrap time only, never when a task-local connection opens.
        """
        self.conn.executescript(_SCHEMA)
        self._migrate()
        self._retire_data_tables()
        self._verify_data_layer_write_targets()

    # --- data-layer delegation ------------------------------------------ #
    # Every table retired above must have a twin here. Checked at INIT time, not at
    # first write: `sqlite3.OperationalError: no such table: evidence_observations`
    # surfaced deep inside a scheduled run, weeks after the boundary decision that
    # caused it, and 86% of the suite's failures were that one mismatch.
    def _writes_redirected_to_data_layer(self) -> tuple[str, ...]:
        return ("data_evidence_observations", "data_evidence_facts",
                "data_evidence_projections", "data_evidence_failures",
                "data_documents", "data_document_versions",
                "data_document_processing_runs", "data_document_candidates",
                "data_ingestion_runs", "data_newsletter_cursors",
                "data_measurement_series", "data_measurement_points")

    def _verify_data_layer_write_targets(self) -> None:
        """Fail at construction when the boundary disagrees with the write targets.

        `_retire_data_tables` is a decision about OWNERSHIP, not just about which
        tables this database happens to keep. If the data layer cannot produce the
        twin a delegated writer needs, the honest answer is to refuse to open rather
        than to accept writes that will fail at run time.
        """
        present = {row["name"] for row in self.data_store().conn.execute(
            "SELECT name FROM sqlite_master WHERE type IN ('table','view')")}
        missing = [t for t in self._writes_redirected_to_data_layer() if t not in present]
        if missing:
            raise RuntimeError(
                "Workflow memory retires these tables but the data layer has no twin "
                f"for them: {', '.join(missing)}. Boundary classification and write "
                "targets disagree — fix the data-layer schema or the retirement list.")

    def data_store(self):
        """The data-layer repository that owns the tables this database retires.

        The boundary decision (`_retire_data_tables`) makes Workflow memory a store of
        opinionated conclusions only. Neutral evidence facts, documents, candidates,
        cursors and ingestion bookkeeping live in the data layer, so every method that
        used to read or write the retired tables delegates here instead of reaching for
        a table that no longer exists. Cached per instance because the repository owns
        its own SQLite connection; instances are rebuilt whenever the DB path changes.
        """
        if self._data is None:
            from ..data.stores.unstructured.platform import get_platform_unstructured_store

            self._data = get_platform_unstructured_store()
        return self._data

    def _retire_data_tables(self) -> None:
        """Enforce the boundary: this database is Workflow memory, never a data store."""
        views = ("structured_observations_selected", "structured_observations_accepted")
        tables = (
            "structured_artifact_blobs", "structured_artifacts", "structured_sources",
            "structured_datasets", "structured_metrics", "structured_provider_mappings",
            "structured_pending_mappings", "structured_series", "structured_observations",
            "structured_derivations", "structured_evidence_links", "structured_entities",
            "structured_events", "structured_evidence_candidates", "structured_evidence_reviews",
            "structured_snapshots", "structured_snapshot_items", "structured_ingestion_runs",
            "structured_candidates", "structured_conflicts", "structured_legacy_audits",
            "structured_migrations", "source_documents", "document_candidates",
            "document_versions", "document_entities", "document_source_aliases",
            "document_chunks", "document_processing_runs", "newsletter_cursors",
            "data_sources", "ingestion_runs", "measurement_series", "measurement_points",
            "evidence_observations", "evidence_failures", "evidence_facts",
            "evidence_fact_projections",
        )
        self.conn.execute("PRAGMA foreign_keys=OFF")
        for name in views:
            self.conn.execute(f'DROP VIEW IF EXISTS "{name}"')
        for name in tables:
            self.conn.execute(f'DROP TABLE IF EXISTS "{name}"')
        self.conn.commit()

    def _migrate(self) -> None:
        """Additive column migrations (kept out of _SCHEMA so old DBs get them too)."""
        cols = {r["name"] for r in self.conn.execute("PRAGMA table_info(pead_events)")}
        for ddl in ("triage_score REAL", "triage_category TEXT"):
            if ddl.split()[0] not in cols:
                self.conn.execute(f"ALTER TABLE pead_events ADD COLUMN {ddl}")
        tcols = {r["name"] for r in self.conn.execute("PRAGMA table_info(trades)")}
        for ddl in ("limit_price REAL", "filled_at TEXT", "error TEXT",
                    "realized_pnl REAL", "source TEXT", "context TEXT"):
            if ddl.split()[0] not in tcols:
                self.conn.execute(f"ALTER TABLE trades ADD COLUMN {ddl}")
        scols = {r["name"] for r in self.conn.execute("PRAGMA table_info(pead_score_runs)")}
        if scols and "final" not in scols:
            # Pre-existing rows were all transcript-backed scores, so they are final.
            self.conn.execute("ALTER TABLE pead_score_runs ADD COLUMN final INTEGER DEFAULT 0")
            self.conn.execute("UPDATE pead_score_runs SET final = has_transcript")
        # Journal linkage. `client_order_id` is the idempotency key; `perm_id` /
        # `order_ref` are the durable broker identities (orderId is a per-client
        # sequence that TWS resets, so it cannot be joined on across days).
        # NOTE: `trades.entry_id` below is dead weight — client_order_id IS the
        # JournalEntry id by construction (see JournalEntry docstring), so nothing
        # ever needed a second column for it. Left in place rather than dropped:
        # SQLite column drops require a full table rebuild for zero benefit on an
        # already-deployed table. Use client_order_id, not this column.
        for ddl in ("client_order_id TEXT", "perm_id TEXT", "order_ref TEXT",
                    "attempt INTEGER DEFAULT 1", "entry_id TEXT", "first_submitted_at TEXT",
                    "order_seq INTEGER"):
            if ddl.split()[0] not in tcols:
                self.conn.execute(f"ALTER TABLE trades ADD COLUMN {ddl}")
        fcols = {r["name"] for r in self.conn.execute("PRAGMA table_info(fills)")}
        for ddl in ("perm_id TEXT", "order_ref TEXT", "origin TEXT",
                    "link_confidence TEXT", "captured_at TEXT",
                    "entry_id TEXT", "episode_id TEXT",
                    "late_backfill INTEGER"):
            if ddl.split()[0] not in fcols:
                self.conn.execute(f"ALTER TABLE fills ADD COLUMN {ddl}")
        # Phase C compensation semantics (§11, tasks 3.1/3.4): filled_qty backs
        # the cumulative partial-fill accounting; terminal_basis separates a
        # broker-reported terminal state from an inferred one.
        for ddl in ("filled_qty REAL", "terminal_basis TEXT"):
            if ddl.split()[0] not in tcols:
                self.conn.execute(f"ALTER TABLE trades ADD COLUMN {ddl}")
        # §11.2 (task 7.1): LLM annotations carry provenance — additive on the
        # episodes table so old rows simply read as "no LLM judgement yet".
        ecols = {r["name"] for r in self.conn.execute(
            "PRAGMA table_info(trade_episodes)")}
        for ddl in ("invalidation_source TEXT", "invalidation_checked_at TEXT"):
            if ecols and ddl.split()[0] not in ecols:
                self.conn.execute(f"ALTER TABLE trade_episodes ADD COLUMN {ddl}")
        # Decision-audit linkage (§12.3, Phase B). Nullable on purpose: forcing
        # them non-null on every new order is Phase C's cutover, after all new
        # orders flow through the authorization gate. `trades.cycle_id` already
        # exists (original column); `fills` gets the full quadruple.
        for ddl in ("revision_no INTEGER", "decision_hash TEXT", "approval_id TEXT"):
            if ddl.split()[0] not in tcols:
                self.conn.execute(f"ALTER TABLE trades ADD COLUMN {ddl}")
        for ddl in ("cycle_id TEXT", "revision_no INTEGER", "decision_hash TEXT",
                    "approval_id TEXT"):
            if ddl.split()[0] not in fcols:
                self.conn.execute(f"ALTER TABLE fills ADD COLUMN {ddl}")
        self.conn.execute("CREATE INDEX IF NOT EXISTS idx_trades_decision "
                          "ON trades(cycle_id, revision_no)")
        self.conn.execute("CREATE INDEX IF NOT EXISTS idx_fills_decision "
                          "ON fills(cycle_id, revision_no)")
        # Any column added to a table that already exists in the wild needs an ALTER —
        # CREATE TABLE IF NOT EXISTS in _SCHEMA is a no-op on an existing table.
        pcols = {r["name"] for r in self.conn.execute("PRAGMA table_info(predictions)")}
        if pcols and "print_date" not in pcols:
            self.conn.execute("ALTER TABLE predictions ADD COLUMN print_date TEXT")
        # NULLs are distinct in a SQLite unique index, so the 52 legacy rows (which
        # have no client_order_id) coexist with the constraint.
        self.conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_trades_coid "
                          "ON trades(client_order_id)")
        ocols = {r["name"] for r in self.conn.execute(
            "PRAGMA table_info(evidence_observations)")}
        for ddl in ("concept TEXT", "source_entity TEXT", "superseded_at TEXT"):
            if ocols and ddl.split()[0] not in ocols:
                self.conn.execute(
                    f"ALTER TABLE evidence_observations ADD COLUMN {ddl}")
        dcols = {r["name"] for r in self.conn.execute("PRAGMA table_info(source_documents)")}
        for ddl in ("external_id TEXT", "title TEXT", "published_at TEXT",
                    "completeness TEXT DEFAULT 'full'", "truncation_reason TEXT",
                    "carrier_format TEXT", "mime_source TEXT"):
            if dcols and ddl.split()[0] not in dcols:
                self.conn.execute(f"ALTER TABLE source_documents ADD COLUMN {ddl}")
        rcols = {r["name"] for r in self.conn.execute("PRAGMA table_info(ingestion_runs)")}
        for ddl in ("quarantined INTEGER DEFAULT 0", "reason_codes TEXT",
                    "snapshot_updated_at TEXT", "snapshot_lag_hours REAL"):
            if rcols and ddl.split()[0] not in rcols:
                self.conn.execute(f"ALTER TABLE ingestion_runs ADD COLUMN {ddl}")
        fact_cols = {r["name"] for r in self.conn.execute("PRAGMA table_info(evidence_facts)")}
        if fact_cols and "document_version_id" not in fact_cols:
            self.conn.execute("ALTER TABLE evidence_facts ADD COLUMN document_version_id TEXT")
        # Existing deployments already have the latest logical-document inventory.
        # Promote rows with a real content hash into the immutable version catalog;
        # failed fetches deliberately have no version because no accepted bytes exist.
        #
        # The catalog is data-layer-owned, so this promotion is a cross-store write:
        # inserting locally would land in a table `_retire_data_tables()` drops a few
        # lines later, and the legacy inventory would silently vanish on upgrade.
        legacy_versions = self.conn.execute(
            "SELECT document_id, sha256, local_path, chars, source_url, fetched_at "
            "FROM source_documents WHERE ok = 1 AND sha256 IS NOT NULL AND sha256 != ''"
        ).fetchall()
        legacy_entities = self.conn.execute(
            "SELECT document_id, upper(entity) AS entity FROM source_documents "
            "WHERE entity IS NOT NULL AND entity != ''").fetchall()
        if legacy_versions or legacy_entities:
            data = self.data_store()
            data.conn.executemany(
                "INSERT OR IGNORE INTO data_document_versions "
                "(version_id,document_id,content_hash,local_path,chars,source_url,"
                " fetched_at,created_at) VALUES (?,?,?,?,?,?,?,?)",
                [(f"{row['document_id']}@{row['sha256'][:16]}", row["document_id"],
                  row["sha256"], row["local_path"] or "", row["chars"] or 0,
                  row["source_url"] or "", row["fetched_at"] or "",
                  row["fetched_at"] or "") for row in legacy_versions])
            data.conn.executemany(
                "INSERT OR IGNORE INTO data_document_entities (document_id,entity,relation) "
                "VALUES (?,?,'primary')",
                [(row["document_id"], row["entity"]) for row in legacy_entities])
            data.conn.commit()
        # One-time compatibility bridge: before the processing ledger existed,
        # presence in source_documents was the chain consumer's paid/read marker.
        # Never repeat this backfill, or documents acquired later for PEAD would be
        # incorrectly marked as already observed by chain after a process restart.
        migration = "document_processing_chain_v1"
        done = self.conn.execute(
            "SELECT 1 FROM data_migrations WHERE key = ?", (migration,)).fetchone()
        if not done:
            stamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
            # Scope the seen-set to THIS database's legacy inventory. The data layer is
            # shared, so a blanket backfill over every known version would mark other
            # workflows' documents as chain-seen too.
            legacy_ids = [row["document_id"] for row in self.conn.execute(
                "SELECT document_id FROM source_documents").fetchall()]
            data = self.data_store()
            if legacy_ids:
                placeholders = ",".join("?" * len(legacy_ids))
                versions = data.conn.execute(
                    "SELECT version_id, created_at FROM data_document_versions "
                    f"WHERE document_id IN ({placeholders})", legacy_ids).fetchall()
                data.conn.executemany(
                    "INSERT OR IGNORE INTO data_document_processing_runs "
                    "(version_id,consumer,processor_version,status,started_at,"
                    " completed_at,outputs,note) VALUES (?,'chain','chain-observer-v1',"
                    " 'succeeded',?,?,0,'migrated from source_documents')",
                    [(row["version_id"], row["created_at"], row["created_at"])
                     for row in versions])
                data.conn.commit()
            self.conn.execute(
                "INSERT INTO data_migrations (key,applied_at,note) VALUES (?,?,?)",
                (migration, stamp, "legacy source_documents were chain seen-set"))
        self._migrate_shared_facts()
        self._migrate_pead_events_pk()
        self._migrate_decision_audit_tables()
        self._migrate_clerk_ledger_tables()
        self._register_legacy_link_gaps()
        self._migrate_legacy_decisions()
        self.conn.commit()

    def _migrate_shared_facts(self) -> None:
        """One-time additive split of legacy observations into facts + projections."""
        import hashlib
        import json

        key = "shared_facts_v1"
        if self.conn.execute("SELECT 1 FROM data_migrations WHERE key=?", (key,)).fetchone():
            return
        rows = self.conn.execute("SELECT * FROM evidence_observations").fetchall()
        # Facts and their projections are data-layer-owned now. Writing them back into
        # the local (retired) tables would make the upgrade look successful while the
        # rows are dropped before anyone can read them.
        data = self.data_store()
        for row in rows:
            raw = f"{row['document_id']}|{(row['entity'] or '').upper()}|" \
                  f"{(row['metric'] or '').lower()}|{row['period'] or ''}"
            fact_id = hashlib.sha1(raw.encode()).hexdigest()[:20]
            version = self.latest_document_version(row["document_id"])
            data.conn.execute(
                "INSERT OR REPLACE INTO data_evidence_facts "
                "(fact_id,document_id,document_version_id,source_url,entity,source_entity,metric,period,"
                " observation_type,value,unit,evidence_span,observed_at,"
                " extraction_confidence,discovery_evidence,superseded_at) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (fact_id, row["document_id"], version["version_id"] if version else "",
                 row["source_url"], row["entity"],
                 row["source_entity"], row["metric"], row["period"],
                 row["observation_type"], row["value"], row["unit"],
                 row["evidence_span"], row["observed_at"], row["extraction_confidence"],
                 row["discovery_evidence"], row["superseded_at"]))
            projection_id = hashlib.sha1(
                f"{row['id']}|legacy-evidence|v1".encode()).hexdigest()[:20]
            payload = json.dumps({"migrated": True}, ensure_ascii=False)
            data.conn.execute(
                "INSERT OR REPLACE INTO data_evidence_projections "
                "(projection_id,fact_id,legacy_observation_id,profile,profile_version,"
                " concept,stance,direction,payload,created_at,superseded_at) "
                "VALUES (?,?,?,'legacy-evidence','v1',?,?,?,?,?,?)",
                (projection_id, fact_id, row["id"], row["concept"], row["stance"],
                 row["direction"], payload, row["observed_at"], row["superseded_at"]))
        data.conn.commit()
        stamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
        self.conn.execute(
            "INSERT INTO data_migrations (key,applied_at,note) VALUES (?,?,?)",
            (key, stamp, f"migrated {len(rows)} legacy observations"))

    def _migrate_pead_events_pk(self) -> None:
        """pead_events: global `id` PK -> composite (symbol, id).

        The same news item is legitimately relevant to several targets — a peer's
        headline is fetched once per target that lists it in `signal_chain`. Under a
        global PK only the FIRST target to fetch it could store it; every other target
        silently saw nothing that round (AMZN sits in 6 targets' signal chains, so 5 of
        them lost it). Rebuild is required: SQLite cannot ALTER a PRIMARY KEY.

        Idempotent — detects the old shape and does nothing once migrated.
        """
        info = list(self.conn.execute("PRAGMA table_info(pead_events)"))
        if not info:
            return                                   # fresh DB: _SCHEMA already correct
        pk_cols = {r["name"] for r in info if r["pk"]}
        if pk_cols == {"symbol", "id"}:
            return                                   # already migrated
        cols = [r["name"] for r in info]             # preserve ALTER-added columns
        collist = ",".join(cols)
        log.info("migrating pead_events to composite PK (symbol, id)")
        self.conn.executescript(f"""
            CREATE TABLE pead_events__new (
                id TEXT, symbol TEXT, published_at TEXT, source TEXT,
                headline TEXT, url TEXT, processed INTEGER DEFAULT 0,
                triage_score REAL, triage_category TEXT,
                PRIMARY KEY (symbol, id)
            );
            INSERT OR IGNORE INTO pead_events__new ({collist})
                SELECT {collist} FROM pead_events;
            DROP TABLE pead_events;
            ALTER TABLE pead_events__new RENAME TO pead_events;
            CREATE INDEX IF NOT EXISTS idx_pead_events ON pead_events(symbol, published_at);
        """)

    def _migrate_decision_audit_tables(self) -> None:
        """Additive completion of the §12.3 decision-audit tables.

        A fresh database already gets them from `_SCHEMA`; a database created
        before Phase B ran an older script, so the migration re-applies exactly
        the `_DECISION_AUDIT_DDL` fragment. CREATE IF NOT EXISTS keeps it
        idempotent and no legacy column or table is touched.
        """
        present = {r["name"] for r in self.conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        if not _DECISION_AUDIT_TABLES <= present:
            self.conn.executescript(_DECISION_AUDIT_DDL)

    def _migrate_clerk_ledger_tables(self) -> None:
        """Additive completion of the §11 Clerk/ledger tables (Phase C).

        Same pattern as `_migrate_decision_audit_tables`: a pre-Phase-C database
        re-applies the `_CLERK_LEDGER_DDL` fragment; CREATE IF NOT EXISTS keeps
        it idempotent and no legacy column or table is touched.
        """
        present = {r["name"] for r in self.conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        if not _CLERK_LEDGER_TABLES <= present:
            self.conn.executescript(_CLERK_LEDGER_DDL)

    def _register_legacy_link_gaps(self) -> None:
        """One-time §11 backfill (task 2.3): pre-Phase-C system orders whose
        decision chain cannot be recovered become explicit `broken_link`
        exceptions. Linkage columns stay empty — fabricating a chain is worse
        than an honest gap (design D3). Manual/standalone rows are NOT gaps:
        they never had a chain by nature.
        """
        key = "ledger_legacy_gaps_v1"
        if self.conn.execute(
                "SELECT 1 FROM data_migrations WHERE key=?", (key,)).fetchone():
            return
        cols = {r["name"] for r in self.conn.execute("PRAGMA table_info(trades)")}
        needed = {"source", "cycle_id", "revision_no", "decision_hash", "approval_id"}
        if needed <= cols:
            rows = self.conn.execute(
                "SELECT client_order_id, symbol, action, status, source, "
                "COALESCE(client_order_id, '') coid FROM trades "
                "WHERE COALESCE(source,'') IN ('chief','trader') "
                "AND (COALESCE(cycle_id,'') = '' OR COALESCE(revision_no,0) = 0 "
                "     OR COALESCE(decision_hash,'') = '' "
                "     OR COALESCE(approval_id,'') = '')").fetchall()
            now = datetime.now(timezone.utc).isoformat()
            for r in rows:
                self.record_ledger_exception(
                    kind="broken_link",
                    subject_key=f"trade:{r['coid'] or r['symbol']}",
                    symbol=r["symbol"],
                    basis="pre-Phase-C system order without a recoverable "
                          "decision chain",
                    detail_json=json.dumps({
                        "source": r["source"], "status": r["status"],
                        "action": r["action"]}, ensure_ascii=False),
                    created_at=now)
        self.conn.execute(
            "INSERT INTO data_migrations (key,applied_at,note) VALUES (?,?,?)",
            (key, now if needed <= cols else datetime.now(timezone.utc).isoformat(),
             "legacy system orders without decision chains registered as gaps"))
        self.conn.commit()

    def record_ledger_exception(
            self, *, kind: str, subject_key: str, cycle_id: str | None = None,
            symbol: str | None = None, window_start: str | None = None,
            window_end: str | None = None, as_of: str | None = None,
            basis: str = "", detail_json: str = "",
            created_at: str | None = None) -> str:
        """Idempotently register (or refresh) a ledger audit exception.

        Same (kind, subject_key) rediscovered updates `last_seen_at` and the
        detail — it is the same fact seen again, not a second fact (§11:
        unattributable does not mean ignorable, but it must not duplicate).
        """
        from ..execution.ids import exception_id

        now = created_at or datetime.now(timezone.utc).isoformat()
        exc_id = exception_id(kind, subject_key)
        existing = self.conn.execute(
            "SELECT exception_id FROM ledger_exceptions WHERE exception_id = ?",
            (exc_id,)).fetchone()
        if existing is None:
            self.conn.execute(
                "INSERT INTO ledger_exceptions (exception_id, kind, subject_key, "
                "cycle_id, symbol, window_start, window_end, as_of, basis, "
                "detail_json, status, first_seen_at, last_seen_at, created_at, "
                "updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (exc_id, kind, subject_key, cycle_id, symbol, window_start,
                 window_end, as_of, basis, detail_json, "open", now, now,
                 now, now))
        else:
            self.conn.execute(
                "UPDATE ledger_exceptions SET last_seen_at = ?, detail_json = ?, "
                "updated_at = ? WHERE exception_id = ?",
                (now, detail_json, now, exc_id))
        self.conn.commit()
        return exc_id

    def _migrate_legacy_decisions(self) -> None:
        """One-time §12.3 backfill: legacy `decisions` rows become revisions.

        Mappable rows (content fully recoverable — see
        :mod:`ats.decision.legacy` for the shared classification) become one
        `legacy_revision` per cycle, with a real content hash over the recovered
        orders and rationales. Rows with gaps become a separate `legacy_unknown`
        revision that keeps the original identifiers (`legacy_ref`) but gets NO
        hash, NO input refs and NO snapshot/approval linkage — and is
        structurally barred from execution authorization
        (`ats.decision.state.revision_authorization_blockers`).

        Guarded by the `data_migrations` ledger, like every other one-time
        backfill; the classification must stay identical to
        `scripts/audit_legacy_decisions.py`, which is why both call the same
        function instead of duplicating the rule.
        """
        from ..decision import hashing
        from ..decision.legacy import classify_legacy_decisions as legacy_inventory
        from ..decision.state import (REVISION_SOURCE_LEGACY,
                                      REVISION_SOURCE_LEGACY_UNKNOWN)
        from ..schemas.decision import normalize_action as _normalize_action

        key = "decision_audit_legacy_v1"
        if self.conn.execute(
                "SELECT 1 FROM data_migrations WHERE key=?", (key,)).fetchone():
            return
        names = {r["name"] for r in self.conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        if not {"cycles", "decisions"} <= names:
            return                                    # nothing legacy to migrate
        inventory = legacy_inventory(self.conn)
        if not inventory.rows:
            return
        stamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
        from ..agent.task_projection import canonical_json

        def _next_revision_no(cycle_id: str) -> int:
            row = self.conn.execute(
                "SELECT MAX(revision_no) FROM decision_revisions WHERE cycle_id=?",
                (cycle_id,)).fetchone()
            return (row[0] or 0) + 1

        # Mappable rows: one legacy_revision per cycle, orders sorted by symbol
        # for a deterministic hash.
        by_cycle: dict[str, list] = {}
        for row in inventory.mappable:
            by_cycle.setdefault(row.cycle_id, []).append(row)
        for cycle_id, rows in sorted(by_cycle.items()):
            orders = []
            rationales: dict[str, str] = {}
            for row in sorted(rows, key=lambda r: (r.symbol or "", r.rowid)):
                order = {"symbol": (row.symbol or "").upper(),
                         "action": _normalize_action(
                             row.action or "", where=f"decisions.rowid={row.rowid}"),
                         "notional_usd": float(row.notional_usd)}
                if row.limit_price is not None:
                    order["limit_price"] = float(row.limit_price)
                if row.conviction is not None:
                    order["conviction"] = float(row.conviction)
                if row.rationale:
                    order["rationale"] = row.rationale
                    rationales[order["symbol"]] = row.rationale
                orders.append(order)
            self.conn.execute(
                "INSERT INTO decision_revisions (cycle_id, revision_no, decision_hash, "
                "parent_revision_no, orders_json, rationale, input_refs, model_version, "
                "prompt_version, revision_source, legacy_ref, created_at) "
                "VALUES (?,?,?,NULL,?,?,NULL,NULL,NULL,?,?,?)",
                (cycle_id, _next_revision_no(cycle_id),
                 hashing.decision_hash(orders=orders, rationale=rationales),
                 canonical_json(orders),
                 canonical_json(rationales) if rationales else "",
                 REVISION_SOURCE_LEGACY,
                 f"decisions:{cycle_id}", stamp))
        # Unmapped rows: keep original identifiers, fabricate nothing.
        unknown_by_cycle: dict[str, list] = {}
        for row in inventory.unmappable:
            unknown_by_cycle.setdefault(row.cycle_id or "<no-cycle-id>", []).append(row)
        for cycle_id, rows in sorted(unknown_by_cycle.items()):
            legacy_ref = canonical_json([
                {"decisions.rowid": row.rowid, "cycle_id": row.cycle_id,
                 "symbol": row.symbol, "action": row.action,
                 "reason": row.reason} for row in
                sorted(rows, key=lambda r: r.rowid)])
            self.conn.execute(
                "INSERT INTO decision_revisions (cycle_id, revision_no, decision_hash, "
                "parent_revision_no, orders_json, rationale, input_refs, model_version, "
                "prompt_version, revision_source, legacy_ref, created_at) "
                "VALUES (?,?,NULL,NULL,NULL,NULL,NULL,NULL,NULL,?,?,?)",
                (cycle_id, _next_revision_no(cycle_id), REVISION_SOURCE_LEGACY_UNKNOWN,
                 legacy_ref, stamp))
        self.conn.execute(
            "INSERT INTO data_migrations (key,applied_at,note) VALUES (?,?,?)",
            (key, stamp,
             f"migrated {len(inventory.mappable)} mappable / "
             f"{len(inventory.unmappable)} legacy_unknown legacy decisions"))

    # --- writes ---------------------------------------------------------- #
    _TRADE_COLS = ("order_id", "cycle_id", "symbol", "action", "qty", "order_type", "status",
                   "avg_fill_price", "submitted_at", "rationale", "limit_price", "filled_at",
                   "error", "realized_pnl", "source", "context", "perm_id", "order_ref",
                   "decision_hash", "approval_id")

    @staticmethod
    def client_order_id(cycle_id: str, revision_no: int, seq: int,
                        symbol: str, action: str) -> str:
        """Deterministic idempotency key: one INTENT, one row.

        Task 7.7: the id is derived from cycle + revision + the order's sequence
        WITHIN the revision (+ symbol/action for readability), so two revisions
        of the same cycle can carry same-symbol same-direction orders without
        colliding. Repeated rows for the same id are retries of the same intent,
        not new intents. Without this key the 2026-07-23 IBKR outage wrote the
        same GOOG/ASML/KLAC trim five times each.
        """
        return f"{cycle_id}:r{revision_no}:{seq}:{symbol.upper()}:{action}"

    def _insert_trades(self, entries, *, cycle_id: str, source: str, context: str = "") -> None:
        """Upsert one row per intent, counting attempts instead of duplicating rows.

        On a repeat we keep whatever execution facts we already learned — a retry that
        errors must never erase a fill the first attempt achieved — and keep the
        original submit time, while advancing status/error and bumping `attempt`.
        """
        from ..execution.shadow_execution import assert_trade_publication

        assert_trade_publication(self, entries)
        for t in entries:
            self._enforce_decision_chain(t, source=source)
            coid = self.client_order_id(cycle_id, getattr(t, "revision_no", 0),
                                        getattr(t, "order_seq", 0),
                                        t.symbol, t.action)
            submitted = t.submitted_at.isoformat() if t.submitted_at else None
            filled = t.filled_at.isoformat() if t.filled_at else None
            prior = self.conn.execute(
                "SELECT attempt, status, avg_fill_price, filled_at, order_id, first_submitted_at "
                "FROM trades WHERE client_order_id = ?", (coid,)).fetchone()
            if prior is None:
                self.conn.execute(
                    f"INSERT INTO trades ({','.join(self._TRADE_COLS)}, client_order_id, "
                    f"revision_no, order_seq, attempt, first_submitted_at) VALUES "
                    f"({','.join('?' * len(self._TRADE_COLS))},?,?,?,?,?)",
                    (t.order_id, cycle_id, t.symbol, t.action, t.qty, t.order_type, t.status,
                     t.avg_fill_price, submitted, t.rationale, t.limit_price, filled,
                     t.error, None, source, context,
                     getattr(t, "perm_id", "") or None, getattr(t, "order_ref", "") or None,
                     getattr(t, "decision_hash", "") or None,
                     getattr(t, "approval_id", "") or None,
                     coid, getattr(t, "revision_no", 0) or None,
                     getattr(t, "order_seq", 0) or None, 1, submitted))
                continue
            had_fill = prior["avg_fill_price"] is not None
            self.conn.execute(
                "UPDATE trades SET attempt = attempt + 1, status = ?, error = ?, "
                "order_id = ?, avg_fill_price = COALESCE(avg_fill_price, ?), "
                "filled_at = COALESCE(filled_at, ?), qty = ?, limit_price = ?, "
                "context = ?, submitted_at = ?, "
                "perm_id = COALESCE(?, perm_id), order_ref = COALESCE(?, order_ref) "
                "WHERE client_order_id = ?",
                (prior["status"] if had_fill else t.status, t.error,
                 t.order_id or prior["order_id"], t.avg_fill_price, filled,
                 t.qty, t.limit_price, context, submitted,
                 getattr(t, "perm_id", "") or None, getattr(t, "order_ref", "") or None,
                 coid))

    # Chain-less statuses: these never reach (or try to reach) the broker, so
    # there is nothing for the decision chain to authorize. Everything else
    # written by a system source MUST carry the full chain (§11, task 2.1).
    CHAIN_EXEMPT_STATUSES = frozenset({"cancelled", "rejected"})
    SYSTEM_TRADE_SOURCES = frozenset({"chief", "trader"})

    def _enforce_decision_chain(self, entry, *, source: str) -> None:
        """Refuse chain-less SYSTEM submissions and register the gap (task 2.1).

        A real order — submitted, filled, errored, retried — must be traceable
        to its cycle, revision, hash and approval. Missing any of them here
        means a caller bypassed the authorization gate; we record an explicit
        exception and refuse the write rather than filing a half-linked order
        that looks attributable but cannot be verified.
        """
        if source not in self.SYSTEM_TRADE_SOURCES:
            return
        if entry.status in self.CHAIN_EXEMPT_STATUSES:
            return
        missing = []
        if not entry.cycle_id:
            missing.append("cycle_id")
        if not getattr(entry, "revision_no", 0):
            missing.append("revision_no")
        if not getattr(entry, "decision_hash", ""):
            missing.append("decision_hash")
        if not getattr(entry, "approval_id", ""):
            missing.append("approval_id")
        if not missing:
            return
        subject = f"order:{entry.cycle_id}:{entry.symbol}:{entry.action}"
        self.record_ledger_exception(
            kind="broken_link", subject_key=subject, cycle_id=entry.cycle_id,
            symbol=entry.symbol,
            basis="system submission rejected: decision chain incomplete",
            detail_json=json.dumps({"missing": missing, "status": entry.status,
                                    "source": source}, ensure_ascii=False))
        raise MissingDecisionChainError(
            f"system order for {entry.symbol} {entry.action} is missing "
            f"decision-chain fields: {', '.join(missing)}")

    def save_trades(self, entries, *, cycle_id: str, source: str, context: str = "") -> None:
        """Persist trade-log entries with their full context (trader path, standalone)."""
        if not entries:
            return
        self._insert_trades(entries, cycle_id=cycle_id, source=source, context=context)
        self.conn.commit()

    def upsert_fills(self, fills: list[dict]) -> int:
        """Insert IBKR fills, deduped by exec_id (accumulates per-trade realized P&L)."""
        if not fills:
            return 0
        from ..execution.shadow_execution import assert_trade_publication

        assert_trade_publication(self, fills)
        before = self.conn.execute("SELECT COUNT(*) c FROM fills").fetchone()["c"]
        # Column-explicit: `fills` gains journal columns over time, and a positional
        # INSERT silently breaks the moment one is added.
        self.conn.executemany(
            "INSERT OR IGNORE INTO fills (exec_id, symbol, side, shares, price, time, "
            "realized_pnl, commission, order_id, perm_id, order_ref, captured_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            [(f["exec_id"], f["symbol"], f.get("side", ""), f.get("shares", 0), f.get("price", 0),
              f.get("time", ""), f.get("realized_pnl"), f.get("commission", 0),
              f.get("order_id", ""), f.get("perm_id"), f.get("order_ref"),
              datetime.now(timezone.utc).isoformat())
             for f in fills])
        self.conn.commit()
        return self.conn.execute("SELECT COUNT(*) c FROM fills").fetchone()["c"] - before

    def set_cycle_approval(self, cycle_id: str, status: str) -> None:
        """Record the Boss's verdict once it is known.

        `save_chief_run` writes the cycle row BEFORE the approval interrupt (so a card
        the Boss never answers still leaves an audit trail), which is why
        approval_status was NULL on every cycle ever recorded — nothing came back to
        fill it in.
        """
        self.conn.execute("UPDATE cycles SET approval_status = ? WHERE cycle_id = ?",
                          (status, cycle_id))
        self.conn.commit()

    # --- journal entries (one row per INTENT) ------------------------------ #
    # The typed columns; `risk_notes` and `approval` are objects in Python and JSON
    # on disk, so they are mapped explicitly rather than dumped.
    _JOURNAL_COLS = (
        "entry_id", "cycle_id", "as_of", "symbol", "action", "source", "setup",
        "intended_notional", "intended_qty", "conviction", "order_type", "limit_price",
        "stop_price", "target_price", "planned_horizon_days", "invalidation",
        "planned_risk_usd", "risk_unit_source", "rationale", "regime_risk_state",
        "ev_score_total", "ev_score_band", "ev_has_transcript", "ev_score_latency_h",
        "ev_expected_move_pct", "risk_notes_json", "approval_status", "approval_reviewer",
        "approval_comment", "approval_divergence", "submit_attempts", "terminal_status",
        "filled_qty", "avg_fill_price", "slippage_bps")

    @staticmethod
    def _journal_to_row(e) -> dict:
        import json as _json

        d = e.model_dump(mode="json")
        ap = e.approval
        d["risk_notes_json"] = _json.dumps(e.risk_notes, ensure_ascii=False)
        d["approval_status"] = ap.status if ap else None
        d["approval_reviewer"] = ap.reviewer if ap else None
        d["approval_comment"] = ap.comment if ap else None
        d["approval_divergence"] = (_json.dumps(ap.model_dump(mode="json"),
                                                ensure_ascii=False) if ap else None)
        return {k: d.get(k) for k in TradingMemory._JOURNAL_COLS}

    @staticmethod
    def _row_to_journal(row):
        import json as _json

        from ..schemas.journal import ApprovalDivergence, JournalEntry

        d = dict(row)
        d["risk_notes"] = _json.loads(d.pop("risk_notes_json", None) or "[]")
        raw = d.pop("approval_divergence", None)
        d["approval"] = ApprovalDivergence.model_validate(_json.loads(raw)) if raw else None
        for k in ("approval_status", "approval_reviewer", "approval_comment"):
            d.pop(k, None)
        # A NULL column on a field that has a non-null default means "never set" —
        # let the default speak rather than failing validation (e.g. submit_attempts
        # is NULL until an order row exists).
        fields = JournalEntry.model_fields
        return JournalEntry.model_validate({
            k: v for k, v in d.items()
            if k in fields and not (v is None and fields[k].default is not None)})

    def save_journal_entry(self, entry) -> None:
        """Insert the pre-registered plan. Idempotent on entry_id: a retried cycle
        re-states the same plan, it does not create a second intent."""
        row = self._journal_to_row(entry)
        self.conn.execute(
            f"INSERT OR REPLACE INTO journal_entries ({','.join(row)}) "
            f"VALUES ({','.join('?' * len(row))})", tuple(row.values()))
        self.conn.commit()

    def update_journal_outcome(self, entry_id: str, row: dict) -> None:
        """Attach the execution result. The PLAN columns are never touched here —
        a journal whose plan can be edited after the outcome proves nothing."""
        sets = ", ".join(f"{k} = COALESCE(?, {k})" for k in row)
        self.conn.execute(
            f"UPDATE journal_entries SET {sets}, submit_attempts = "
            "(SELECT attempt FROM trades WHERE client_order_id = ?) WHERE entry_id = ?",
            (*row.values(), entry_id, entry_id))
        self.conn.commit()

    def journal_entries(self, *, since: str = "", symbol: str = "",
                        limit: int = 500) -> list:
        """-> list[JournalEntry]."""
        sql = "SELECT * FROM journal_entries WHERE 1=1"
        args: list = []
        if since:
            sql += " AND as_of >= ?"
            args.append(since)
        if symbol:
            sql += " AND symbol = ?"
            args.append(symbol.upper())
        sql += " ORDER BY as_of DESC, symbol LIMIT ?"
        args.append(limit)
        return [self._row_to_journal(r) for r in self.conn.execute(sql, args).fetchall()]

    def get_journal_entry(self, entry_id: str):
        """-> JournalEntry | None. Used to attach the opening plan onto an episode."""
        row = self.conn.execute(
            "SELECT * FROM journal_entries WHERE entry_id = ?", (entry_id,)).fetchone()
        return self._row_to_journal(row) if row else None

    # --- trade episodes (one round trip: flat -> position -> flat) --------- #
    _EPISODE_COLS = (
        "episode_id", "symbol", "direction", "origin", "status", "opened_at",
        "closed_at", "avg_entry", "avg_exit", "realized_pnl", "unrealized_pnl",
        "commission", "basis_source", "holding_days", "r_multiple", "r_multiple_mtm",
        "risk_unit_source", "mae_pct", "mfe_pct", "mae_source", "excess_vs_sector_pct",
        "setup", "primary_entry_id", "exit_reason", "exit_as_planned",
        "invalidation_triggered", "horizon_overdue_days",
        "invalidation_source", "invalidation_checked_at")

    def save_episode(self, episode) -> None:
        """Upsert by episode_id — the reducer re-derives episodes from fills each run,
        so re-saving the same episode_id must replace, not duplicate."""
        row = episode.model_dump(mode="json")
        row = {k: row.get(k) for k in self._EPISODE_COLS}
        self.conn.execute(
            f"INSERT OR REPLACE INTO trade_episodes ({','.join(row)}) "
            f"VALUES ({','.join('?' * len(row))})", tuple(row.values()))
        self.conn.commit()

    def get_episode(self, episode_id: str):
        """-> TradeEpisode | None."""
        from ..schemas.journal import TradeEpisode

        row = self.conn.execute(
            "SELECT * FROM trade_episodes WHERE episode_id = ?", (episode_id,)).fetchone()
        return TradeEpisode.model_validate(dict(row)) if row else None

    def list_episodes(self, *, symbol: str = "", status: str = "",
                      decision_gradeable_only: bool = False, limit: int = 500) -> list:
        """-> list[TradeEpisode]."""
        from ..schemas.journal import TradeEpisode

        sql = "SELECT * FROM trade_episodes WHERE 1=1"
        args: list = []
        if symbol:
            sql += " AND symbol = ?"
            args.append(symbol.upper())
        if status:
            sql += " AND status = ?"
            args.append(status)
        if decision_gradeable_only:
            # Mirrors TradeEpisode.decision_gradeable: a real linked plan, not origin —
            # manual-origin episodes also have no plan (manual orders bypass
            # persist_decision) and must not slip into decision-quality stats either.
            sql += " AND primary_entry_id != ''"
        sql += " ORDER BY opened_at DESC LIMIT ?"
        args.append(limit)
        return [TradeEpisode.model_validate(dict(r))
                for r in self.conn.execute(sql, args).fetchall()]

    def fills_for_symbol(self, symbol: str) -> list[dict]:
        """Raw fill rows for the reducer, oldest first."""
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM fills WHERE symbol = ? ORDER BY time ASC", (symbol.upper(),))]

    def symbols_with_fills(self) -> list[str]:
        return [r[0] for r in self.conn.execute(
            "SELECT DISTINCT symbol FROM fills ORDER BY symbol")]

    def legs_for_episode(self, episode_id: str) -> list[dict]:
        """Raw fill rows belonging to one episode, oldest first. The last row is the
        closing leg for a closed episode, or the most recent trim for an open one."""
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM fills WHERE episode_id = ? ORDER BY time ASC", (episode_id,))]

    # --- predictions + outcomes -------------------------------------------- #
    def save_prediction(self, prediction) -> None:
        row = prediction.model_dump(mode="json")
        self.conn.execute(
            f"INSERT OR REPLACE INTO predictions ({','.join(row)}) "
            f"VALUES ({','.join('?' * len(row))})", tuple(row.values()))
        self.conn.commit()

    def save_prediction_outcome(self, outcome) -> None:
        row = outcome.model_dump(mode="json")
        self.conn.execute(
            f"INSERT OR REPLACE INTO prediction_outcomes ({','.join(row)}) "
            f"VALUES ({','.join('?' * len(row))})", tuple(row.values()))
        self.conn.commit()

    def has_outcome(self, prediction_id: str, horizon_days: int) -> bool:
        return self.conn.execute(
            "SELECT 1 FROM prediction_outcomes WHERE prediction_id = ? AND horizon_days = ?",
            (prediction_id, horizon_days)).fetchone() is not None

    def open_predictions(self, horizons: list[int]) -> list:
        """Predictions still missing at least one horizon. -> list[Prediction]."""
        from ..schemas.journal import Prediction

        rows = self.conn.execute(
            "SELECT p.* FROM predictions p WHERE (SELECT COUNT(*) FROM prediction_outcomes o "
            "WHERE o.prediction_id = p.prediction_id) < ? ORDER BY p.made_at",
            (len(horizons),)).fetchall()
        return [Prediction.model_validate(dict(r)) for r in rows]

    def all_predictions(self, source: str = "") -> list:
        """-> list[Prediction], every one ever made (optionally filtered by source).
        Calibration accrues per SCORE regardless of whether a trade followed, so this
        is the base population for Stage D's calibration report."""
        from ..schemas.journal import Prediction

        sql = "SELECT * FROM predictions"
        args: list = []
        if source:
            sql += " WHERE source = ?"
            args.append(source)
        sql += " ORDER BY made_at"
        return [Prediction.model_validate(dict(r))
                for r in self.conn.execute(sql, args).fetchall()]

    def get_prediction(self, prediction_id: str):
        """-> Prediction | None. Single-row lookup, mirrors get_episode/
        get_journal_entry — used to resolve a bare counterexample ID back to its
        full record (e.g. when rendering, or when Stage E's critic picks cases)."""
        from ..schemas.journal import Prediction

        row = self.conn.execute(
            "SELECT * FROM predictions WHERE prediction_id = ?", (prediction_id,)).fetchone()
        return Prediction.model_validate(dict(row)) if row else None

    def predictions_for_entries(self, entry_ids: list[str]) -> list:
        """-> list[Prediction] whose entry_id is one of the given ids — the predictions
        that actually led to a trade in a given episode (an episode has no fiscal_label
        of its own; this is how its review card finds the right quarter's predictions)."""
        from ..schemas.journal import Prediction

        ids = [e for e in entry_ids if e]
        if not ids:
            return []
        rows = self.conn.execute(
            f"SELECT * FROM predictions WHERE entry_id IN ({','.join('?' * len(ids))}) "
            "ORDER BY made_at", ids).fetchall()
        return [Prediction.model_validate(dict(r)) for r in rows]

    def prediction_outcomes(self, prediction_id: str) -> list:
        """-> list[PredictionOutcome]."""
        from ..schemas.journal import PredictionOutcome

        return [PredictionOutcome.model_validate(dict(r)) for r in self.conn.execute(
            "SELECT * FROM prediction_outcomes WHERE prediction_id = ? ORDER BY horizon_days",
            (prediction_id,)).fetchall()]

    # --- journal bookkeeping ---------------------------------------------- #
    def set_meta(self, key: str, value: str) -> None:
        self.conn.execute("INSERT OR REPLACE INTO journal_meta VALUES (?,?)", (key, value))
        self.conn.commit()

    def get_meta(self, key: str, default: str = "") -> str:
        row = self.conn.execute(
            "SELECT value FROM journal_meta WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else default

    def recent_fills(self, symbol: str | None = None, limit: int = 20) -> list[dict]:
        if symbol:
            rows = self.conn.execute(
                "SELECT * FROM fills WHERE symbol = ? ORDER BY time DESC LIMIT ?",
                (symbol, limit)).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM fills ORDER BY time DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    # --- chief runs (reuse cycles + decisions tables) ---------------------- #
    def save_chief_run(self, *, cycle_id: str, as_of, summary: str, decisions) -> None:
        self.conn.execute("INSERT OR REPLACE INTO cycles VALUES (?,?,?,?)",
                          (cycle_id, as_of.isoformat(), None, summary))
        self.conn.executemany(
            "INSERT INTO decisions VALUES (?,?,?,?,?,?,?)",
            [(cycle_id, d.symbol, d.action, d.notional_usd, d.limit_price, d.conviction,
              d.rationale) for d in decisions])
        self.conn.commit()

    def last_chief_run(self) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM cycles WHERE cycle_id LIKE 'chief-%' ORDER BY as_of DESC LIMIT 1"
        ).fetchone()
        if row is None:
            return None
        out = dict(row)
        out["decisions"] = [dict(r) for r in self.conn.execute(
            "SELECT * FROM decisions WHERE cycle_id = ?", (row["cycle_id"],)).fetchall()]
        return out

    def save_risk_review(self, review) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO risk_reviews VALUES (?,?,?,?)",
            (review.as_of.isoformat(), review.risk_state, review.notes,
             review.model_dump_json()))
        self.conn.commit()

    def latest_risk_review(self):
        from ..schemas.risk import RiskReview

        row = self.conn.execute(
            "SELECT payload FROM risk_reviews ORDER BY as_of DESC LIMIT 1").fetchone()
        return RiskReview.model_validate_json(row["payload"]) if row else None

    def recent_risk_reviews(self, limit: int = 10) -> list[dict]:
        rows = self.conn.execute(
            "SELECT as_of, risk_state, summary FROM risk_reviews ORDER BY as_of DESC LIMIT ?",
            (limit,)).fetchall()
        return [dict(r) for r in rows]

    # --- PEAD score consumption (a score is actionable to the Chief ONCE) ---- #
    def mark_score_consumed(self, symbol: str, fiscal_label: str, cycle_id: str = "") -> None:
        """Record that the Chief has acted on (responded to) this earnings' score, so
        it becomes background thereafter — keyed per earnings (symbol, fiscal_label)."""
        from datetime import datetime, timezone

        self.conn.execute(
            "INSERT OR REPLACE INTO score_consumption VALUES (?,?,?,?)",
            (symbol.upper(), fiscal_label, datetime.now(timezone.utc).isoformat(), cycle_id))
        self.conn.commit()

    def is_score_consumed(self, symbol: str, fiscal_label: str) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM score_consumption WHERE symbol = ? AND fiscal_label = ?",
            (symbol.upper(), fiscal_label)).fetchone()
        return row is not None

    # --- Detected earnings prints (quarter key + session, cached per print) ---- #
    def upsert_period(self, print_, fiscal_label: str, label_source: str) -> None:
        """Record/refresh a detected print keyed (symbol, earnings_date).

        Caching the label matters: the upstream calendars revise quarter/year, and a
        label that shifts between the score write and a later read would orphan the
        dossier (its PK is (symbol, fiscal_label)).
        """
        from datetime import datetime, timezone

        p = print_
        self.conn.execute(
            "INSERT OR REPLACE INTO pead_periods VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (p.symbol.upper(), p.date.isoformat(), fiscal_label, p.quarter, p.year,
             p.session, p.session_source, p.at.isoformat() if p.at else None,
             p.eps_actual, p.rev_actual, label_source,
             datetime.now(timezone.utc).isoformat()))
        self.conn.commit()

    def get_period(self, symbol: str, earnings_date) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM pead_periods WHERE symbol = ? AND earnings_date = ?",
            (symbol.upper(), earnings_date.isoformat() if hasattr(earnings_date, "isoformat")
             else earnings_date)).fetchone()
        return dict(row) if row else None

    # --- Versioned score runs (idempotency + v1→v2 upgrade record) ------------ #
    def record_score_run(self, *, symbol: str, fiscal_label: str, version: int,
                         earnings_date, has_transcript: bool, transcript_source: str = "",
                         window: str = "", latency_hours: float | None = None,
                         total: float | None = None, band: str = "",
                         decision_summary: str = "", final: bool | None = None) -> None:
        """`final` defaults to has_transcript: a transcript-backed score is actionable
        at once, a transcript-less v1 is withheld until promoted."""
        from datetime import datetime, timezone

        self.conn.execute(
            "INSERT OR REPLACE INTO pead_score_runs VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (symbol.upper(), fiscal_label, version, datetime.now(timezone.utc).isoformat(),
             earnings_date.isoformat() if hasattr(earnings_date, "isoformat") else earnings_date,
             1 if has_transcript else 0, transcript_source, window, latency_hours,
             total, band, decision_summary,
             1 if (has_transcript if final is None else final) else 0))
        self.conn.commit()

    def stamp_score_run(self, symbol: str, fiscal_label: str, *, window: str,
                        latency_hours: float | None) -> None:
        """Attach which window produced the latest run and how long after the print.

        Fixed windows necessarily leave a gap (a 06:00 ET print is only scored at
        11:00), so record the real print→score latency: that turns "is twice a day
        often enough" from an argument into a measurement.
        """
        last = self.latest_score_run(symbol, fiscal_label)
        if not last:
            return
        self.conn.execute(
            "UPDATE pead_score_runs SET window = ?, latency_hours = ? "
            "WHERE symbol = ? AND fiscal_label = ? AND version = ?",
            (window, latency_hours, symbol.upper(), fiscal_label, last["version"]))
        self.conn.commit()

    def promote_score_run(self, symbol: str, fiscal_label: str) -> bool:
        """Mark the latest run final without re-scoring — used when the transcript
        never arrived and the v1 becomes the best available answer."""
        last = self.latest_score_run(symbol, fiscal_label)
        if not last or last["final"]:
            return False
        self.conn.execute(
            "UPDATE pead_score_runs SET final = 1 WHERE symbol = ? AND fiscal_label = ? "
            "AND version = ?", (symbol.upper(), fiscal_label, last["version"]))
        self.conn.commit()
        return True

    def latest_score_run(self, symbol: str, fiscal_label: str) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM pead_score_runs WHERE symbol = ? AND fiscal_label = ? "
            "ORDER BY version DESC LIMIT 1", (symbol.upper(), fiscal_label)).fetchone()
        return dict(row) if row else None

    def next_score_version(self, symbol: str, fiscal_label: str) -> int:
        last = self.latest_score_run(symbol, fiscal_label)
        return (last["version"] + 1) if last else 1

    def score_state(self, symbol: str, fiscal_label: str) -> str:
        """'unscored' | 'v1_no_transcript' | 'final' — drives the window state machine."""
        last = self.latest_score_run(symbol, fiscal_label)
        if not last:
            return "unscored"
        return "final" if (last["has_transcript"] or last["final"]) else "v1_no_transcript"

    def is_score_final(self, symbol: str, fiscal_label: str) -> bool:
        """Whether the Chief may act on this quarter's score yet."""
        return self.score_state(symbol, fiscal_label) == "final"

    def save_performance(self, record: PerformanceRecord) -> None:
        """Standalone performance snapshot (trader daily snapshot, no full cycle)."""
        p = record
        self.conn.execute("INSERT INTO performance VALUES (?,?,?,?,?,?,?,?,?)",
                          (p.cycle_id, p.as_of.isoformat(), p.net_liquidation, p.daily_pnl,
                           p.cumulative_pnl, p.realized_pnl, p.unrealized_pnl, p.num_positions,
                           p.model_dump_json()))
        self.conn.commit()

    # --- reads ----------------------------------------------------------- #
    def last_performance(self) -> PerformanceRecord | None:
        row = self.conn.execute(
            "SELECT payload FROM performance ORDER BY rowid DESC LIMIT 1").fetchone()
        return PerformanceRecord.model_validate_json(row["payload"]) if row else None

    def performance_history(self, limit: int = 30) -> list[PerformanceRecord]:
        rows = self.conn.execute(
            "SELECT payload FROM performance ORDER BY rowid DESC LIMIT ?", (limit,)).fetchall()
        return list(reversed(
            [PerformanceRecord.model_validate_json(r["payload"]) for r in rows]))

    def recent_decisions(self, symbol: str | None = None, limit: int = 20) -> list[dict]:
        if symbol:
            rows = self.conn.execute(
                "SELECT * FROM decisions WHERE symbol = ? ORDER BY rowid DESC LIMIT ?",
                (symbol, limit)).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM decisions ORDER BY rowid DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    def recent_trades(self, symbol: str | None = None, limit: int = 10) -> list[dict]:
        if symbol:
            rows = self.conn.execute(
                "SELECT * FROM trades WHERE symbol = ? ORDER BY rowid DESC LIMIT ?",
                (symbol, limit)).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM trades ORDER BY rowid DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    # --- PEAD dossier ---------------------------------------------------- #
    def save_dossier(self, dossier) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO pead_dossier VALUES (?,?,?,?,?)",
            (dossier.symbol, dossier.fiscal_label, dossier.phase,
             dossier.model_dump_json(), dossier.updated_at.isoformat()))
        self.conn.commit()

    def get_dossier(self, symbol: str, fiscal_label: str):
        from ..schemas.pead import PeadDossier

        row = self.conn.execute(
            "SELECT payload FROM pead_dossier WHERE symbol = ? AND fiscal_label = ?",
            (symbol, fiscal_label)).fetchone()
        return PeadDossier.model_validate_json(row["payload"]) if row else None

    def recent_dossiers(self, symbol: str | None = None, limit: int = 10) -> list[dict]:
        if symbol:
            rows = self.conn.execute(
                "SELECT symbol, fiscal_label, phase, updated_at FROM pead_dossier "
                "WHERE symbol = ? ORDER BY updated_at DESC LIMIT ?", (symbol, limit)).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT symbol, fiscal_label, phase, updated_at FROM pead_dossier "
                "ORDER BY updated_at DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]

    # --- PEAD event log -------------------------------------------------- #
    def append_events(self, symbol: str, items) -> list:
        """Insert news items not already stored FOR THIS SYMBOL; return the new ones.

        Dedup is per-symbol, not global: the same peer headline is relevant to every
        target that lists that peer in its signal_chain, and each of them needs to see
        it. A global dedup gave the item to whichever target fetched it first and
        silently starved the rest.
        """
        if not items:
            return []
        existing = {r["id"] for r in self.conn.execute(
            "SELECT id FROM pead_events WHERE symbol = ? AND id IN (%s)"
            % ",".join("?" * len(items)),
            [symbol, *(i.id for i in items)]).fetchall()}
        fresh = []
        for i in items:                     # also dedup within the batch itself
            if i.id not in existing:
                existing.add(i.id)
                fresh.append(i)
        self.conn.executemany(
            "INSERT OR IGNORE INTO pead_events (id,symbol,published_at,source,headline,url) "
            "VALUES (?,?,?,?,?,?)",
            [(i.id, symbol, i.published_at.isoformat(), i.source, i.headline, i.url) for i in fresh])
        self.conn.commit()
        return fresh

    # --- chain evidence --------------------------------------------------- #
    def save_observation(self, obs, *, projection_profile: str = "evidence_observer",
                         projection_version: str = "v1") -> bool:
        """Idempotent upsert. Returns True if this observation is new.

        The id is deterministic over (document, entity, metric, period), so
        re-running the observer over the same transcript cannot inflate the
        evidence count — which would otherwise manufacture false corroboration.

        Delegated to the data layer: these rows are neutral facts, and the tables this
        database used to hold them are dropped by `_retire_data_tables`.
        """
        return self.data_store().save_evidence_observation(
            obs, projection_profile=projection_profile,
            projection_version=projection_version)

    def supersede_document_observations(self, document_id: str, source_entity: str,
                                        *, at: datetime | None = None) -> int:
        """Retire the previous extraction of one document by one speaker.

        `concept` is assigned by the model AT EXTRACTION TIME and frozen in the row. So
        when a claim's dimension definitions change, re-extracting is the only way for
        the new definitions to take effect — but the OLD rows do not disappear, and
        their stale `concept` keeps them eligible. Both readings of the same sentence
        then vote, and the older, wronger one usually wins on volume.

        That is not hypothetical: `xpu_value_capture_per_capacity` was tightened
        specifically to exclude consolidated gross margin, the re-extraction correctly
        dropped that row — and the verdict did not move, because the previous run's copy
        was still mapped and still refuting. One document, one speaker, two contradictory
        classifications, both counted.

        Rows are marked, never deleted. "Superseded" and "never observed" are different
        states, and the audit trail is the whole point of storing spans. Callers that
        assess evidence read only live rows; callers that audit history can still see
        everything.

        Ordering matters: mark first, then insert. `save_observation` uses INSERT OR
        REPLACE, which drops and re-inserts the row, so any observation the new run
        reproduces gets `superseded_at` reset to NULL by construction. What stays
        retired is exactly what the new extraction no longer produces.
        """
        return self.data_store().supersede_document_observations(
            document_id, source_entity, at=at)

    def observations(self, *, entity: str | None = None, metric: str | None = None,
                     since: datetime | None = None, limit: int = 500,
                     include_superseded: bool = False) -> list[dict]:
        return self.data_store().observations(
            entity=entity, metric=metric, since=since, limit=limit,
            include_superseded=include_superseded)

    def facts(self, *, entity: str | None = None, document_id: str | None = None,
              since: datetime | None = None, include_superseded: bool = False,
              limit: int = 500) -> list[dict]:
        return self.data_store().facts(
            entity=entity, document_id=document_id, since=since,
            include_superseded=include_superseded, limit=limit)

    def fact_projections(self, *, fact_id: str | None = None,
                         profile: str | None = None, concept: str | None = None,
                         include_superseded: bool = False,
                         limit: int = 500) -> list[dict]:
        return self.data_store().fact_projections(
            fact_id=fact_id, profile=profile, concept=concept,
            include_superseded=include_superseded, limit=limit)

    def has_observations_for_document(self, document_id: str) -> bool:
        """Already extracted from this filing? Then never fetch or re-read it.

        Document-level idempotence: the earnings windows retry across days and both
        windows may attempt an unknown-session print, so without this a filing would be
        re-fetched and re-sent to the model every attempt.
        """
        return self.data_store().has_observations_for_document(document_id)

    def save_claim_assessment(self, assessment) -> None:
        """Snapshot a verdict, one row per claim per DAY.

        Versioned rather than overwritten because "when did this claim turn from mixed
        to contradicted" is the question a verdict table exists to answer. But the unit
        of version is the day, not the instant: the report file is already named by date
        and same-day reruns overwrite it, so a table that appended on every rerun
        disagreed with its own report — three `evidence report` runs on 2026-08-07 left
        three rows per claim, and the history read as change when nothing had changed.

        Normalising happens HERE rather than at the call sites so every writer gets it,
        and it converts to UTC first: the CLI stamped `+00:00` while the scheduler
        stamped an ET offset, and `latest_claim_assessments` picks MAX over TEXT — a
        lexicographic compare on wall-clock digits, which mixed offsets can invert.
        """
        import json

        day = assessment.as_of.astimezone(timezone.utc).date().isoformat()
        self.conn.execute(
            "INSERT OR REPLACE INTO claim_assessments (claim_id,as_of,layer,verdict,"
            " support_score,refute_score,evidence_clusters,stance_classes,"
            " witnesses_expected,witnesses_reported,payload) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (assessment.claim_id, day, assessment.layer,
             assessment.verdict, assessment.support_score, assessment.refute_score,
             assessment.evidence_clusters, assessment.stance_classes,
             assessment.witnesses_expected, assessment.witnesses_reported,
             json.dumps(assessment.model_dump(mode="json"), ensure_ascii=False)))
        self.conn.commit()

    def claim_assessment_history(self, claim_id: str, limit: int = 20) -> list[dict]:
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM claim_assessments WHERE claim_id = ? ORDER BY as_of DESC "
            "LIMIT ?", (claim_id, limit)).fetchall()]

    def claim_assessments_on(self, layer_keys: list[str], date: str) -> dict[str, list]:
        """Full `ClaimAssessment` objects for a set of layers on one day, grouped by
        layer key — the offline counterpart to what `_run_layered` holds in memory
        during a live run. `date` is `YYYY-MM-DD` (the table's day-truncated key).

        Returns deserialized objects, not raw rows: a reader (the viz bundle) needs the
        nested judgements and entity_readings, which live only in `payload`, not in the
        indexed columns.
        """
        from ..schemas.chain import ClaimAssessment

        if not layer_keys:
            return {}
        placeholders = ",".join("?" * len(layer_keys))
        rows = self.conn.execute(
            f"SELECT layer, payload FROM claim_assessments "
            f"WHERE layer IN ({placeholders}) AND as_of = ?",
            [*layer_keys, date]).fetchall()
        out: dict[str, list] = {}
        for r in rows:
            out.setdefault(r["layer"], []).append(ClaimAssessment.model_validate_json(r["payload"]))
        return out

    def latest_claim_assessments(self, limit: int = 50) -> list[dict]:
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM claim_assessments a WHERE as_of = ("
            "  SELECT MAX(as_of) FROM claim_assessments b WHERE b.claim_id = a.claim_id)"
            " ORDER BY layer, claim_id LIMIT ?", (limit,)).fetchall()]

    def save_observation_failure(self, fail) -> None:
        self.data_store().save_evidence_failure(fail)

    def observation_failures(self, limit: int = 50) -> list[dict]:
        return self.data_store().observation_failures(limit=limit)

    # ----------------------------------------------------------------- #
    # Primary-source inventory (metadata; text lives under docs_root)
    # ----------------------------------------------------------------- #
    def save_document(self, doc, *, ok: bool = True, note: str = "") -> None:
        """Record a logical document and its immutable accepted content version.

        The row lands in the data layer: `source_documents` is one of the tables
        `_retire_data_tables` drops from this database.
        """
        self.data_store().save_document(doc, ok=ok, note=note)
        if ok and doc.sha256:
            self._index_document_version(
                self.document_version_id(doc.document_id, doc.sha256), doc.text or "")

    def link_document_entities(self, document_id: str, entities, *,
                               relation: str = "mentioned") -> int:
        """Attach additional company discovery keys without copying the document."""
        return self.data_store().link_document_entities(
            document_id, entities, relation=relation)

    def save_document_alias(self, document_id: str, *, source: str,
                            source_url: str = "", external_id: str = "",
                            title: str = "", published_at: str = "",
                            metadata: dict | None = None) -> str:
        """Attach another provider identity to an existing logical document."""
        return self.data_store().save_document_alias(
            document_id, source=source, source_url=source_url, external_id=external_id,
            title=title, published_at=published_at, metadata=metadata)

    def document_aliases(self, document_id: str | None = None, *,
                         limit: int = 200) -> list[dict]:
        return self.data_store().document_aliases(document_id, limit=limit)

    def documents_by_alias_source(self, source_contains: str, *, entity: str | None = None,
                                  published_since: str | None = None,
                                  limit: int = 1000) -> list[dict]:
        return self.data_store().documents_by_alias_source(
            source_contains, entity=entity, published_since=published_since, limit=limit)

    def document_by_story(self, title: str, published_at: str = "") -> dict | None:
        """Exact normalized headline/date fallback when a provider has no public URL."""
        return self.data_store().document_by_story(title, published_at)

    def _index_document_version(self, version_id: str, text: str, *,
                                chunk_chars: int = 2400, overlap: int = 240) -> int:
        """Deterministic local full-text chunks; safe to call repeatedly.

        Chunking itself is unchanged — only the destination table moved, so ids stay
        byte-identical and a re-run after the cutover still finds the same chunks.
        """
        body = (text or "").strip()
        if not body:
            return 0
        chunks: list[dict] = []
        ordinal, start = 0, 0
        while start < len(body):
            end = min(len(body), start + chunk_chars)
            if end < len(body):
                # Prefer a nearby paragraph/sentence boundary without requiring one.
                floor = start + chunk_chars // 2
                candidates = [body.rfind(mark, floor, end) for mark in ("\n\n", "。", ". ")]
                boundary = max(candidates)
                if boundary > floor:
                    end = boundary + (2 if body[boundary:boundary + 2] in ("\n\n", ". ") else 1)
            chunk = body[start:end]
            chunks.append({"ordinal": ordinal, "char_start": start, "char_end": end,
                           "text": chunk})
            if end >= len(body):
                break
            start = max(start + 1, end - overlap)
            ordinal += 1
        return self.data_store().save_document_chunks(version_id, chunks)

    def search_document_chunks(self, query: str, *, entity: str | None = None,
                               source_contains: str | None = None,
                               published_since: str | None = None,
                               limit: int = 20) -> list[dict]:
        """Metadata-filtered local full-text search with exact source locations."""
        return self.data_store().search_document_chunks(
            query, entity=entity, source_contains=source_contains,
            published_since=published_since, limit=limit)

    @staticmethod
    def document_version_id(document_id: str, content_hash: str) -> str:
        """Stable identity for one exact body of one logical document."""
        return f"{document_id}@{content_hash[:16]}"

    def document_versions(self, document_id: str) -> list[dict]:
        return self.data_store().document_versions(document_id)

    def latest_document_version(self, document_id: str) -> dict | None:
        return self.data_store().latest_document_version(document_id)

    def document_by_content_hash(self, content_hash: str, *,
                                 entity: str | None = None) -> dict | None:
        return self.data_store().document_by_content_hash(content_hash, entity=entity)

    def begin_document_processing(self, document_id: str, consumer: str,
                                  processor_version: str = "v1", *,
                                  at: str | None = None) -> str | None:
        """Claim one exact document version for a consumer, once.

        Returns the version id when this caller owns a new run, otherwise ``None``.
        The row is written before the expensive operation, so scheduler retries cannot
        duplicate spend. A new processor version remains eligible by construction.
        """
        claimed = self.data_store().begin_document_processing(
            document_id, consumer, processor_version, at=at)
        return claimed

    def finish_document_processing(self, version_id: str, consumer: str,
                                   processor_version: str = "v1", *,
                                   ok: bool, outputs: int = 0, note: str = "",
                                   at: str | None = None) -> None:
        self.data_store().finish_document_processing(
            version_id, consumer, processor_version, ok=ok, outputs=outputs, note=note,
            at=at)

    def document_processing(self, document_id: str | None = None, *,
                            consumer: str | None = None,
                            processor_version: str | None = None,
                            limit: int = 200) -> list[dict]:
        return self.data_store().processing_runs(
            document_id, consumer=consumer, processor_version=processor_version, limit=limit)

    def processed_document_ids(self, consumer: str, processor_version: str, *,
                               entity: str | None = None) -> set[str]:
        return self.data_store().processed_document_ids(
            consumer, processor_version, entity=entity)

    def save_document_failure(self, entity: str, period: str, doc_type: str, *,
                              source: str = "", source_url: str = "", note: str = "",
                              at: str | None = None) -> None:
        """Record a fetch that failed a guard, so it is not retried blindly.

        Stored with ok=0 and no local path: there is deliberately no text, because the
        whole point is that this document was rejected before it could contaminate
        anything.
        """
        self.data_store().save_document_failure(
            entity, period, doc_type, source=source, source_url=source_url, note=note, at=at)

    def save_document_candidate(self, candidate, validation, *, raw_path: str = "",
                                document_id: str = "") -> None:
        """Persist an admission decision without exposing quarantine to asset queries."""
        self.data_store().save_document_candidate(
            candidate, validation, raw_path=raw_path, document_id=document_id)

    def document_candidates(self, *, status: str | None = None,
                            source: str | None = None, limit: int = 200) -> list[dict]:
        return self.data_store().document_candidates(status=status, source=source, limit=limit)

    def save_earnings_event(self, resolution) -> str:
        """Persist resolved/conflicting event evidence as the period audit anchor."""
        import json

        event = resolution.event
        if event is not None:
            event_id = event.event_id
            entity, report_date = event.entity, str(event.report_date)
            fiscal_year, fiscal_quarter = event.fiscal_year, event.fiscal_quarter
        else:
            evidence = resolution.evidence
            entity = ""
            for item in evidence:
                if getattr(item, "reference", "").startswith("entity:"):
                    entity = item.reference.split(":", 1)[1].upper()
                    break
            seed = "|".join(f"{e.source}:{e.report_date}:{e.fiscal_label}" for e in evidence)
            import hashlib

            event_id = f"unresolved:{hashlib.sha1(seed.encode()).hexdigest()[:16]}"
            report_date, fiscal_year, fiscal_quarter = "", None, None
        evidence_json = json.dumps([
            {
                "source": item.source, "report_date": str(item.date or ""),
                "fiscal_period": (
                    f"{item.period[0]}Q{item.period[1]}" if item.period else ""),
                "reference": item.reference,
            }
            for item in resolution.evidence
        ], ensure_ascii=False, sort_keys=True)
        conflicts_json = json.dumps([
            conflict.__dict__ for conflict in resolution.conflicts
        ], ensure_ascii=False, sort_keys=True)
        self.conn.execute(
            "INSERT OR REPLACE INTO earnings_events (event_id,entity,report_date,"
            "fiscal_year,fiscal_quarter,status,evidence_json,conflicts_json,resolved_at) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (event_id, entity, report_date, fiscal_year, fiscal_quarter, resolution.status,
             evidence_json, conflicts_json,
             datetime.now(timezone.utc).isoformat(timespec="seconds")))
        self.conn.commit()
        return event_id

    def earnings_events(self, entity: str | None = None, *, limit: int = 50) -> list[dict]:
        sql, args = "SELECT * FROM earnings_events", []
        if entity:
            sql += " WHERE entity=?"
            args.append(entity.upper())
        sql += " ORDER BY report_date DESC,resolved_at DESC LIMIT ?"
        args.append(limit)
        return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    def documents(self, entity: str | None = None, *, ok_only: bool = True,
                  doc_type: str | None = None, source_contains: str | None = None,
                  published_since: str | None = None, limit: int = 200) -> list[dict]:
        from ..data.document_types import compatible_type_values

        doc_type_in: tuple[str, ...] | None = None
        if doc_type:
            try:
                doc_type_in = compatible_type_values(doc_type)
            except (KeyError, ValueError):
                doc_type_in = None
        return self.data_store().documents(
            entity, ok_only=ok_only, doc_type=None if doc_type_in else doc_type,
            source_contains=source_contains, published_since=published_since, limit=limit,
            doc_type_in=doc_type_in)

    def document_by_external_id(self, external_id: str) -> dict | None:
        return self.data_store().document_by_external_id(external_id)

    def has_document(self, entity: str, period: str, doc_type: str) -> bool:
        from ..data.document_types import compatible_type_values

        try:
            current, legacy = compatible_type_values(doc_type)
        except (KeyError, ValueError):
            current = legacy = doc_type
        return self.data_store().has_document([
            f"{entity.upper()}:{period or 'unknown'}:{current}",
            f"{entity.upper()}:{period or 'unknown'}:{legacy}"])

    def freeze_as_discovery(self, observation_ids: list[str]) -> int:
        """Mark observations as the material that MADE us notice a proposition.

        Frozen material explains "why look"; it may never also count as "it is true"
        (see docs/CHAIN_EVIDENCE.md §6.5). Returns rows affected.
        """
        return self.data_store().freeze_observations_as_discovery(observation_ids)

    def unmapped_observations(self, *, limit: int = 500) -> list[dict]:
        """Facts we stored but could file under no declared claim dimension.

        These are the raw material for induction: information the system already holds
        that has no home yet. Discovery-frozen rows are excluded — they already
        triggered a proposal and must not trigger another.
        """
        return self.data_store().unmapped_observations(limit=limit)

    def save_claim_proposal(self, proposal) -> None:
        import json

        self.conn.execute(
            "INSERT OR REPLACE INTO claim_proposals (id,signature,statement,layer_hint,"
            " kind,subject,status,created_at,reviewed_at,reviewer,rationale,payload)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
            (proposal.id, proposal.signature, proposal.statement, proposal.layer_hint,
             proposal.kind, proposal.subject, proposal.status,
             proposal.created_at.isoformat(),
             proposal.reviewed_at.isoformat() if proposal.reviewed_at else None,
             proposal.reviewer, proposal.rationale,
             json.dumps(proposal.model_dump(mode="json"), ensure_ascii=False)))
        self.conn.commit()

    def claim_proposals(self, *, status: str | None = None, limit: int = 50) -> list[dict]:
        sql = "SELECT * FROM claim_proposals"
        args: list = []
        if status:
            sql += " WHERE status = ?"
            args.append(status)
        sql += " ORDER BY created_at DESC LIMIT ?"
        args.append(limit)
        return [dict(r) for r in self.conn.execute(sql, args).fetchall()]

    def proposal_by_signature(self, signature: str) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM claim_proposals WHERE signature = ? ORDER BY created_at DESC "
            "LIMIT 1", (signature,)).fetchone()
        return dict(row) if row else None

    def set_proposal_status(self, proposal_id: str, status: str, *, reviewer: str = "",
                            rationale: str = "", at=None) -> bool:
        at = at or datetime.now(timezone.utc)
        cur = self.conn.execute(
            "UPDATE claim_proposals SET status = ?, reviewed_at = ?, reviewer = ?,"
            " rationale = ? WHERE id = ?",
            (status, at.isoformat(), reviewer, rationale, proposal_id))
        self.conn.commit()
        return cur.rowcount > 0

    def recent_events(self, symbol: str, limit: int = 20) -> list[dict]:
        rows = self.conn.execute(
            "SELECT * FROM pead_events WHERE symbol = ? ORDER BY published_at DESC LIMIT ?",
            (symbol, limit)).fetchall()
        return [dict(r) for r in rows]

    def count_events(self, symbol: str) -> int:
        return self.conn.execute("SELECT COUNT(*) c FROM pead_events WHERE symbol = ?",
                                 (symbol,)).fetchone()["c"]

    def set_triage(self, scores: dict[str, tuple[float, str]]) -> None:
        """Persist triage results: {event_id: (materiality, category)}."""
        if not scores:
            return
        self.conn.executemany(
            "UPDATE pead_events SET triage_score = ?, triage_category = ? WHERE id = ?",
            [(score, cat, eid) for eid, (score, cat) in scores.items()])
        self.conn.commit()

    # ----------------------------------------------------------------- #
    # Shared structured observations (raw accepted points, never derivatives)
    # ----------------------------------------------------------------- #
    def register_data_source(self, source, *, kind: str = "structured",
                             at: datetime | None = None) -> None:
        self.data_store().register_data_source(source, kind=kind, at=at)

    def begin_ingestion(self, source_id: str, *, kind: str,
                        at: datetime | None = None) -> str:
        return self.data_store().begin_ingestion(source_id, kind=kind, at=at)

    def finish_ingestion(self, run_id: str, *, status: str, discovered: int = 0,
                         accepted: int = 0, quarantined: int = 0,
                         reason_codes: dict | list | tuple | None = None,
                         snapshot_updated_at: str = "",
                         snapshot_lag_hours: float | None = None, note: str = "",
                         at: datetime | None = None) -> None:
        self.data_store().finish_ingestion(
            run_id, status=status, discovered=discovered, accepted=accepted,
            quarantined=quarantined, reason_codes=reason_codes,
            snapshot_updated_at=snapshot_updated_at, snapshot_lag_hours=snapshot_lag_hours,
            note=note, at=at)

    def ingestion_history(self, source_id: str | None = None, *,
                          limit: int = 100) -> list[dict]:
        return self.data_store().ingestion_runs(source_id, limit=limit)

    def data_source_health(self) -> list[dict]:
        return self.data_store().data_source_health()

    def document_source_health(self) -> list[dict]:
        return self.data_store().document_source_health()

    def document_candidate_health(self) -> list[dict]:
        """Admission totals and reason codes by source/status for release reports."""
        return self.data_store().document_candidate_health()

    def document_quality_inventory(self) -> list[dict]:
        """Accepted inventory grouped by source, semantic and completeness."""
        return self.data_store().document_quality_inventory()

    def save_measurement_points(self, source, points, *,
                                fetched_at: datetime | None = None) -> int:
        return self.data_store().save_measurement_points(source, points, fetched_at=fetched_at)

    def measurements(self, *, source_id: str | None = None,
                     series: str | None = None, since: str | None = None,
                     entity: str | None = None,
                     as_of: datetime | None = None, latest_only: bool = True,
                     limit: int = 5000) -> list[dict]:
        """Query point vintages, optionally as they were knowable at `as_of`."""
        return self.data_store().measurements(
            source_id=source_id, series=series, since=since, entity=entity, as_of=as_of,
            latest_only=latest_only, limit=limit)

    def save_task_projection(self, *, profile: str, profile_version: str,
                             input_kind: str, input_ref: str,
                             target_type: str, target_id: str, payload,
                             created_at: str | None = None,
                             expires_at: str = "") -> str:
        """Persist one versioned task interpretation without changing its input."""
        import hashlib
        import json

        from ..workflow.cutover_wiring import guard_analyst_output

        guard_analyst_output(store=self, what="a legacy task projection")

        stamp = created_at or datetime.now(timezone.utc).isoformat(timespec="seconds")
        projection_id = hashlib.sha1(
            f"{profile}|{profile_version}|{input_kind}|{input_ref}|"
            f"{target_type}|{target_id}".encode()).hexdigest()[:20]
        if hasattr(payload, "model_dump"):
            body = payload.model_dump(mode="json")
        else:
            body = payload
        encoded = json.dumps(body, ensure_ascii=False, sort_keys=True)
        self.conn.execute(
            "INSERT OR REPLACE INTO task_projections "
            "(projection_id,profile,profile_version,input_kind,input_ref,target_type,"
            " target_id,payload,created_at,expires_at) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (projection_id, profile, profile_version, input_kind, input_ref,
             target_type, target_id, encoded, stamp, expires_at))
        self.conn.commit()
        return projection_id

    def task_projections(self, *, profile: str | None = None,
                         target_type: str | None = None,
                         target_id: str | None = None,
                         input_ref: str | None = None,
                         limit: int = 500) -> list[dict]:
        sql, args = "SELECT * FROM task_projections WHERE 1=1", []
        for column, value in (("profile", profile), ("target_type", target_type),
                              ("target_id", target_id), ("input_ref", input_ref)):
            if value:
                sql += f" AND {column}=?"
                args.append(value)
        sql += " ORDER BY created_at DESC LIMIT ?"
        args.append(limit)
        return [dict(r) for r in self.conn.execute(sql, args).fetchall()]

    def projection_lineage(self, projection_id: str) -> dict | None:
        """Resolve either projection family back to its fact/document/source input.

        Split across the boundary on purpose: `task_projections` is Workflow memory's
        own table (it is NOT one of the retired data tables), while evidence
        projections, facts, document versions and documents all belong to the data
        layer. The data store resolves both families; we only supply the local row.
        """
        task = self.conn.execute(
            "SELECT * FROM task_projections WHERE projection_id=?", (projection_id,)
        ).fetchone()
        return self.data_store().projection_lineage(
            projection_id, task_projection=dict(task) if task else None)

    # --- unified agent-output envelopes ------------------------------------ #
    def save_task_projection_envelope(self, envelope) -> str:
        """Publish one validated agent output. Returns `projection_id`.

        Validation happens in `ats.agent.task_projection.build_envelope`, before this
        point: a rejected payload never reaches storage, so there is no code path here
        that could degrade it into free text.

        Idempotent by content: a retry with the same role, scope, inputs and payload
        rewrites the same row instead of adding a twin.
        """
        import json

        from ..workflow.cutover_wiring import guard_analyst_output

        guard_analyst_output(store=self, what="a task projection envelope")

        # Timed-out/retried Dispatcher attempts may finish after their caller has
        # moved on. Do not allow such a late worker to publish into the durable
        # projection set after its attempt has been cancelled or superseded.
        if self._task_scoped and envelope.agent_run_id:
            attempt = self.conn.execute(
                "SELECT status FROM agent_runs WHERE agent_run_id=? AND run_id=?",
                (envelope.agent_run_id, envelope.workflow_run_id)).fetchone()
            if attempt is None or attempt["status"] != "running":
                raise RuntimeError(
                    f"projection publish fenced: agent attempt {envelope.agent_run_id!r} "
                    "is not the active attempt for this run")

        scope = envelope.scope
        self.conn.execute(
            "INSERT OR REPLACE INTO task_projection_envelopes "
            "(projection_id,workflow_run_id,agent_run_id,agent_role,scope_kind,scope_id,"
            " as_of,valid_until,schema_name,schema_version,input_refs,data_vintage_refs,"
            " model_version,prompt_version,payload,content_hash,status,created_at,"
            " supersedes_projection_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (envelope.projection_id, envelope.workflow_run_id, envelope.agent_run_id,
             envelope.agent_role, scope.kind, scope.id, envelope.as_of,
             envelope.valid_until, envelope.schema_name, envelope.schema_version,
             json.dumps(envelope.input_refs, ensure_ascii=False, sort_keys=True),
             json.dumps(envelope.data_vintage_refs, ensure_ascii=False, sort_keys=True),
             envelope.model_version, envelope.prompt_version,
             json.dumps(envelope.payload, ensure_ascii=False, sort_keys=True),
             envelope.content_hash, envelope.status, envelope.created_at,
             envelope.supersedes_projection_id))
        self.conn.commit()
        return envelope.projection_id

    def get_task_projection(self, projection_id: str) -> dict | None:
        """One envelope row by id (refs/payload decoded), regardless of status.

        Snapshot consumers use this to re-verify that the projection a frozen
        research snapshot cites still exists, is still published, and still
        hashes to the same content (decision/research-snapshot, task 7.7).
        """
        import json

        row = self.conn.execute(
            "SELECT * FROM task_projection_envelopes WHERE projection_id=?",
            (projection_id,)).fetchone()
        if row is None:
            return None
        item = dict(row)
        for column in ("input_refs", "data_vintage_refs", "payload"):
            try:
                item[column] = json.loads(item[column] or "")
            except json.JSONDecodeError:
                item[column] = {}
        return item

    def task_projection_envelopes(self, *, agent_role: str | None = None,
                                  scope_kind: str | None = None,
                                  scope_id: str | None = None,
                                  workflow_run_id: str | None = None,
                                  status: str | None = "published",
                                  limit: int = 500) -> list[dict]:
        """Read envelopes back as rows; refs and payload are decoded from JSON."""
        import json

        sql, args = "SELECT * FROM task_projection_envelopes WHERE 1=1", []
        for column, value in (("agent_role", agent_role), ("scope_kind", scope_kind),
                              ("scope_id", scope_id),
                              ("workflow_run_id", workflow_run_id), ("status", status)):
            if value:
                sql += f" AND {column}=?"
                args.append(value)
        sql += " ORDER BY created_at DESC LIMIT ?"
        args.append(limit)
        rows = []
        for row in self.conn.execute(sql, args).fetchall():
            item = dict(row)
            for column in ("input_refs", "data_vintage_refs", "payload"):
                try:
                    item[column] = json.loads(item[column] or "")
                except json.JSONDecodeError:
                    item[column] = {}
            rows.append(item)
        return rows

    def reusable_task_projection(self, *, agent_role, scope, input_refs=None,
                                 data_vintage_refs=None, schema_name=None,
                                 schema_version=None, at=None):
        """Latest still-usable envelope for a role and scope, or `None`.

        Delegates the four reuse conditions (freshness, scope coverage, schema
        compatibility, unchanged key vintages) to the contract in `ats.agent`, so the
        rule lives in one place rather than being re-derived per query.
        """
        return self._reusable_envelope(
            agent_role=agent_role, scope=scope, input_refs=input_refs,
            data_vintage_refs=data_vintage_refs, schema_name=schema_name,
            schema_version=schema_version, at=at)

    def _reusable_envelope(self, *, agent_role, scope, input_refs, data_vintage_refs,
                           schema_name, schema_version, at):
        import json

        from ..agent.task_projection import (ProjectionScope, TaskProjectionEnvelope,
                                             reuse_decision)

        target = scope if isinstance(scope, ProjectionScope) else ProjectionScope(
            kind=scope["kind"], id=scope.get("id", ""))
        sql = ("SELECT * FROM task_projection_envelopes WHERE agent_role=? "
               "AND scope_kind=? AND scope_id=? AND status='published' "
               "ORDER BY created_at DESC")
        rows = self.conn.execute(sql, (agent_role, target.kind, target.id)).fetchall()
        for row in rows:
            item = dict(row)
            try:
                payload = json.loads(item["payload"] or "{}")
                input_refs_row = json.loads(item["input_refs"] or "[]")
                vintage_refs_row = json.loads(item["data_vintage_refs"] or "[]")
            except json.JSONDecodeError:
                continue
            envelope = TaskProjectionEnvelope(
                projection_id=item["projection_id"],
                workflow_run_id=item["workflow_run_id"] or "",
                agent_run_id=item["agent_run_id"] or "",
                agent_role=item["agent_role"], scope=target, as_of=item["as_of"],
                valid_until=item["valid_until"] or "", schema_name=item["schema_name"],
                schema_version=item["schema_version"], input_refs=input_refs_row,
                data_vintage_refs=vintage_refs_row,
                model_version=item["model_version"] or "",
                prompt_version=item["prompt_version"] or "", payload=payload,
                content_hash=item["content_hash"], status=item["status"],
                created_at=item["created_at"] or "",
                supersedes_projection_id=item["supersedes_projection_id"] or "")
            reusable, reason = reuse_decision(
                envelope, scope=target, input_refs=input_refs,
                data_vintage_refs=data_vintage_refs, schema_name=schema_name,
                schema_version=schema_version, at=at)
            if reusable:
                return envelope
            if reason in ("expired", "schema_mismatch", "schema_version_mismatch"):
                # A newer row cannot repair these; stop scanning older ones.
                break
        return None

    # --- research (newsletters) ------------------------------------------ #
    def admitted_research_articles(self, since, *, limit: int = 500,
                                   allow_incomplete: bool = True) -> list:
        """Admitted research articles via the data-product read router (Phase D).

        The information analyst reads admitted documents through this bridge —
        it never imports `ats.data.*` provider modules directly, so the
        `agent/information-analyst` guard (no provider imports) can pass while
        the read-router and consumer-policy selection stay in the data layer.
        Applies the research-article consumer policy (full texts, or partial
        previews from sources that publish them intentionally).
        """
        from ..data.research import is_pead_research_article, stored_articles

        # `store=self` matches the pre-Phase-D caller pattern: stored_articles
        # treats this Workflow-Memory instance as the legacy repository and the
        # router decides platform vs legacy by the consumer's release mode.
        candidates = stored_articles(since, store=self,
                                     allow_incomplete=allow_incomplete,
                                     consumer="information_analyst")
        return [a for a in candidates if is_pead_research_article(a)]

    def admitted_document_body(self, external_id: str, *, min_chars: int = 800) -> str:
        """Already-admitted article body, or "" — never a network fetch.

        Phase D: the information analyst's full-text path is read-only over
        admitted document assets. An item whose body was never ingested is
        simply unavailable (its metadata still makes it into the brief); the
        pre-Phase-D behavior of fetching the URL on the fly from an agent is
        retired with the provider-direct-connection cleanup.
        """
        from ..data import document_assets

        row, cached = document_assets.read_external(external_id,
                                                    store=self.data_store())
        if row and len(cached) >= min_chars:
            return cached
        return ""

    def admitted_news_body(self, item, *, min_chars: int = 800) -> str:
        """Already-admitted news article body by cross-provider identity (Phase D).

        Read-only bridge over admitted document assets — the caller (information
        analyst) never imports the news provider module and never fetches. An
        item whose body was never ingested returns "".
        """
        from ..data import document_assets
        from ..data.news import external_id

        row, cached = document_assets.read_external(external_id(item),
                                                    store=self.data_store())
        if row and len(cached) >= min_chars:
            return cached
        return ""

    def article_seen(self, article_id: str) -> bool:
        return self.conn.execute("SELECT 1 FROM research_articles WHERE id = ?",
                                 (article_id,)).fetchone() is not None

    def save_article(self, art) -> None:
        """Legacy compatibility index; the body lives in the shared document store."""
        from datetime import datetime, timezone

        self.conn.execute(
            "INSERT OR IGNORE INTO research_articles VALUES (?,?,?,?,?,?,?)",
            (art.id, art.source, art.title, art.url, art.published_at.isoformat(),
             datetime.now(timezone.utc).isoformat(), len(art.body)))
        self.conn.commit()

    def insight_count(self, article_id: str) -> int:
        row = self.conn.execute(
            "SELECT count(*) AS n FROM research_insights WHERE article_id = ?",
            (article_id,)).fetchone()
        return int(row["n"] if row else 0)

    def save_insights(self, article_id: str, insights, *,
                      profile_version: str = "v1") -> None:
        from datetime import datetime, timezone

        now = datetime.now(timezone.utc).isoformat()
        from ..workflow.runtime_reads import current_read_context
        from ..workflow.isolation import verified_isolation_root

        context = current_read_context()
        if context and (context.route == "target" or verified_isolation_root() is not None):
            # Target extraction already carries the canonical admitted document
            # ID. Resolve its immutable version through the product boundary.
            from ..data.products.unstructured import admitted_documents

            admitted = admitted_documents(entities=context.identity.scope["entities"],
                                          as_of=context.cutoff, limit=500)
            selected = next((d for d in admitted if d.document_id == article_id), None)
            version = {"version_id": selected.version_id} if selected else None
            if not selected:
                raise ValueError("insight_input_document_not_admitted")
        else:
            doc = self.document_by_external_id(article_id)
            version = self.latest_document_version(doc["document_id"]) if doc else None
        input_kind = "document_version" if version else "external_article"
        input_ref = version["version_id"] if version else article_id
        self.conn.executemany(
            "INSERT INTO research_insights VALUES (?,?,?,?,?,?,?,?)",
            [(article_id, i.ticker, i.direction, i.impact_path, i.summary,
              i.evidence_quote, i.confidence, now) for i in insights])
        self.conn.commit()
        for insight in insights:
            self.save_task_projection(
                profile="pead_research", profile_version=profile_version,
                input_kind=input_kind, input_ref=input_ref,
                target_type="entity", target_id=insight.ticker.upper(), payload=insight,
                created_at=now)

    def recent_insights(self, ticker: str | None = None, limit: int = 20) -> list[dict]:
        if ticker:
            rows = self.conn.execute(
                "SELECT * FROM research_insights WHERE ticker = ? ORDER BY rowid DESC LIMIT ?",
                (ticker, limit)).fetchall()
        else:
            rows = self.conn.execute(
                "SELECT * FROM research_insights ORDER BY rowid DESC LIMIT ?",
                (limit,)).fetchall()
        return [dict(r) for r in rows]

    def newsletter_cursor(self, mailbox: str, folder: str, sender: str) -> dict | None:
        return self.data_store().newsletter_cursor(mailbox, folder, sender.lower())

    def save_newsletter_cursor(self, *, mailbox: str, folder: str, sender: str,
                               uidvalidity: str, last_uid: int,
                               last_message_id: str, watermark: str) -> None:
        self.data_store().save_newsletter_cursor(
            mailbox=mailbox, folder=folder, sender=sender.lower(), uidvalidity=uidvalidity,
            last_uid=int(last_uid), last_message_id=last_message_id, watermark=watermark)

    # --- sector reviews --------------------------------------------------- #
    def save_sector_review(self, review) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO sector_reviews VALUES (?,?,?,?,?)",
            (review.sector, review.as_of.isoformat(), review.regime, review.summary,
             review.model_dump_json()))
        self.conn.commit()
        self.save_task_projection(
            profile="sector_review", profile_version="v1",
            input_kind="review_context",
            input_ref=f"sector:{review.sector}:{review.as_of.isoformat()}",
            target_type="sector", target_id=review.sector, payload=review,
            created_at=review.as_of.isoformat())

    def latest_sector_review(self, sector: str):
        from ..schemas.sector import SectorReview

        row = self.conn.execute(
            "SELECT payload FROM sector_reviews WHERE sector = ? ORDER BY as_of DESC LIMIT 1",
            (sector,)).fetchone()
        return SectorReview.model_validate_json(row["payload"]) if row else None

    def layer_verdict_history(self, sector: str, layer_key: str, limit: int = 12) -> list:
        """This layer's allocation calls over time, newest first.

        Returns (verdict, is_legacy) pairs. `is_legacy` marks rows recorded under a key
        that predates a split — those calls were made under a COARSER lens (one verdict
        covering what is now two layers), so a caller comparing them against today's
        must be able to say so rather than plotting them as one continuous series.
        """
        from ..config import load_sector_config

        try:
            cfg = load_sector_config(sector)
        except Exception:  # noqa: BLE001 - history must not depend on a loadable config
            keys, legacy = {layer_key}, set()
        else:
            layer = cfg.layer_by_key(layer_key)
            legacy = set(layer.legacy_keys) if layer else set()
            keys = {layer.key, *legacy} if layer else {layer_key}

        out = []
        for review in self.sector_review_history(sector, limit=limit):
            for v in getattr(review, "layer_verdicts", []):
                if v.layer_key in keys:
                    out.append((v, v.layer_key in legacy))
        return out

    def sector_review_history(self, sector: str, limit: int = 8) -> list:
        """Recent reviews in full, newest first — payloads, not just the summary row.

        A weekly run often assesses one layer, so `latest_sector_review` alone answers
        "what do we currently think about L3?" with silence. Readers that need the most
        recent view PER LAYER have to walk backwards through several reviews.
        """
        from ..schemas.sector import SectorReview

        rows = self.conn.execute(
            "SELECT payload FROM sector_reviews WHERE sector = ? ORDER BY as_of DESC "
            "LIMIT ?", (sector, limit)).fetchall()
        out = []
        for r in rows:
            try:
                out.append(SectorReview.model_validate_json(r["payload"]))
            except Exception as exc:  # noqa: BLE001 — one bad row must not hide the rest
                log.warning("sector review payload skipped: %s", exc)
        return out

    def recent_sector_reviews(self, sector: str, limit: int = 8) -> list[dict]:
        rows = self.conn.execute(
            "SELECT sector, as_of, regime, summary FROM sector_reviews "
            "WHERE sector = ? ORDER BY as_of DESC LIMIT ?", (sector, limit)).fetchall()
        return [dict(r) for r in rows]

    # --- macro reviews ---------------------------------------------------- #
    def save_macro_review(self, review) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO macro_reviews VALUES (?,?,?,?,?)",
            (review.name, review.as_of.isoformat(), review.regime, review.summary,
             review.model_dump_json()))
        self.conn.commit()

    def latest_macro_review(self, name: str = "macro"):
        from ..schemas.macro_strategy import MacroReview

        row = self.conn.execute(
            "SELECT payload FROM macro_reviews WHERE name = ? ORDER BY as_of DESC LIMIT 1",
            (name,)).fetchone()
        return MacroReview.model_validate_json(row["payload"]) if row else None

    def latest_macro_review_before(self, name: str, before_date):
        """Latest full review from an earlier calendar day.

        Same-day reruns overwrite the report file and must keep comparing with
        the previous formal period; otherwise the first imperfect rerun consumes
        the delta and a corrected rerun minutes later says "nothing changed".
        """
        from ..schemas.macro_strategy import MacroReview

        day = before_date.isoformat() if hasattr(before_date, "isoformat") else str(before_date)
        row = self.conn.execute(
            "SELECT payload FROM macro_reviews WHERE name = ? "
            "AND substr(as_of, 1, 10) < ? ORDER BY as_of DESC LIMIT 1",
            (name, day)).fetchone()
        return MacroReview.model_validate_json(row["payload"]) if row else None

    def recent_macro_reviews(self, name: str = "macro", limit: int = 8) -> list[dict]:
        rows = self.conn.execute(
            "SELECT name, as_of, regime, summary FROM macro_reviews "
            "WHERE name = ? ORDER BY as_of DESC LIMIT ?", (name, limit)).fetchall()
        return [dict(r) for r in rows]

    # --- technical reviews ------------------------------------------------ #
    # `as_of` is stored as a DATE, not a timestamp: the analyst runs once per
    # session, so a same-day rerun must overwrite rather than accumulate rows.
    def save_technical_review(self, review) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO technical_reviews VALUES (?,?,?,?)",
            (review.name, review.as_of.date().isoformat(), review.summary_line(),
             review.model_dump_json()))
        self.conn.commit()

    def latest_technical_review(self, name: str = "technical"):
        from ..schemas.technical import TechnicalReview

        row = self.conn.execute(
            "SELECT payload FROM technical_reviews WHERE name = ? "
            "ORDER BY as_of DESC LIMIT 1", (name,)).fetchone()
        return TechnicalReview.model_validate_json(row["payload"]) if row else None

    def previous_technical_review(self, name: str = "technical", *, before: str = ""):
        """The most recent review STRICTLY before `before` (an ISO date).

        Change detection ("NVDA dropped from 100% to 50%") needs yesterday's
        reading; without the strict bound a same-day rerun would compare against
        the row it is about to overwrite and always report "no change".
        """
        from ..schemas.technical import TechnicalReview

        row = self.conn.execute(
            "SELECT payload FROM technical_reviews WHERE name = ? AND as_of < ? "
            "ORDER BY as_of DESC LIMIT 1", (name, before)).fetchone()
        return TechnicalReview.model_validate_json(row["payload"]) if row else None

    def recent_technical_reviews(self, name: str = "technical", limit: int = 8) -> list[dict]:
        rows = self.conn.execute(
            "SELECT name, as_of, summary FROM technical_reviews "
            "WHERE name = ? ORDER BY as_of DESC LIMIT ?", (name, limit)).fetchall()
        return [dict(r) for r in rows]

    def close(self) -> None:
        if self._closed:
            return
        self.conn.close()
        if self._data is not None and hasattr(self._data, "close"):
            self._data.close()
        self._closed = True
