---
symbol: COHR
period: Q3 FY2026
doc_type: company_release
document_key: pair-release
source: ibkr_news
source_url: fixture:pair-release
fetched_at: '2026-10-09T03:41:18+00:00'
sha256: fb2e3e9fd4be3f39434179c777337c88da93210568bc1f272e56996696fe495d
chars: 1259
external_id: ''
title: Q3 FY2026 results
published_at: '2026-10-09T03:41:18.876451+00:00'
related_entities: ''
completeness: full
truncation_reason: ''
carrier_format: plain_text
mime_source: ''
---

Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3. Q3 FY2026 results revenue 120 earnings 3.