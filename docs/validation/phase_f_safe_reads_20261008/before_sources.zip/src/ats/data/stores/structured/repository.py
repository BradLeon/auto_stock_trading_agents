"""SQLite repository for governed structured research observations.

The repository owns additive structured tables only. Existing workflow and
measurement tables are read through compatibility methods and are never rewritten.
"""

from __future__ import annotations

from datetime import datetime, timezone
from functools import lru_cache
import hashlib
import json
import os
from pathlib import Path
import sqlite3
from threading import RLock
from typing import Protocol

from .artifacts import ArtifactStore, default_artifact_root
from ...catalog.structured import StructuredCatalog
from ...core.structured_models import (
    ArtifactDescriptor, EvidenceLink, MetricDefinition, ObservationInput,
    ObservationVintage, ProviderMapping, RawArtifact, SeriesIdentity,
    StructuredDataset, StructuredSource,
)


_SCHEMA = """
CREATE TABLE IF NOT EXISTS structured_migrations (
    key TEXT PRIMARY KEY, applied_at TEXT NOT NULL, note TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS structured_sources (
    source_id TEXT PRIMARY KEY, provider TEXT NOT NULL, adapter TEXT NOT NULL,
    persistence TEXT NOT NULL, catalog_status TEXT NOT NULL, cadence TEXT NOT NULL,
    retention TEXT NOT NULL, upstream TEXT NOT NULL, datasets_json TEXT NOT NULL,
    constraints_json TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS structured_datasets (
    dataset_id TEXT PRIMARY KEY, catalog_status TEXT NOT NULL,
    expected_cadence TEXT NOT NULL, primary_sources_json TEXT NOT NULL,
    fallback_sources_json TEXT NOT NULL, core_metrics_json TEXT NOT NULL,
    quality_json TEXT NOT NULL, entities_json TEXT NOT NULL,
    acceptance_samples_json TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS structured_metrics (
    metric_id TEXT PRIMARY KEY, value_type TEXT NOT NULL, unit_family TEXT NOT NULL,
    cadence TEXT NOT NULL, period_basis_json TEXT NOT NULL, adjustment TEXT NOT NULL,
    derived INTEGER NOT NULL DEFAULT 0, description TEXT NOT NULL,
    definition_version TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS structured_provider_mappings (
    provider TEXT NOT NULL, provider_field TEXT NOT NULL, mapping_version TEXT NOT NULL,
    metric_id TEXT NOT NULL, dimensions_json TEXT NOT NULL,
    PRIMARY KEY (provider, provider_field, mapping_version)
);
CREATE INDEX IF NOT EXISTS idx_structured_mapping_metric
    ON structured_provider_mappings(metric_id, provider);
CREATE TABLE IF NOT EXISTS structured_pending_mappings (
    pending_id TEXT PRIMARY KEY, provider TEXT NOT NULL, dataset_id TEXT NOT NULL,
    provider_field TEXT NOT NULL, sample_payload TEXT NOT NULL, status TEXT NOT NULL,
    first_seen_at TEXT NOT NULL, last_seen_at TEXT NOT NULL, seen_count INTEGER NOT NULL,
    UNIQUE(provider, dataset_id, provider_field)
);
CREATE TABLE IF NOT EXISTS structured_artifact_blobs (
    blob_id TEXT PRIMARY KEY, content_hash TEXT NOT NULL UNIQUE,
    relative_path TEXT NOT NULL, bytes INTEGER NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS structured_artifacts (
    artifact_id TEXT PRIMARY KEY, blob_id TEXT NOT NULL, source_id TEXT NOT NULL,
    dataset_id TEXT NOT NULL, fetched_at TEXT NOT NULL, query_scope_json TEXT NOT NULL,
    query_hash TEXT NOT NULL, source_url TEXT NOT NULL, source_version TEXT NOT NULL,
    media_type TEXT NOT NULL, retention TEXT NOT NULL, storage_mode TEXT NOT NULL,
    pointer TEXT NOT NULL, metadata_json TEXT NOT NULL,
    UNIQUE(source_id, dataset_id, query_hash, blob_id)
);
CREATE INDEX IF NOT EXISTS idx_structured_artifact_source
    ON structured_artifacts(source_id, dataset_id, fetched_at);
CREATE TABLE IF NOT EXISTS structured_series (
    series_id TEXT PRIMARY KEY, identity_hash TEXT NOT NULL UNIQUE,
    source_id TEXT NOT NULL, dataset_id TEXT NOT NULL, entity_id TEXT NOT NULL,
    metric_id TEXT NOT NULL, unit TEXT NOT NULL, currency TEXT NOT NULL,
    period_basis TEXT NOT NULL, adjustment TEXT NOT NULL,
    dimensions_json TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_structured_series_lookup
    ON structured_series(dataset_id, entity_id, metric_id, source_id);
CREATE TABLE IF NOT EXISTS structured_observations (
    observation_id TEXT PRIMARY KEY, series_id TEXT NOT NULL, period TEXT NOT NULL,
    period_start TEXT NOT NULL, period_end TEXT NOT NULL, event_time TEXT NOT NULL,
    value REAL NOT NULL, published_at TEXT NOT NULL, known_at TEXT NOT NULL,
    fetched_at TEXT NOT NULL, artifact_id TEXT NOT NULL, content_hash TEXT NOT NULL,
    quality_status TEXT NOT NULL, quality_json TEXT NOT NULL, raw_payload TEXT NOT NULL,
    UNIQUE(series_id, period, content_hash)
);
CREATE INDEX IF NOT EXISTS idx_structured_observation_lookup
    ON structured_observations(series_id, period, known_at);
CREATE TABLE IF NOT EXISTS structured_derivations (
    derivation_id TEXT NOT NULL, definition_version TEXT NOT NULL,
    operation TEXT NOT NULL, inputs_json TEXT NOT NULL, parameters_json TEXT NOT NULL,
    output_metric_id TEXT NOT NULL, updated_at TEXT NOT NULL,
    PRIMARY KEY (derivation_id, definition_version)
);
CREATE TABLE IF NOT EXISTS structured_evidence_links (
    link_id TEXT PRIMARY KEY, observation_id TEXT NOT NULL, candidate_id TEXT NOT NULL,
    document_id TEXT NOT NULL, version_id TEXT NOT NULL, char_start INTEGER NOT NULL,
    char_end INTEGER NOT NULL, anchor_kind TEXT NOT NULL DEFAULT 'text_span',
    page_number INTEGER, chart_id TEXT NOT NULL DEFAULT '', region_json TEXT NOT NULL DEFAULT '',
    extraction_method TEXT NOT NULL, source_tier TEXT NOT NULL,
    verification_status TEXT NOT NULL, reviewer TEXT NOT NULL, reviewed_at TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_structured_evidence_target
    ON structured_evidence_links(candidate_id, observation_id, verification_status);
CREATE TABLE IF NOT EXISTS structured_entities (
    entity_id TEXT PRIMARY KEY, kind TEXT NOT NULL, canonical_name TEXT NOT NULL,
    aliases_json TEXT NOT NULL, securities_json TEXT NOT NULL,
    metadata_json TEXT NOT NULL DEFAULT '{}', updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS structured_entity_relations (
    relation_id TEXT PRIMARY KEY, dataset_id TEXT NOT NULL, source_id TEXT NOT NULL,
    parent_entity_id TEXT NOT NULL, child_entity_id TEXT NOT NULL,
    relation_type TEXT NOT NULL, source_version TEXT NOT NULL, known_at TEXT NOT NULL,
    artifact_id TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
    metadata_json TEXT NOT NULL,
    UNIQUE(dataset_id,source_id,parent_entity_id,child_entity_id,relation_type,source_version,active,metadata_json)
);
CREATE INDEX IF NOT EXISTS idx_structured_entity_relation_parent
    ON structured_entity_relations(dataset_id,source_id,parent_entity_id,relation_type,known_at);
CREATE INDEX IF NOT EXISTS idx_structured_entity_relation_child
    ON structured_entity_relations(dataset_id,source_id,child_entity_id,relation_type,known_at);
CREATE TABLE IF NOT EXISTS structured_frontier_capability_methods (
    benchmark_id TEXT NOT NULL, method_version TEXT NOT NULL, comparability_group TEXT NOT NULL,
    metadata_json TEXT NOT NULL, first_seen_at TEXT NOT NULL, last_seen_at TEXT NOT NULL,
    PRIMARY KEY (benchmark_id, method_version, comparability_group)
);
CREATE TABLE IF NOT EXISTS structured_frontier_capability_coverage (
    lab_id TEXT NOT NULL, model_id TEXT NOT NULL, benchmark_id TEXT NOT NULL,
    coverage_state TEXT NOT NULL, method_version TEXT NOT NULL DEFAULT '',
    known_at TEXT NOT NULL, source_id TEXT NOT NULL, metadata_json TEXT NOT NULL,
    PRIMARY KEY (lab_id, model_id, benchmark_id, method_version, source_id)
);
CREATE TABLE IF NOT EXISTS structured_relation_candidates (
    candidate_id TEXT PRIMARY KEY, run_id TEXT NOT NULL, source_id TEXT NOT NULL,
    dataset_id TEXT NOT NULL, parent_entity_id TEXT NOT NULL, child_entity_id TEXT NOT NULL,
    relation_type TEXT NOT NULL, source_version TEXT NOT NULL, status TEXT NOT NULL,
    reason_codes_json TEXT NOT NULL, artifact_id TEXT NOT NULL, raw_payload TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS structured_events (
    event_id TEXT PRIMARY KEY, dataset_id TEXT NOT NULL, entity_id TEXT NOT NULL,
    event_type TEXT NOT NULL, event_date TEXT NOT NULL, event_label TEXT NOT NULL,
    status TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
    UNIQUE(dataset_id, entity_id, event_type, event_date, event_label)
);
CREATE TABLE IF NOT EXISTS structured_evidence_candidates (
    candidate_id TEXT PRIMARY KEY, event_id TEXT NOT NULL, source_id TEXT NOT NULL,
    dataset_id TEXT NOT NULL, entity_id TEXT NOT NULL, metric_id TEXT NOT NULL,
    period TEXT NOT NULL, event_time TEXT NOT NULL, published_at TEXT NOT NULL,
    value REAL NOT NULL, unit TEXT NOT NULL, currency TEXT NOT NULL,
    document_id TEXT NOT NULL, version_id TEXT NOT NULL,
    char_start INTEGER NOT NULL, char_end INTEGER NOT NULL,
    extraction_method TEXT NOT NULL, source_tier TEXT NOT NULL,
    confidence REAL, status TEXT NOT NULL, reason_codes_json TEXT NOT NULL,
    observation_id TEXT NOT NULL, raw_payload TEXT NOT NULL,
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_structured_evidence_candidate_status
    ON structured_evidence_candidates(dataset_id, entity_id, status, updated_at);
CREATE TABLE IF NOT EXISTS structured_evidence_reviews (
    review_id TEXT PRIMARY KEY, candidate_id TEXT NOT NULL,
    from_status TEXT NOT NULL, to_status TEXT NOT NULL,
    reviewer TEXT NOT NULL, note TEXT NOT NULL, reviewed_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_structured_evidence_review_candidate
    ON structured_evidence_reviews(candidate_id, reviewed_at);
CREATE TABLE IF NOT EXISTS structured_snapshots (
    snapshot_id TEXT PRIMARY KEY, consumer TEXT NOT NULL, purpose TEXT NOT NULL,
    as_of TEXT NOT NULL, created_at TEXT NOT NULL, metadata_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS structured_snapshot_items (
    snapshot_id TEXT NOT NULL, ordinal INTEGER NOT NULL, observation_id TEXT NOT NULL,
    selected_source TEXT NOT NULL, selection_reason TEXT NOT NULL,
    derivation_id TEXT NOT NULL, derivation_version TEXT NOT NULL,
    PRIMARY KEY (snapshot_id, ordinal)
);
CREATE TABLE IF NOT EXISTS structured_release_manifests (
    release_id TEXT PRIMARY KEY, source_id TEXT NOT NULL, dataset_id TEXT NOT NULL,
    partition_name TEXT NOT NULL, report_date TEXT NOT NULL,
    document_id TEXT NOT NULL, version_id TEXT NOT NULL, artifact_id TEXT NOT NULL,
    known_at TEXT NOT NULL, extractor_version TEXT NOT NULL,
    status TEXT NOT NULL, passed INTEGER NOT NULL,
    quality_json TEXT NOT NULL, observation_ids_json TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE(dataset_id,partition_name,version_id,extractor_version)
);
CREATE INDEX IF NOT EXISTS idx_structured_release_lookup
    ON structured_release_manifests(dataset_id,partition_name,known_at);
CREATE TABLE IF NOT EXISTS structured_legacy_audits (
    audit_id TEXT PRIMARY KEY, audited_at TEXT NOT NULL, series_count INTEGER NOT NULL,
    point_count INTEGER NOT NULL, missing_published_at INTEGER NOT NULL,
    note TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS structured_ingestion_runs (
    run_id TEXT PRIMARY KEY, source_id TEXT NOT NULL, dataset_id TEXT NOT NULL,
    query_scope_json TEXT NOT NULL, started_at TEXT NOT NULL, completed_at TEXT NOT NULL,
    status TEXT NOT NULL, discovered INTEGER NOT NULL DEFAULT 0,
    accepted INTEGER NOT NULL DEFAULT 0, quarantined INTEGER NOT NULL DEFAULT 0,
    unchanged INTEGER NOT NULL DEFAULT 0, reason_codes_json TEXT NOT NULL,
    note TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_structured_run_source
    ON structured_ingestion_runs(source_id, dataset_id, started_at);
CREATE TABLE IF NOT EXISTS structured_source_checks (
    check_id TEXT PRIMARY KEY, source_id TEXT NOT NULL, dataset_id TEXT NOT NULL,
    checked_at TEXT NOT NULL, status TEXT NOT NULL,
    latest_upstream_identity TEXT NOT NULL DEFAULT '',
    latest_ingested_identity TEXT NOT NULL DEFAULT '',
    latest_available_period TEXT NOT NULL DEFAULT '',
    candidate_identities_json TEXT NOT NULL DEFAULT '[]',
    request_identity_json TEXT NOT NULL DEFAULT '{}',
    diagnostics_json TEXT NOT NULL DEFAULT '{}',
    UNIQUE(source_id, dataset_id, checked_at, latest_upstream_identity, status)
);
CREATE INDEX IF NOT EXISTS idx_structured_source_check_latest
    ON structured_source_checks(source_id, dataset_id, checked_at DESC);
CREATE TABLE IF NOT EXISTS structured_source_purges (
    purge_id TEXT PRIMARY KEY, source_id TEXT NOT NULL, dataset_ids_json TEXT NOT NULL,
    purged_at TEXT NOT NULL, actor TEXT NOT NULL,
    observations INTEGER NOT NULL, series INTEGER NOT NULL, artifacts INTEGER NOT NULL,
    source_checks INTEGER NOT NULL, blobs INTEGER NOT NULL, freed_bytes INTEGER NOT NULL,
    sources INTEGER NOT NULL DEFAULT 0, datasets INTEGER NOT NULL DEFAULT 0,
    exported INTEGER NOT NULL DEFAULT 0, residuals_json TEXT NOT NULL DEFAULT '[]',
    note TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_structured_source_purge_lookup
    ON structured_source_purges(source_id, purged_at DESC);
CREATE TABLE IF NOT EXISTS structured_discovery_claims (
    source_id TEXT NOT NULL, candidate_identity TEXT NOT NULL,
    claimed_at TEXT NOT NULL, owner_id TEXT NOT NULL,
    PRIMARY KEY(source_id, candidate_identity)
);
CREATE TABLE IF NOT EXISTS structured_candidates (
    candidate_id TEXT PRIMARY KEY, run_id TEXT NOT NULL, source_id TEXT NOT NULL,
    dataset_id TEXT NOT NULL, entity_id TEXT NOT NULL, provider_field TEXT NOT NULL,
    metric_id TEXT NOT NULL, period TEXT NOT NULL, value_json TEXT NOT NULL,
    unit TEXT NOT NULL, currency TEXT NOT NULL, status TEXT NOT NULL,
    reason_codes_json TEXT NOT NULL, artifact_id TEXT NOT NULL,
    raw_payload TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_structured_candidate_status
    ON structured_candidates(dataset_id, status, created_at);
CREATE TABLE IF NOT EXISTS structured_conflicts (
    conflict_id TEXT PRIMARY KEY, dataset_id TEXT NOT NULL, entity_id TEXT NOT NULL,
    metric_id TEXT NOT NULL, period TEXT NOT NULL, left_observation_id TEXT NOT NULL,
    right_source_id TEXT NOT NULL, right_value REAL NOT NULL,
    absolute_difference REAL NOT NULL, relative_difference REAL,
    status TEXT NOT NULL, detected_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_structured_conflict_lookup
    ON structured_conflicts(dataset_id, entity_id, metric_id, period, status);
CREATE VIEW IF NOT EXISTS structured_observations_accepted AS
SELECT
    o.observation_id, o.series_id, s.dataset_id, s.entity_id, s.metric_id,
    o.period, o.period_start, o.period_end, o.event_time, o.value,
    s.unit, s.currency, s.period_basis, s.adjustment, s.dimensions_json,
    s.source_id, o.published_at, o.known_at, o.fetched_at, o.artifact_id,
    o.content_hash, o.quality_status, o.quality_json
FROM structured_observations o
JOIN structured_series s ON s.series_id=o.series_id
WHERE o.quality_status IN ('accepted','warning','conflict');
CREATE VIEW IF NOT EXISTS structured_observations_selected AS
WITH latest AS (
    SELECT a.*
    FROM structured_observations_accepted a
    WHERE NOT EXISTS (
        SELECT 1 FROM structured_observations_accepted newer
        WHERE newer.series_id=a.series_id AND newer.period=a.period
          AND (newer.known_at>a.known_at OR
               (newer.known_at=a.known_at AND newer.fetched_at>a.fetched_at))
    )
), ranked AS (
    SELECT latest.*,
        CASE
          WHEN instr(d.primary_sources_json, '"' || latest.source_id || '"')>0 THEN 0
          WHEN instr(d.fallback_sources_json, '"' || latest.source_id || '"')>0 THEN 1
          ELSE 2
        END AS source_tier,
        row_number() OVER (
          PARTITION BY latest.dataset_id,latest.entity_id,latest.metric_id,latest.period
          ORDER BY
            CASE
              WHEN instr(d.primary_sources_json, '"' || latest.source_id || '"')>0 THEN 0
              WHEN instr(d.fallback_sources_json, '"' || latest.source_id || '"')>0 THEN 1
              ELSE 2
            END,
            instr(d.primary_sources_json || d.fallback_sources_json, latest.source_id),
            latest.source_id
        ) AS source_rank
    FROM latest JOIN structured_datasets d ON d.dataset_id=latest.dataset_id
)
SELECT * FROM ranked WHERE source_rank=1;
"""


def _json(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _decode_json(value, fallback):
    """Decode a stored JSON column, tolerating already-decoded and legacy shapes."""
    if isinstance(value, (list, dict)):
        return value
    if not value:
        return fallback
    try:
        decoded = json.loads(value)
    except (TypeError, ValueError):
        return fallback
    return decoded if isinstance(decoded, type(fallback)) else fallback


def _decode_list(value) -> list:
    return list(_decode_json(value, []))


def _stamp(value: datetime | None = None) -> str:
    return (value or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat(
        timespec="microseconds")


def _table_exists(conn: sqlite3.Connection, table: str) -> bool:
    return conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone() is not None


class StructuredRepository(Protocol):
    def register_source(self, source: StructuredSource) -> None: ...
    def register_dataset(self, dataset: StructuredDataset) -> None: ...
    def register_metric(self, metric: MetricDefinition) -> None: ...
    def save_observation(self, value: ObservationInput) -> ObservationVintage: ...
    def observations(self, **filters) -> list[dict]: ...


class SQLiteStructuredRepository:
    def __init__(self, path: str | Path, *, artifact_root: str | Path | None = None,
                 readonly: bool = False):
        self.path = str(path)
        self._lock = RLock()
        if readonly:
            if self.path == ":memory:":
                raise ValueError("readonly_repository_requires_existing_database")
            self.conn = sqlite3.connect(Path(self.path).resolve().as_uri() + "?mode=ro",
                                        uri=True, check_same_thread=False, timeout=30)
            self.conn.row_factory = sqlite3.Row
            self.conn.execute("PRAGMA query_only=ON")
            self.artifacts = ArtifactStore(artifact_root or default_artifact_root(), readonly=True)
            return
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path, check_same_thread=False, timeout=30)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys=ON")
        if self.path != ":memory:":
            self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.executescript(_SCHEMA)
        self.artifacts = ArtifactStore(artifact_root or default_artifact_root())
        self._record_migration()

    def _record_migration(self) -> None:
        with self.conn:
            columns = {row[1] for row in self.conn.execute(
                "PRAGMA table_info(structured_evidence_links)").fetchall()}
            for ddl in (
                "anchor_kind TEXT NOT NULL DEFAULT 'text_span'",
                "page_number INTEGER",
                "chart_id TEXT NOT NULL DEFAULT ''",
                "region_json TEXT NOT NULL DEFAULT ''",
            ):
                if ddl.split()[0] not in columns:
                    self.conn.execute(
                        f"ALTER TABLE structured_evidence_links ADD COLUMN {ddl}")
            entity_columns = {row[1] for row in self.conn.execute(
                "PRAGMA table_info(structured_entities)").fetchall()}
            if "metadata_json" not in entity_columns:
                self.conn.execute(
                    "ALTER TABLE structured_entities ADD COLUMN metadata_json TEXT NOT NULL DEFAULT '{}'")
            self.conn.execute(
                "INSERT OR IGNORE INTO structured_migrations(key,applied_at,note) "
                "VALUES ('structured_foundation_v1',?,'additive governed structured tables')",
                (_stamp(),))
            self.conn.execute(
                "INSERT OR IGNORE INTO structured_migrations(key,applied_at,note) "
                "VALUES ('structured_entity_relations_v1',?,'versioned entity relations and metadata')",
                (_stamp(),))
            self.conn.execute(
                "INSERT OR IGNORE INTO structured_migrations(key,applied_at,note) "
                "VALUES ('structured_source_checks_v1',?,'auditable source discovery checks')",
                (_stamp(),))
            self.conn.execute(
                "INSERT OR IGNORE INTO structured_migrations(key,applied_at,note) "
                "VALUES ('structured_source_purges_v1',?,'explicit confirmed source data purges')",
                (_stamp(),))

    def close(self) -> None:
        self.conn.close()

    def register_source(self, source: StructuredSource) -> None:
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT INTO structured_sources VALUES (?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(source_id) DO UPDATE SET provider=excluded.provider,"
                "adapter=excluded.adapter,persistence=excluded.persistence,"
                "catalog_status=excluded.catalog_status,cadence=excluded.cadence,"
                "retention=excluded.retention,upstream=excluded.upstream,"
                "datasets_json=excluded.datasets_json,constraints_json=excluded.constraints_json,"
                "updated_at=excluded.updated_at",
                (source.id, source.provider, source.adapter, source.persistence.value,
                 source.catalog_status.value, source.cadence, source.retention, source.upstream,
                 _json(source.datasets), _json(source.constraints), _stamp()))

    def register_dataset(self, dataset: StructuredDataset) -> None:
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT INTO structured_datasets VALUES (?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(dataset_id) DO UPDATE SET catalog_status=excluded.catalog_status,"
                "expected_cadence=excluded.expected_cadence,"
                "primary_sources_json=excluded.primary_sources_json,"
                "fallback_sources_json=excluded.fallback_sources_json,"
                "core_metrics_json=excluded.core_metrics_json,quality_json=excluded.quality_json,"
                "entities_json=excluded.entities_json,"
                "acceptance_samples_json=excluded.acceptance_samples_json,"
                "updated_at=excluded.updated_at",
                (dataset.id, dataset.catalog_status.value, dataset.expected_cadence,
                 _json(dataset.primary_sources), _json(dataset.fallback_sources),
                 _json(dataset.core_metrics), _json(dataset.quality), _json(dataset.entities),
                 _json(dataset.acceptance_samples), _stamp()))

    def register_metric(self, metric: MetricDefinition) -> None:
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT INTO structured_metrics VALUES (?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(metric_id) DO UPDATE SET value_type=excluded.value_type,"
                "unit_family=excluded.unit_family,cadence=excluded.cadence,"
                "period_basis_json=excluded.period_basis_json,adjustment=excluded.adjustment,"
                "derived=excluded.derived,description=excluded.description,"
                "definition_version=excluded.definition_version,updated_at=excluded.updated_at",
                (metric.id, metric.value_type, metric.unit_family, metric.cadence,
                 _json(metric.period_basis), metric.adjustment, int(metric.derived),
                 metric.description, metric.version, _stamp()))

    def register_mapping(self, mapping: ProviderMapping) -> None:
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT INTO structured_provider_mappings VALUES (?,?,?,?,?) "
                "ON CONFLICT(provider,provider_field,mapping_version) DO UPDATE SET "
                "metric_id=excluded.metric_id,dimensions_json=excluded.dimensions_json",
                (mapping.provider, mapping.provider_field, mapping.version,
                 mapping.metric_id, _json(mapping.dimensions)))

    def bootstrap_catalog(self, catalog: StructuredCatalog | None = None) -> None:
        catalog = catalog or StructuredCatalog.load()
        for entity_id, body in (catalog.raw.get("entities", {}) or {}).items():
            self.register_entity(
                entity_id=entity_id, kind=str((body or {}).get("kind", "economic_entity")),
                canonical_name=str((body or {}).get("canonical_name", entity_id)),
                aliases=list((body or {}).get("aliases", [])),
                securities=list((body or {}).get("securities", [])))
        for source in catalog.sources():
            self.register_source(source)
        for dataset in catalog.datasets():
            self.register_dataset(dataset)
        for metric in catalog.metrics():
            self.register_metric(metric)
        for provider, field, metric_id in catalog.provider_mappings():
            self.register_mapping(ProviderMapping(
                provider=provider, provider_field=field, metric_id=metric_id))

    def register_entity(self, *, entity_id: str, kind: str, canonical_name: str,
                        aliases: list[str] | None = None,
                        securities: list[dict] | None = None,
                        metadata: dict | None = None) -> None:
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT INTO structured_entities "
                "(entity_id,kind,canonical_name,aliases_json,securities_json,metadata_json,updated_at) "
                "VALUES (?,?,?,?,?,?,?) "
                "ON CONFLICT(entity_id) DO UPDATE SET kind=excluded.kind,"
                "canonical_name=excluded.canonical_name,aliases_json=excluded.aliases_json,"
                "securities_json=excluded.securities_json,metadata_json=excluded.metadata_json,"
                "updated_at=excluded.updated_at",
                (entity_id.upper(), kind, canonical_name, _json(aliases or []),
                 _json(securities or []), _json(metadata or {}), _stamp()))

    def save_frontier_capability_metadata(self, *, records: list[dict], source_id: str,
                                          known_at: datetime | None = None) -> None:
        """Persist method versions and explicit coverage states alongside scores.

        This additive table is intentionally independent of observations, allowing
        NA/withdrawn cells to survive when a source has no numeric score.
        """
        stamp = _stamp(known_at)
        with self._lock, self.conn:
            for item in records:
                self.conn.execute(
                    "INSERT INTO structured_frontier_capability_methods VALUES (?,?,?,?,?,?) "
                    "ON CONFLICT(benchmark_id,method_version,comparability_group) DO UPDATE SET "
                    "metadata_json=excluded.metadata_json,last_seen_at=excluded.last_seen_at",
                    (str(item.get("benchmark_id") or ""), str(item.get("method_version") or ""),
                     str(item.get("comparability_group") or ""), _json(item), stamp, stamp))
                self.conn.execute(
                    "INSERT INTO structured_frontier_capability_coverage VALUES (?,?,?,?,?,?,?,?) "
                    "ON CONFLICT(lab_id,model_id,benchmark_id,method_version,source_id) DO UPDATE SET "
                    "coverage_state=excluded.coverage_state,known_at=excluded.known_at,metadata_json=excluded.metadata_json",
                    (str(item.get("lab_id") or ""), str(item.get("model_id") or ""),
                     str(item.get("benchmark_id") or ""), str(item.get("coverage_state") or "observed"),
                     str(item.get("method_version") or ""), stamp, source_id, _json(item)))

    def frontier_capability_coverage(self, *, lab_id: str | None = None,
                                     model_id: str | None = None,
                                     benchmark_id: str | None = None) -> list[dict]:
        sql = "SELECT * FROM structured_frontier_capability_coverage WHERE 1=1"; args: list = []
        for column, value in (("lab_id", lab_id), ("model_id", model_id), ("benchmark_id", benchmark_id)):
            if value:
                sql += f" AND {column}=?"; args.append(value)
        sql += " ORDER BY lab_id,model_id,benchmark_id"
        return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    def save_entity_relation(self, *, dataset_id: str, source_id: str,
                             parent_entity_id: str, child_entity_id: str,
                             relation_type: str, source_version: str,
                             known_at: datetime, artifact_id: str,
                             metadata: dict | None = None, active: bool = True) -> tuple[str, bool]:
        """Append one immutable relationship version and return (id, created)."""
        body = {
            "dataset_id": dataset_id, "source_id": source_id,
            "parent_entity_id": parent_entity_id.upper(),
            "child_entity_id": child_entity_id.upper(),
            "relation_type": relation_type, "source_version": source_version,
            "metadata": metadata or {}, "active": bool(active),
        }
        relation_id = hashlib.sha256(_json(body).encode()).hexdigest()[:24]
        with self._lock, self.conn:
            cur = self.conn.execute(
                "INSERT OR IGNORE INTO structured_entity_relations "
                "(relation_id,dataset_id,source_id,parent_entity_id,child_entity_id,relation_type,"
                "source_version,known_at,artifact_id,active,metadata_json) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (relation_id, dataset_id, source_id, body["parent_entity_id"],
                 body["child_entity_id"], relation_type, source_version, _stamp(known_at),
                 artifact_id, int(active), _json(metadata or {})))
        return relation_id, cur.rowcount > 0

    def entity_relations(self, *, dataset_id: str | None = None,
                         source_id: str | None = None,
                         parent_entity_id: str | None = None,
                         child_entity_id: str | None = None,
                         relation_type: str | None = None,
                         as_of: datetime | None = None,
                         active_only: bool = True, limit: int = 5000) -> list[dict]:
        sql = "SELECT * FROM structured_entity_relations WHERE 1=1"
        args: list = []
        for column, value in (("dataset_id", dataset_id), ("source_id", source_id),
                              ("parent_entity_id", parent_entity_id.upper() if parent_entity_id else None),
                              ("child_entity_id", child_entity_id.upper() if child_entity_id else None),
                              ("relation_type", relation_type)):
            if value:
                sql += f" AND {column}=?"
                args.append(value)
        cutoff = _stamp(as_of or datetime.now(timezone.utc))
        sql += " AND known_at<=?"
        args.append(cutoff)
        sql += (" AND NOT EXISTS (SELECT 1 FROM structured_entity_relations newer "
                "WHERE newer.dataset_id=structured_entity_relations.dataset_id "
                "AND newer.source_id=structured_entity_relations.source_id "
                "AND newer.parent_entity_id=structured_entity_relations.parent_entity_id "
                "AND newer.child_entity_id=structured_entity_relations.child_entity_id "
                "AND newer.relation_type=structured_entity_relations.relation_type "
                "AND newer.known_at>structured_entity_relations.known_at "
                "AND newer.known_at<=?)")
        args.append(cutoff)
        if active_only:
            sql += " AND active=1"
        sql += " ORDER BY parent_entity_id,child_entity_id,relation_type,known_at LIMIT ?"
        args.append(limit)
        return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    def entity_relation(self, relation_id: str) -> dict | None:
        """Return one immutable taxonomy relation for snapshot replay/audit."""
        row = self.conn.execute(
            "SELECT * FROM structured_entity_relations WHERE relation_id=?", (relation_id,)
        ).fetchone()
        return dict(row) if row else None

    def save_relation_candidate(self, *, run_id: str, source_id: str, dataset_id: str,
                                parent_entity_id: str, child_entity_id: str,
                                relation_type: str, source_version: str,
                                reason_codes: list[str], artifact_id: str = "",
                                raw: dict | None = None, at: datetime | None = None) -> str:
        identity = "|".join((run_id, parent_entity_id, child_entity_id, relation_type, source_version,
                             _json(reason_codes)))
        candidate_id = hashlib.sha256(identity.encode()).hexdigest()[:24]
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT OR REPLACE INTO structured_relation_candidates VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (candidate_id, run_id, source_id, dataset_id, parent_entity_id.upper(),
                 child_entity_id.upper(), relation_type, source_version, "quarantined",
                 _json(reason_codes), artifact_id, _json(raw or {}), _stamp(at)))
        return candidate_id

    def relation_candidates(self, *, run_id: str | None = None,
                            limit: int = 1000) -> list[dict]:
        sql = "SELECT * FROM structured_relation_candidates WHERE 1=1"
        args: list = []
        if run_id:
            sql += " AND run_id=?"
            args.append(run_id)
        sql += " ORDER BY created_at DESC LIMIT ?"
        args.append(limit)
        return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    def entities(self) -> list[dict]:
        return [dict(row) for row in self.conn.execute(
            "SELECT * FROM structured_entities ORDER BY entity_id").fetchall()]

    def resolve_entity(self, value: str) -> str | None:
        stripped = value.strip()
        direct = self.conn.execute(
            "SELECT entity_id FROM structured_entities WHERE entity_id=? COLLATE NOCASE",
            (stripped,),
        ).fetchone()
        if direct:
            return direct["entity_id"]
        target = stripped.casefold()
        for row in self.entities():
            aliases = json.loads(row["aliases_json"] or "[]")
            if target in {row["entity_id"].casefold(), row["canonical_name"].casefold(),
                          *(str(alias).casefold() for alias in aliases)}:
                return row["entity_id"]
        return None

    def resolve_metric(self, provider: str, provider_field: str,
                       *, version: str = "v1") -> str | None:
        row = self.conn.execute(
            "SELECT metric_id FROM structured_provider_mappings WHERE provider=? "
            "AND provider_field=? AND mapping_version=?",
            (provider, provider_field, version)).fetchone()
        return row["metric_id"] if row else None

    def record_pending_mapping(self, *, provider: str, dataset_id: str,
                               provider_field: str, sample: dict,
                               at: datetime | None = None) -> str:
        now = _stamp(at)
        pending_id = hashlib.sha1(
            f"{provider}|{dataset_id}|{provider_field}".encode()).hexdigest()[:24]
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT INTO structured_pending_mappings VALUES (?,?,?,?,?,'pending',?,?,1) "
                "ON CONFLICT(provider,dataset_id,provider_field) DO UPDATE SET "
                "sample_payload=excluded.sample_payload,last_seen_at=excluded.last_seen_at,"
                "seen_count=structured_pending_mappings.seen_count+1",
                (pending_id, provider, dataset_id, provider_field, _json(sample), now, now))
        return pending_id

    def source(self, source_id: str) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM structured_sources WHERE source_id=?", (source_id,)).fetchone()
        return dict(row) if row else None

    def dataset(self, dataset_id: str) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM structured_datasets WHERE dataset_id=?", (dataset_id,)).fetchone()
        return dict(row) if row else None

    def metric(self, metric_id: str) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM structured_metrics WHERE metric_id=?", (metric_id,)).fetchone()
        return dict(row) if row else None

    def sources(self) -> list[dict]:
        return [dict(row) for row in self.conn.execute(
            "SELECT * FROM structured_sources ORDER BY source_id").fetchall()]

    def datasets(self) -> list[dict]:
        return [dict(row) for row in self.conn.execute(
            "SELECT * FROM structured_datasets ORDER BY dataset_id").fetchall()]

    def metrics(self) -> list[dict]:
        return [dict(row) for row in self.conn.execute(
            "SELECT * FROM structured_metrics ORDER BY metric_id").fetchall()]

    def pending_mappings(self, *, status: str | None = None,
                         limit: int = 1000) -> list[dict]:
        sql = "SELECT * FROM structured_pending_mappings WHERE 1=1"
        args: list = []
        if status:
            sql += " AND status=?"
            args.append(status)
        sql += " ORDER BY last_seen_at DESC LIMIT ?"
        args.append(limit)
        return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    def conflicts(self, *, dataset_id: str | None = None,
                  status: str | None = "open", limit: int = 1000) -> list[dict]:
        sql = "SELECT * FROM structured_conflicts WHERE 1=1"
        args: list = []
        if dataset_id:
            sql += " AND dataset_id=?"
            args.append(dataset_id)
        if status:
            sql += " AND status=?"
            args.append(status)
        sql += " ORDER BY detected_at DESC LIMIT ?"
        args.append(limit)
        return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    def artifact_usage(self, *, source_id: str | None = None) -> dict:
        """Report logical references, physical blobs and content-hash deduplication."""
        where = "WHERE a.source_id=?" if source_id else ""
        args = [source_id] if source_id else []
        summary = self.conn.execute(
            f"""
            SELECT COUNT(*) AS artifacts,COUNT(DISTINCT a.blob_id) AS unique_blobs,
                   COALESCE(SUM(b.bytes),0) AS referenced_bytes
            FROM structured_artifacts a
            JOIN structured_artifact_blobs b ON b.blob_id=a.blob_id
            {where}
            """, args).fetchone()
        physical = self.conn.execute(
            f"""
            SELECT COALESCE(SUM(b.bytes),0) AS physical_bytes
            FROM structured_artifact_blobs b
            WHERE b.blob_id IN (
                SELECT DISTINCT a.blob_id FROM structured_artifacts a {where})
            """, args).fetchone()
        by_source_sql = """
            SELECT a.source_id,COUNT(*) AS artifacts,
                   COUNT(DISTINCT a.blob_id) AS unique_blobs,
                   COALESCE(SUM(b.bytes),0) AS referenced_bytes
            FROM structured_artifacts a
            JOIN structured_artifact_blobs b ON b.blob_id=a.blob_id
        """
        by_source_args: list = []
        if source_id:
            by_source_sql += " WHERE a.source_id=?"
            by_source_args.append(source_id)
        by_source_sql += " GROUP BY a.source_id ORDER BY a.source_id"
        rows = [dict(row) for row in self.conn.execute(
            by_source_sql, by_source_args).fetchall()]
        for row in rows:
            row["deduplicated_references"] = row["artifacts"] - row["unique_blobs"]
            row["deduplication_rate"] = (
                row["deduplicated_references"] / row["artifacts"]
                if row["artifacts"] else 0.0)
            source = self.source(row["source_id"])
            row["retention"] = source["retention"] if source else "unknown"
        artifacts = int(summary["artifacts"])
        unique_blobs = int(summary["unique_blobs"])
        return {
            "artifacts": artifacts,
            "unique_blobs": unique_blobs,
            "deduplicated_references": artifacts - unique_blobs,
            "deduplication_rate": ((artifacts - unique_blobs) / artifacts
                                   if artifacts else 0.0),
            "referenced_bytes": int(summary["referenced_bytes"]),
            "physical_bytes": int(physical["physical_bytes"]),
            "filesystem": self.artifacts.usage(),
            "by_source": rows,
        }

    def artifacts_for(self, *, source_id: str | None = None,
                      dataset_id: str | None = None,
                      content_hash: str | None = None,
                      limit: int = 500) -> list[dict]:
        sql = ("SELECT a.*,b.content_hash,b.relative_path,b.bytes "
               "FROM structured_artifacts a JOIN structured_artifact_blobs b "
               "ON b.blob_id=a.blob_id WHERE 1=1")
        args: list = []
        for column, value in (("a.source_id", source_id),
                              ("a.dataset_id", dataset_id),
                              ("b.content_hash", content_hash)):
            if value:
                sql += f" AND {column}=?"
                args.append(value)
        sql += " ORDER BY a.fetched_at DESC,a.artifact_id LIMIT ?"
        args.append(limit)
        return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    def artifact(self, artifact_id: str) -> dict | None:
        row = self.conn.execute(
            "SELECT a.*,b.content_hash AS artifact_content_hash,b.relative_path,b.bytes "
            "FROM structured_artifacts a JOIN structured_artifact_blobs b "
            "ON b.blob_id=a.blob_id WHERE a.artifact_id=?", (artifact_id,)
        ).fetchone()
        return dict(row) if row else None

    def source_health(self) -> list[dict]:
        """Return one explicit health row for every registered source."""
        sql = """
        SELECT s.source_id,s.provider,s.persistence,s.catalog_status,s.cadence,
               r.status AS last_status,r.started_at AS last_started_at,
               r.completed_at AS last_completed_at,r.accepted,r.quarantined,r.unchanged,
               r.reason_codes_json
        FROM structured_sources s
        LEFT JOIN structured_ingestion_runs r ON r.run_id=(
            SELECT r2.run_id FROM structured_ingestion_runs r2
            WHERE r2.source_id=s.source_id ORDER BY r2.started_at DESC LIMIT 1)
        ORDER BY s.source_id
        """
        rows = [dict(row) for row in self.conn.execute(sql).fetchall()]
        for row in rows:
            check = self.source_checks(source_id=row["source_id"], limit=1)
            if check:
                latest_check = check[0]
                row.update({
                    "last_checked_at": latest_check["checked_at"],
                    "latest_upstream_identity": latest_check["latest_upstream_identity"],
                    "latest_ingested_identity": latest_check["latest_ingested_identity"],
                    "latest_available_period": latest_check["latest_available_period"],
                    "last_check_status": latest_check["status"],
                    "last_check_diagnostics": json.loads(latest_check["diagnostics_json"] or "{}"),
                })
            if row["source_id"] != "anthropic_economic_index":
                continue
            history = self.ingestion_history(source_id=row["source_id"], limit=1)
            latest = history[0] if history else {}
            artifacts = self.artifacts_for(source_id=row["source_id"], limit=1000)
            metadata = [json.loads(item.get("metadata_json") or "{}") for item in artifacts]
            observations = self.observations(source_id=row["source_id"], latest_only=True,
                                             accepted_only=True, limit=1_000_000)
            products = {}
            for product in ("claude_ai", "1p_api"):
                product_rows = [item for item in observations
                                if json.loads(item.get("dimensions_json") or "{}").get("source_product") == product]
                products[product] = {
                    "status": "ingested" if product_rows else "not_published_or_privacy_filtered",
                    "latest_available_period": max((item["period"] for item in product_rows), default=None),
                }
            row.update({
                "last_checked_at": row.get("last_checked_at") or latest.get("started_at"),
                "latest_upstream_commit": next((item.get("repository_commit") for item in metadata
                                                 if item.get("repository_commit")), None),
                "latest_ingested_release": next((item.get("release") for item in metadata if item.get("release")), None),
                "latest_available_period": max((item["period"] for item in observations
                                                if item.get("period_basis") == "calendar_month"), default=None),
                "source_products": products,
            })
        return rows

    def save_source_check(self, *, source_id: str, dataset_id: str, status: str,
                          latest_upstream_identity: str = "",
                          latest_ingested_identity: str = "",
                          latest_available_period: str = "",
                          candidates: list[dict] | None = None,
                          request_identity: dict | None = None,
                          diagnostics: dict | None = None,
                          at: datetime | None = None) -> str:
        checked_at = _stamp(at)
        check_id = hashlib.sha256("|".join((source_id, dataset_id, checked_at, status,
                                             latest_upstream_identity)).encode()).hexdigest()[:24]
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT OR IGNORE INTO structured_source_checks VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (check_id, source_id, dataset_id, checked_at, status,
                 latest_upstream_identity, latest_ingested_identity, latest_available_period,
                 _json(candidates or []), _json(request_identity or {}), _json(diagnostics or {})))
        return check_id

    def source_checks(self, *, source_id: str | None = None,
                      dataset_id: str | None = None, limit: int = 100) -> list[dict]:
        sql = "SELECT * FROM structured_source_checks WHERE 1=1"
        args: list = []
        if source_id:
            sql += " AND source_id=?"
            args.append(source_id)
        if dataset_id:
            sql += " AND dataset_id=?"
            args.append(dataset_id)
        sql += " ORDER BY checked_at DESC LIMIT ?"
        args.append(limit)
        return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    # ------------------------------------------------------------------ purge
    # Physical removal of a retired source's data.  This is deliberately the only
    # place that deletes governed rows: collection, publication, rollback and
    # catalog sync must never reach it, because those paths are routine and this
    # one is irreversible.

    def _exclusive_blobs(self, source_id: str, blob_ids: list[str]) -> list[str]:
        """Blobs that no ``structured_artifacts`` row outside this source references.

        The condition is per *artifact row*, not per *other source*: content
        deduplication happens inside a source too, so a blob may back several of
        this source's own artifacts.  Once those rows are gone the blob is
        unreferenced and safe to drop.
        """
        if not blob_ids:
            return []
        placeholders = ",".join("?" * len(blob_ids))
        shared = {row[0] for row in self.conn.execute(
            f"SELECT DISTINCT blob_id FROM structured_artifacts "
            f"WHERE blob_id IN ({placeholders}) AND source_id<>?",
            [*blob_ids, source_id]).fetchall()}
        return [blob_id for blob_id in blob_ids if blob_id not in shared]

    def purge_plan(self, source_id: str) -> dict:
        """Read-only inventory of what purging ``source_id`` would remove."""
        source_row = self.source(source_id) or {}
        dataset_ids = _decode_list(source_row.get("datasets_json"))
        observations = int(self.conn.execute(
            "SELECT COUNT(*) FROM structured_observations o "
            "JOIN structured_series s ON s.series_id=o.series_id "
            "WHERE s.source_id=?", (source_id,)).fetchone()[0])
        series = int(self.conn.execute(
            "SELECT COUNT(*) FROM structured_series WHERE source_id=?",
            (source_id,)).fetchone()[0])
        artifacts = int(self.conn.execute(
            "SELECT COUNT(*) FROM structured_artifacts WHERE source_id=?",
            (source_id,)).fetchone()[0])
        blob_ids = [row[0] for row in self.conn.execute(
            "SELECT DISTINCT blob_id FROM structured_artifacts WHERE source_id=?",
            (source_id,)).fetchall()]
        exclusive = self._exclusive_blobs(source_id, blob_ids)
        bytes_freed = 0
        blob_paths: list[str] = []
        if exclusive:
            placeholders = ",".join("?" * len(exclusive))
            bytes_freed = int(self.conn.execute(
                "SELECT COALESCE(SUM(bytes),0) FROM structured_artifact_blobs "
                f"WHERE blob_id IN ({placeholders})", exclusive).fetchone()[0])
            blob_paths = [row[0] for row in self.conn.execute(
                "SELECT relative_path FROM structured_artifact_blobs "
                f"WHERE blob_id IN ({placeholders})", exclusive).fetchall()]
        source_checks = int(self.conn.execute(
            "SELECT COUNT(*) FROM structured_source_checks WHERE source_id=?",
            (source_id,)).fetchone()[0])
        return {
            "row_counts": {
                "observations": observations,
                "series": series,
                "artifacts": artifacts,
                "source_checks": source_checks,
                "registered_sources": 1 if source_row else 0,
                "registered_datasets": sum(
                    1 for dataset_id in dataset_ids if self.dataset(dataset_id)),
            },
            "dataset_ids": dataset_ids,
            "blobs": len(exclusive),
            "blobs_total": len(blob_ids),
            "bytes_freed": bytes_freed,
            "exclusive_blobs": sorted(exclusive),
            "blob_paths": blob_paths,
            # Tables holding rows of this source that the purge intentionally
            # leaves behind because they are operational history, not data: the
            # ingestion ledger is the audit trail that the source ran and was
            # then retired.  Surfaced explicitly so the residue is never silent.
            "residual_tables": {
                "structured_ingestion_runs": int(self.conn.execute(
                    "SELECT COUNT(*) FROM structured_ingestion_runs WHERE source_id=?",
                    (source_id,)).fetchone()[0]),
            },
        }

    def purge_source(self, source_id: str, *, confirm: bool = False,
                     catalog: StructuredCatalog | None = None,
                     actor: str = "cli", exported: bool = False,
                     note: str = "") -> dict:
        """Dry-run or execute the physical deletion of a retired source's data.

        Without ``confirm`` this only reads.  With ``confirm`` it requires a
        retirement tombstone, deletes every row in a single transaction, and only
        then unlinks the blobs those artifacts exclusively owned: a database
        transaction cannot roll back the filesystem, so removing files first
        would risk leaving rows that point at nothing, whereas running second at
        worst leaves an unreferenced file that the next health check reports.
        """
        catalog = catalog or StructuredCatalog.load()
        tombstone = catalog.retired_source(source_id)
        plan = self.purge_plan(source_id)
        head = {
            "source_id": source_id,
            "tombstoned": tombstone is not None,
            "retired_at": tombstone.retired_at.isoformat() if tombstone else "",
            "retirement_reason": tombstone.reason if tombstone else "",
            "disposition": tombstone.disposition.value if tombstone else "",
        }
        if not confirm:
            return {"mode": "dry_run", **head, **plan,
                    "previous_purges": self.purge_records(source_id=source_id)}
        if tombstone is None:
            raise ValueError(
                f"source {source_id} has no retirement tombstone; refusing to purge a "
                "source that is not retired. Retire it through a change first so the "
                "id is recorded and cannot be silently reused.")

        purged_at = _stamp()
        purge_id = hashlib.sha1(
            f"{source_id}|{purged_at}|{actor}".encode()).hexdigest()[:24]
        with self._lock, self.conn:
            removed = {
                "observations": self.conn.execute(
                    "DELETE FROM structured_observations WHERE series_id IN "
                    "(SELECT series_id FROM structured_series WHERE source_id=?)",
                    (source_id,)).rowcount,
                "series": self.conn.execute(
                    "DELETE FROM structured_series WHERE source_id=?",
                    (source_id,)).rowcount,
                "artifacts": self.conn.execute(
                    "DELETE FROM structured_artifacts WHERE source_id=?",
                    (source_id,)).rowcount,
                "source_checks": self.conn.execute(
                    "DELETE FROM structured_source_checks WHERE source_id=?",
                    (source_id,)).rowcount,
            }
            exclusive = plan["exclusive_blobs"]
            removed["blobs"] = 0
            if exclusive:
                removed["blobs"] = self.conn.execute(
                    "DELETE FROM structured_artifact_blobs "
                    f"WHERE blob_id IN ({','.join('?' * len(exclusive))})",
                    exclusive).rowcount
            removed["registered_sources"] = self.conn.execute(
                "DELETE FROM structured_sources WHERE source_id=?", (source_id,)).rowcount
            removed["registered_datasets"] = 0
            for dataset_id in plan["dataset_ids"]:
                # A dataset is shared when any surviving source still declares it;
                # only unregistered when this source was its last declared owner.
                still_used = any(
                    dataset_id in _decode_list(row[0])
                    for row in self.conn.execute(
                        "SELECT datasets_json FROM structured_sources WHERE source_id<>?",
                        (source_id,)).fetchall())
                if not still_used:
                    removed["registered_datasets"] += self.conn.execute(
                        "DELETE FROM structured_datasets WHERE dataset_id=?",
                        (dataset_id,)).rowcount
            self.conn.execute(
                "INSERT INTO structured_source_purges(purge_id,source_id,dataset_ids_json,"
                "purged_at,actor,observations,series,artifacts,source_checks,blobs,"
                "freed_bytes,sources,datasets,exported,residuals_json,note) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (purge_id, source_id, _json(plan["dataset_ids"]), purged_at, actor,
                 removed["observations"], removed["series"], removed["artifacts"],
                 removed["source_checks"], removed["blobs"], plan["bytes_freed"],
                 removed["registered_sources"], removed["registered_datasets"],
                 int(bool(exported)), _json(plan["residual_tables"]), note))

        # Only now, after the transaction committed, unlink the blob files.
        files_removed = 0
        for relative_path in plan["blob_paths"]:
            target = self.artifacts.root / relative_path
            try:
                target.unlink()
                files_removed += 1
            except FileNotFoundError:
                continue
        return {
            "mode": "purged", **head, "purge_id": purge_id, "purged_at": purged_at,
            "actor": actor, "exported": bool(exported),
            "deleted": removed, "bytes_freed": plan["bytes_freed"],
            "blob_files_removed": files_removed,
            "dataset_ids": plan["dataset_ids"],
            "residual_tables": plan["residual_tables"],
        }

    def purge_records(self, *, source_id: str | None = None,
                      limit: int = 100) -> list[dict]:
        """Return the audit record written by each completed purge."""
        sql = "SELECT * FROM structured_source_purges WHERE 1=1"
        args: list = []
        if source_id:
            sql += " AND source_id=?"
            args.append(source_id)
        sql += " ORDER BY purged_at DESC LIMIT ?"
        args.append(limit)
        records = []
        for row in self.conn.execute(sql, args).fetchall():
            record = dict(row)
            record["dataset_ids"] = _decode_list(record.pop("dataset_ids_json", "[]"))
            record["residuals"] = _decode_json(record.pop("residuals_json", "{}"), {})
            record["exported"] = bool(record["exported"])
            records.append(record)
        return records

    def claim_discovery_candidate(self, *, source_id: str, candidate_identity: str,
                                  owner_id: str) -> bool:
        """Atomically claim one immutable release for discovery/ingestion."""
        with self._lock, self.conn:
            cursor = self.conn.execute(
                "INSERT OR IGNORE INTO structured_discovery_claims "
                "(source_id,candidate_identity,claimed_at,owner_id) VALUES (?,?,?,?)",
                (source_id, candidate_identity, _stamp(), owner_id))
        return cursor.rowcount == 1

    def begin_ingestion(self, *, source_id: str, dataset_id: str,
                        query_scope: dict, at: datetime | None = None) -> str:
        started = _stamp(at)
        run_id = hashlib.sha1(
            f"{source_id}|{dataset_id}|{started}|{os.urandom(8).hex()}".encode()
        ).hexdigest()[:24]
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT INTO structured_ingestion_runs VALUES "
                "(?,?,?,?,?,'','running',0,0,0,0,'{}','')",
                (run_id, source_id, dataset_id, _json(query_scope), started))
        return run_id

    def finish_ingestion(self, run_id: str, *, status: str, discovered: int = 0,
                         accepted: int = 0, quarantined: int = 0, unchanged: int = 0,
                         reason_codes: dict | list | None = None, note: str = "",
                         at: datetime | None = None) -> None:
        with self._lock, self.conn:
            self.conn.execute(
                "UPDATE structured_ingestion_runs SET completed_at=?,status=?,discovered=?,"
                "accepted=?,quarantined=?,unchanged=?,reason_codes_json=?,note=? "
                "WHERE run_id=?",
                (_stamp(at), status, discovered, accepted, quarantined, unchanged,
                 _json(reason_codes or {}), note, run_id))

    def ingestion_history(self, *, source_id: str | None = None,
                          dataset_id: str | None = None, limit: int = 100) -> list[dict]:
        sql = "SELECT * FROM structured_ingestion_runs WHERE 1=1"
        args: list = []
        if source_id:
            sql += " AND source_id=?"
            args.append(source_id)
        if dataset_id:
            sql += " AND dataset_id=?"
            args.append(dataset_id)
        sql += " ORDER BY started_at DESC LIMIT ?"
        args.append(limit)
        return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    def save_candidate(self, *, candidate_id: str, run_id: str, source_id: str,
                       dataset_id: str, entity_id: str, provider_field: str,
                       metric_id: str, period: str, value, unit: str, currency: str,
                       status: str, reason_codes: list[str], artifact_id: str,
                       raw: dict, at: datetime | None = None) -> None:
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT OR REPLACE INTO structured_candidates VALUES "
                "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (candidate_id, run_id, source_id, dataset_id, entity_id, provider_field,
                 metric_id, period, _json(value), unit, currency, status,
                 _json(reason_codes), artifact_id, _json(raw), _stamp(at)))

    def candidates(self, *, status: str | None = None,
                   dataset_id: str | None = None, limit: int = 1000) -> list[dict]:
        sql = "SELECT * FROM structured_candidates WHERE 1=1"
        args: list = []
        if status:
            sql += " AND status=?"
            args.append(status)
        if dataset_id:
            sql += " AND dataset_id=?"
            args.append(dataset_id)
        sql += " ORDER BY created_at DESC LIMIT ?"
        args.append(limit)
        return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    def ensure_event(self, *, dataset_id: str, entity_id: str, event_type: str,
                     event_date: str, event_label: str = "",
                     status: str = "active") -> str:
        normalized = (dataset_id, entity_id.upper(), event_type.strip().lower(),
                      event_date[:10], event_label.strip().casefold())
        event_id = hashlib.sha256("|".join(normalized).encode()).hexdigest()[:24]
        now = _stamp()
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT INTO structured_events VALUES (?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(dataset_id,entity_id,event_type,event_date,event_label) "
                "DO UPDATE SET status=CASE WHEN structured_events.status='active' "
                "THEN 'active' ELSE excluded.status END,updated_at=excluded.updated_at",
                (event_id, *normalized, status, now, now))
        return event_id

    def events(self, *, entity_id: str | None = None,
               event_type: str | None = None) -> list[dict]:
        sql = "SELECT * FROM structured_events WHERE 1=1"
        args: list = []
        if entity_id:
            sql += " AND entity_id=?"
            args.append(entity_id.upper())
        if event_type:
            sql += " AND event_type=?"
            args.append(event_type.lower())
        sql += " ORDER BY event_date,event_id"
        return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    def event(self, event_id: str) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM structured_events WHERE event_id=?", (event_id,)).fetchone()
        return dict(row) if row else None

    def save_evidence_candidate(self, payload: dict) -> str:
        candidate_id = payload["candidate_id"]
        now = _stamp(payload.get("at"))
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT INTO structured_evidence_candidates VALUES "
                "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(candidate_id) DO UPDATE SET "
                "reason_codes_json=excluded.reason_codes_json,raw_payload=excluded.raw_payload,"
                "updated_at=excluded.updated_at",
                (candidate_id, payload["event_id"], payload["source_id"],
                 payload["dataset_id"], payload["entity_id"], payload["metric_id"],
                 payload["period"], payload.get("event_time", ""),
                 payload.get("published_at", ""), float(payload["value"]),
                 payload["unit"], payload.get("currency", ""), payload["document_id"],
                 payload["version_id"], int(payload["char_start"]),
                 int(payload["char_end"]), payload["extraction_method"],
                 payload["source_tier"], payload.get("confidence"), payload["status"],
                 _json(payload.get("reason_codes", [])), payload.get("observation_id", ""),
                 _json(payload.get("raw", {})), now, now))
        return candidate_id

    def evidence_candidate(self, candidate_id: str) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM structured_evidence_candidates WHERE candidate_id=?",
            (candidate_id,)).fetchone()
        return dict(row) if row else None

    def evidence_candidates(self, *, status: str | None = None,
                            entity_id: str | None = None,
                            limit: int = 1000) -> list[dict]:
        sql = "SELECT * FROM structured_evidence_candidates WHERE 1=1"
        args: list = []
        if status:
            sql += " AND status=?"
            args.append(status)
        if entity_id:
            sql += " AND entity_id=?"
            args.append(entity_id.upper())
        sql += " ORDER BY updated_at DESC LIMIT ?"
        args.append(limit)
        return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    def save_evidence_link(self, link: EvidenceLink) -> str:
        body = link.model_dump(mode="json")
        link_id = hashlib.sha256(_json(body).encode()).hexdigest()[:24]
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT OR REPLACE INTO structured_evidence_links "
                "(link_id,observation_id,candidate_id,document_id,version_id,char_start,"
                "char_end,anchor_kind,page_number,chart_id,region_json,extraction_method,"
                "source_tier,verification_status,reviewer,reviewed_at,created_at) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (link_id, link.observation_id, link.candidate_id, link.document_id,
                 link.version_id, link.char_start, link.char_end, link.anchor_kind,
                 link.page_number, link.chart_id,
                 _json(link.region) if link.region is not None else "",
                 link.extraction_method, link.source_tier,
                 link.verification_status.value, link.reviewer,
                 _stamp(link.reviewed_at) if link.reviewed_at else "", _stamp()))
        return link_id

    def evidence_links(self, *, candidate_id: str | None = None,
                       observation_id: str | None = None) -> list[dict]:
        sql = "SELECT * FROM structured_evidence_links WHERE 1=1"
        args: list = []
        if candidate_id:
            sql += " AND candidate_id=?"
            args.append(candidate_id)
        if observation_id:
            sql += " AND observation_id=?"
            args.append(observation_id)
        sql += " ORDER BY created_at,link_id"
        return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    def transition_evidence_candidate(self, *, candidate_id: str, to_status: str,
                                      reviewer: str, note: str,
                                      observation_id: str = "",
                                      at: datetime | None = None) -> dict:
        current = self.evidence_candidate(candidate_id)
        if current is None:
            raise KeyError(candidate_id)
        reviewed_at = _stamp(at)
        review_id = hashlib.sha256(
            f"{candidate_id}|{current['status']}|{to_status}|{reviewer}|{reviewed_at}".encode()
        ).hexdigest()[:24]
        with self._lock, self.conn:
            self.conn.execute(
                "UPDATE structured_evidence_candidates SET status=?,observation_id=?,"
                "updated_at=? WHERE candidate_id=?",
                (to_status, observation_id or current["observation_id"],
                 reviewed_at, candidate_id))
            self.conn.execute(
                "INSERT INTO structured_evidence_reviews VALUES (?,?,?,?,?,?,?)",
                (review_id, candidate_id, current["status"], to_status,
                 reviewer, note, reviewed_at))
            self.conn.execute(
                "UPDATE structured_evidence_links SET verification_status=?,"
                "reviewer=?,reviewed_at=? WHERE candidate_id=?",
                (to_status, reviewer, reviewed_at, candidate_id))
        return self.evidence_candidate(candidate_id) or {}

    def evidence_reviews(self, candidate_id: str) -> list[dict]:
        return [dict(row) for row in self.conn.execute(
            "SELECT * FROM structured_evidence_reviews WHERE candidate_id=? "
            "ORDER BY rowid", (candidate_id,)).fetchall()]

    def save_release_manifest(self, *, source_id: str, dataset_id: str,
                              partition: str, report_date: str,
                              document_id: str, version_id: str,
                              artifact_id: str, known_at: datetime,
                              extractor_version: str, status: str, passed: bool,
                              quality: dict, observation_ids: list[str]) -> str:
        identity = f"{dataset_id}|{partition}|{version_id}|{extractor_version}"
        release_id = hashlib.sha256(identity.encode()).hexdigest()[:24]
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT INTO structured_release_manifests VALUES "
                "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
                "ON CONFLICT(dataset_id,partition_name,version_id,extractor_version) "
                "DO UPDATE SET status=excluded.status,passed=excluded.passed,"
                "quality_json=excluded.quality_json,"
                "observation_ids_json=excluded.observation_ids_json",
                (release_id, source_id, dataset_id, partition, report_date,
                 document_id, version_id, artifact_id, _stamp(known_at),
                 extractor_version, status, int(passed), _json(quality),
                 _json(observation_ids), _stamp()))
        return release_id

    def release_manifests(self, *, dataset_id: str | None = None,
                          partition: str | None = None,
                          as_of: datetime | None = None,
                          passed_only: bool = False,
                          limit: int = 500) -> list[dict]:
        sql, args = "SELECT * FROM structured_release_manifests WHERE 1=1", []
        for column, value in (("dataset_id", dataset_id),
                              ("partition_name", partition)):
            if value:
                sql += f" AND {column}=?"
                args.append(value)
        if as_of:
            sql += " AND known_at<=?"
            args.append(_stamp(as_of))
        if passed_only:
            sql += " AND passed=1"
        sql += " ORDER BY known_at DESC,created_at DESC LIMIT ?"
        args.append(limit)
        rows = [dict(row) for row in self.conn.execute(sql, args).fetchall()]
        for row in rows:
            row["quality"] = json.loads(row.pop("quality_json") or "{}")
            row["observation_ids"] = json.loads(
                row.pop("observation_ids_json") or "[]")
            row["passed"] = bool(row["passed"])
        return rows

    def latest_release(self, *, dataset_id: str, partition: str,
                       as_of: datetime | None = None,
                       passed_only: bool = True) -> dict | None:
        rows = self.release_manifests(
            dataset_id=dataset_id, partition=partition, as_of=as_of,
            passed_only=passed_only, limit=1)
        return rows[0] if rows else None

    def comparable_observations(self, *, dataset_id: str, entity_id: str,
                                metric_id: str, period: str) -> list[dict]:
        return self.observations(dataset_id=dataset_id, entity_id=entity_id,
                                 metric_id=metric_id, latest_only=True,
                                 accepted_only=True, limit=1000)

    def record_conflict(self, *, dataset_id: str, entity_id: str, metric_id: str,
                        period: str, left_observation_id: str, right_source_id: str,
                        right_value: float, absolute_difference: float,
                        relative_difference: float | None,
                        at: datetime | None = None) -> str:
        conflict_id = hashlib.sha1(
            f"{dataset_id}|{entity_id}|{metric_id}|{period}|{left_observation_id}|"
            f"{right_source_id}|{right_value}".encode()).hexdigest()[:24]
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT OR IGNORE INTO structured_conflicts VALUES "
                "(?,?,?,?,?,?,?,?,?,?,'open',?)",
                (conflict_id, dataset_id, entity_id, metric_id, period,
                 left_observation_id, right_source_id, right_value,
                 absolute_difference, relative_difference, _stamp(at)))
        return conflict_id

    def put_artifact(self, payload: bytes | str | dict | list | None,
                     descriptor: ArtifactDescriptor) -> RawArtifact:
        source = self.source(descriptor.source_id)
        if source and source["catalog_status"] == "runtime_excluded":
            raise ValueError(
                f"runtime/excluded source {descriptor.source_id} cannot persist artifacts")
        query = _json(descriptor.query_scope)
        query_hash = hashlib.sha256(query.encode()).hexdigest()
        if payload is None:
            pointer_payload = _json({
                "pointer": descriptor.pointer,
                "source_version": descriptor.source_version,
                "query_scope": descriptor.query_scope,
            })
            blob = self.artifacts.put(pointer_payload, suffix=".json")
        else:
            suffix = ".json" if descriptor.media_type.endswith("json") else ".bin"
            blob = self.artifacts.put(payload, suffix=suffix)
        artifact_id = hashlib.sha1(
            f"{descriptor.source_id}|{descriptor.dataset_id}|{query_hash}|{blob.blob_id}".encode()
        ).hexdigest()[:24]
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT OR IGNORE INTO structured_artifact_blobs VALUES (?,?,?,?,?)",
                (blob.blob_id, blob.content_hash, blob.relative_path, blob.bytes, _stamp()))
            self.conn.execute(
                "INSERT OR IGNORE INTO structured_artifacts VALUES "
                "(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (artifact_id, blob.blob_id, descriptor.source_id, descriptor.dataset_id,
                 _stamp(descriptor.fetched_at), query, query_hash, descriptor.source_url,
                 descriptor.source_version, descriptor.media_type, descriptor.retention,
                 descriptor.storage_mode, descriptor.pointer, _json(descriptor.metadata)))
        return RawArtifact(id=artifact_id, blob_id=blob.blob_id,
                           content_hash=blob.content_hash, relative_path=blob.relative_path,
                           bytes=blob.bytes, descriptor=descriptor)

    @staticmethod
    def _series_payload(series: SeriesIdentity) -> dict:
        return series.model_dump(mode="json")

    def ensure_series(self, series: SeriesIdentity) -> str:
        source = self.source(series.source_id)
        if source and source["catalog_status"] == "runtime_excluded":
            raise ValueError(
                f"runtime/excluded source {series.source_id} cannot persist series")
        payload = self._series_payload(series)
        identity_hash = hashlib.sha256(_json(payload).encode()).hexdigest()
        series_id = identity_hash[:24]
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT OR IGNORE INTO structured_series VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (series_id, identity_hash, series.source_id, series.dataset_id,
                 series.entity_id, series.metric_id, series.unit, series.currency,
                 series.period_basis, series.adjustment, _json(series.dimensions), _stamp()))
        return series_id

    def save_observation(self, value: ObservationInput) -> ObservationVintage:
        series_id = self.ensure_series(value.series)
        normalized = {
            "period": value.period,
            "period_start": value.period_start,
            "period_end": value.period_end,
            "event_time": _stamp(value.event_time) if value.event_time else "",
            "value": value.value,
            "published_at": _stamp(value.published_at) if value.published_at else "",
            "quality_status": value.quality_status.value,
            "quality": value.quality,
            "raw": value.raw,
        }
        content_hash = hashlib.sha256(_json(normalized).encode()).hexdigest()
        observation_id = hashlib.sha1(
            f"{series_id}|{value.period}|{content_hash}".encode()).hexdigest()[:24]
        with self._lock, self.conn:
            cur = self.conn.execute(
                "INSERT OR IGNORE INTO structured_observations VALUES "
                "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (observation_id, series_id, value.period, value.period_start, value.period_end,
                 normalized["event_time"], value.value, normalized["published_at"],
                 _stamp(value.known_at), _stamp(value.fetched_at), value.artifact_id,
                 content_hash, value.quality_status.value, _json(value.quality),
                 _json(value.raw),))
        return ObservationVintage(id=observation_id, series_id=series_id,
                                  content_hash=content_hash, created=cur.rowcount > 0,
                                  observation=value)

    def observations(self, *, dataset_id: str | None = None,
                     metric_id: str | None = None, entity_id: str | None = None,
                     source_id: str | None = None, since: str | None = None,
                     as_of: datetime | None = None, latest_only: bool = True,
                     accepted_only: bool = True, limit: int = 5000) -> list[dict]:
        sql = ("SELECT o.*,s.source_id,s.dataset_id,s.entity_id,s.metric_id,s.unit,"
               "s.currency,s.period_basis,s.adjustment,s.dimensions_json "
               "FROM structured_observations o JOIN structured_series s "
               "ON s.series_id=o.series_id WHERE 1=1")
        args: list = []
        for column, value in (("s.dataset_id", dataset_id), ("s.metric_id", metric_id),
                              ("s.entity_id", entity_id.upper() if entity_id else None),
                              ("s.source_id", source_id)):
            if value:
                sql += f" AND {column}=?"
                args.append(value)
        if since:
            sql += " AND o.period>=?"
            args.append(since)
        if accepted_only:
            sql += " AND o.quality_status IN ('accepted','warning','conflict')"
            sql += (" AND (s.source_id!='accepted_document_evidence' OR EXISTS ("
                    "SELECT 1 FROM structured_evidence_links el "
                    "WHERE el.observation_id=o.observation_id "
                    "AND el.verification_status='accepted'))")
        cutoff = _stamp(as_of) if as_of else ""
        if cutoff:
            sql += " AND o.known_at<=? AND (o.published_at='' OR o.published_at<=?)"
            args.extend([cutoff, cutoff])
        if accepted_only:
            # Reviewed FactSet groups become consumer-visible only when their
            # complete platform manifest commits. A crash between individual
            # observation writes and that commit must not expose a partial
            # cross-section through the generic structured read API. Legacy
            # observations have no package_hash and retain their old behavior.
            sql += (" AND (s.source_id!='factset_earnings_insight_metrics' "
                    "OR json_extract(s.dimensions_json,'$.package_hash') IS NULL "
                    "OR EXISTS (SELECT 1 FROM structured_release_manifests fm "
                    "JOIN json_each(fm.observation_ids_json) fi ON fi.value=o.observation_id "
                    "WHERE fm.dataset_id=s.dataset_id AND fm.passed=1 AND fm.status='platform' "
                    "AND json_extract(fm.quality_json,'$.package_hash')="
                    "json_extract(s.dimensions_json,'$.package_hash')")
            if cutoff:
                sql += " AND fm.known_at<=?"
                args.append(cutoff)
            sql += "))"
        if latest_only:
            sql += (" AND NOT EXISTS (SELECT 1 FROM structured_observations newer "
                    "WHERE newer.series_id=o.series_id AND newer.period=o.period "
                    "AND (newer.known_at>o.known_at OR "
                    "(newer.known_at=o.known_at AND newer.fetched_at>o.fetched_at))")
            if cutoff:
                sql += " AND newer.known_at<=? AND (newer.published_at='' OR newer.published_at<=?)"
                args.extend([cutoff, cutoff])
            sql += ")"
        sql += " ORDER BY o.period,o.known_at,o.fetched_at LIMIT ?"
        args.append(limit)
        return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    def observation(self, observation_id: str) -> dict | None:
        rows = self.conn.execute(
            "SELECT o.*,s.source_id,s.dataset_id,s.entity_id,s.metric_id,s.unit,"
            "s.currency,s.period_basis,s.adjustment,s.dimensions_json "
            "FROM structured_observations o JOIN structured_series s "
            "ON s.series_id=o.series_id WHERE o.observation_id=?",
            (observation_id,)).fetchone()
        return dict(rows) if rows else None

    def lineage(self, observation_id: str) -> dict | None:
        observation = self.observation(observation_id)
        if observation is None:
            return None
        artifact = self.conn.execute(
            "SELECT a.*,b.content_hash AS artifact_content_hash,b.relative_path,b.bytes "
            "FROM structured_artifacts a JOIN structured_artifact_blobs b "
            "ON b.blob_id=a.blob_id WHERE a.artifact_id=?",
            (observation["artifact_id"],)).fetchone()
        evidence = self.conn.execute(
            "SELECT * FROM structured_evidence_links WHERE observation_id=? "
            "ORDER BY created_at", (observation_id,)).fetchall()
        metric = self.metric(observation["metric_id"])
        source = self.source(observation["source_id"])
        return {
            "observation": observation,
            "metric": metric,
            "source": source,
            "artifact": dict(artifact) if artifact else None,
            "evidence": [dict(row) for row in evidence],
        }

    def register_derivation(self, definition) -> None:
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT INTO structured_derivations VALUES (?,?,?,?,?,?,?) "
                "ON CONFLICT(derivation_id,definition_version) DO UPDATE SET "
                "operation=excluded.operation,inputs_json=excluded.inputs_json,"
                "parameters_json=excluded.parameters_json,"
                "output_metric_id=excluded.output_metric_id,updated_at=excluded.updated_at",
                (definition.id, definition.version, definition.operation,
                 _json(definition.inputs), _json(definition.parameters),
                 definition.output_metric_id, _stamp()))

    def derivation(self, derivation_id: str, version: str | None = None) -> dict | None:
        if version:
            row = self.conn.execute(
                "SELECT * FROM structured_derivations WHERE derivation_id=? "
                "AND definition_version=?", (derivation_id, version)).fetchone()
        else:
            row = self.conn.execute(
                "SELECT * FROM structured_derivations WHERE derivation_id=? "
                "ORDER BY definition_version DESC LIMIT 1", (derivation_id,)).fetchone()
        return dict(row) if row else None

    def derivations(self) -> list[dict]:
        return [dict(row) for row in self.conn.execute(
            "SELECT * FROM structured_derivations "
            "ORDER BY derivation_id,definition_version").fetchall()]

    def create_snapshot(self, *, consumer: str, purpose: str, as_of: datetime,
                        items: list, metadata: dict | None = None) -> dict:
        """Persist immutable references to accepted observations, never runtime inputs."""
        persistent_items = []
        seen: set[tuple] = set()
        for item in items:
            if isinstance(item, dict):
                payload = item
            else:
                payload = item.model_dump(mode="json")
            if payload.get("input_mode", "persistent") == "runtime":
                continue
            observation_id = payload.get("observation_id", "")
            if not observation_id or self.observation(observation_id) is None:
                continue
            normalized = {
                "observation_id": observation_id,
                "selected_source": payload.get("selected_source") or
                                   payload.get("source_id", ""),
                "selection_reason": payload.get("selection_reason", "explicit_input"),
                "derivation_id": payload.get("derivation_id", ""),
                "derivation_version": payload.get("derivation_version", ""),
            }
            key = tuple(normalized.values())
            if key not in seen:
                seen.add(key)
                persistent_items.append(normalized)
        persistent_items.sort(key=lambda row: (
            row["observation_id"], row["derivation_id"], row["derivation_version"]))
        body = {
            "consumer": consumer, "purpose": purpose, "as_of": _stamp(as_of),
            "items": persistent_items, "metadata": metadata or {},
        }
        snapshot_id = hashlib.sha256(_json(body).encode()).hexdigest()[:24]
        created_at = _stamp()
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT OR IGNORE INTO structured_snapshots VALUES (?,?,?,?,?,?)",
                (snapshot_id, consumer, purpose, _stamp(as_of), created_at,
                 _json(metadata or {})))
            for ordinal, item in enumerate(persistent_items):
                self.conn.execute(
                    "INSERT OR IGNORE INTO structured_snapshot_items VALUES (?,?,?,?,?,?,?)",
                    (snapshot_id, ordinal, item["observation_id"],
                     item["selected_source"], item["selection_reason"],
                     item["derivation_id"], item["derivation_version"]))
        return self.snapshot(snapshot_id) or {}

    def snapshot(self, snapshot_id: str) -> dict | None:
        row = self.conn.execute(
            "SELECT * FROM structured_snapshots WHERE snapshot_id=?",
            (snapshot_id,)).fetchone()
        if row is None:
            return None
        result = dict(row)
        result["metadata"] = json.loads(result.pop("metadata_json") or "{}")
        result["items"] = [dict(item) for item in self.conn.execute(
            "SELECT * FROM structured_snapshot_items WHERE snapshot_id=? "
            "ORDER BY ordinal", (snapshot_id,)).fetchall()]
        return result

    def replay_snapshot(self, snapshot_id: str) -> dict | None:
        manifest = self.snapshot(snapshot_id)
        if manifest is None:
            return None
        rows = []
        derivations: dict[tuple[str, str], dict] = {}
        for item in manifest["items"]:
            observation = self.observation(item["observation_id"])
            if observation is not None:
                observation.update({
                    "selected_source": item["selected_source"],
                    "selection_reason": item["selection_reason"],
                    "derivation_id": item["derivation_id"],
                    "derivation_version": item["derivation_version"],
                })
                rows.append(observation)
            if item["derivation_id"]:
                key = (item["derivation_id"], item["derivation_version"])
                definition = self.derivation(*key)
                if definition:
                    derivations[key] = definition
        relation_ids = manifest.get("metadata", {}).get("relation_ids", [])
        relations = [relation for relation_id in relation_ids
                     if (relation := self.entity_relation(relation_id)) is not None]
        artifact_ids = sorted({row["artifact_id"] for row in rows} |
                              {row["artifact_id"] for row in relations if row.get("artifact_id")})
        artifacts = [artifact for artifact_id in artifact_ids
                     if (artifact := self.artifact(artifact_id)) is not None]
        return {**manifest, "rows": rows, "relations": relations, "artifacts": artifacts,
                "derivations": list(derivations.values())}

    def open_read_only(self) -> sqlite3.Connection:
        if self.path == ":memory:":
            raise RuntimeError("read-only SQL requires a file-backed structured database")
        conn = sqlite3.connect(f"file:{Path(self.path).resolve()}?mode=ro", uri=True)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA query_only=ON")
        return conn

    def legacy_measurements(self, *, source_id: str | None = None,
                            entity: str | None = None, as_of: datetime | None = None,
                            latest_only: bool = True, limit: int = 5000) -> list[dict]:
        if not (_table_exists(self.conn, "measurement_series") and
                _table_exists(self.conn, "measurement_points")):
            return []
        sql = ("SELECT p.*,s.source_id,s.series,s.label,s.entity,s.cadence "
               "FROM measurement_points p JOIN measurement_series s "
               "ON s.series_id=p.series_id WHERE 1=1")
        args: list = []
        if source_id:
            sql += " AND s.source_id=?"
            args.append(source_id)
        if entity:
            sql += " AND s.entity=?"
            args.append(entity.upper())
        cutoff = _stamp(as_of) if as_of else ""
        if cutoff:
            sql += " AND p.fetched_at<=? AND (p.published_at='' OR p.published_at<=?)"
            args.extend([cutoff, cutoff])
        if latest_only:
            sql += (" AND NOT EXISTS (SELECT 1 FROM measurement_points newer "
                    "WHERE newer.series_id=p.series_id AND newer.period=p.period "
                    "AND newer.fetched_at>p.fetched_at")
            if cutoff:
                sql += " AND newer.fetched_at<=?"
                args.append(cutoff)
            sql += ")"
        sql += " ORDER BY p.period,p.fetched_at LIMIT ?"
        args.append(limit)
        return [dict(row) for row in self.conn.execute(sql, args).fetchall()]

    def audit_legacy_measurements(self, *, at: datetime | None = None) -> dict:
        if not (_table_exists(self.conn, "measurement_series") and
                _table_exists(self.conn, "measurement_points")):
            result = {"series_count": 0, "point_count": 0, "missing_published_at": 0}
        else:
            result = {
                "series_count": self.conn.execute(
                    "SELECT count(*) FROM measurement_series").fetchone()[0],
                "point_count": self.conn.execute(
                    "SELECT count(*) FROM measurement_points").fetchone()[0],
                "missing_published_at": self.conn.execute(
                    "SELECT count(*) FROM measurement_points "
                    "WHERE published_at IS NULL OR published_at='' ").fetchone()[0],
            }
        audited_at = _stamp(at)
        audit_id = hashlib.sha1(
            f"{audited_at}|{_json(result)}".encode()).hexdigest()[:24]
        note = ("read-only audit; missing publication timestamps remain unknown and "
                "legacy values were not rewritten")
        with self._lock, self.conn:
            self.conn.execute(
                "INSERT INTO structured_legacy_audits VALUES (?,?,?,?,?,?)",
                (audit_id, audited_at, result["series_count"], result["point_count"],
                 result["missing_published_at"], note))
        return {"audit_id": audit_id, **result, "note": note}


def default_db_path() -> str:
    from ....config import REPO_ROOT

    return os.environ.get(
        "ATS_DATA_DB_PATH",
        os.environ.get(
            "ATS_STRUCTURED_DB_PATH",
            str(REPO_ROOT / "var" / "data.sqlite"),
        ),
    )


@lru_cache(maxsize=None)
def _repository(path: str, artifact_root: str) -> SQLiteStructuredRepository:
    return SQLiteStructuredRepository(path, artifact_root=artifact_root)


def get_repository() -> SQLiteStructuredRepository:
    return _repository(default_db_path(), str(default_artifact_root()))


def reset_repository_cache() -> None:
    _repository.cache_clear()
