"""Quality-gated, reversible runtime release overlays."""

from __future__ import annotations

from datetime import datetime, timezone
import os
from pathlib import Path
import tempfile

import yaml

from .catalog.structured import StructuredCatalog
from .products.reporting import build_quality_report
from .adapters.structured.registry import validate_source_registration


SAFE_INGESTION_STATES = {"succeeded", "no_change"}
# A source can be explicitly routed back to any governed read mode.  Publishing
# uses ``platform``; rollback must also support the checked-in baseline modes
# (legacy/shadow/fallback/off) without deleting persisted artifacts or vintages.
SOURCE_RELEASE_MODES = {"legacy", "shadow", "platform", "fallback", "off"}
CONSUMER_MODES = {"legacy", "shadow", "platform", "fallback", "off"}


def default_release_path() -> Path:
    from ..config import REPO_ROOT

    return Path(os.environ.get(
        "ATS_STRUCTURED_RELEASE_FILE",
        REPO_ROOT / "var" / "structured_data" / "releases.yaml"))


def load_release_overlay(path: str | Path | None = None) -> dict:
    target = Path(path) if path else default_release_path()
    if not target.exists():
        return {"version": 1, "sources": {}, "consumers": {},
                "product_pins": {}, "history": []}
    raw = yaml.safe_load(target.read_text(encoding="utf-8")) or {}
    if int(raw.get("version", 1)) != 1:
        raise ValueError(f"unsupported structured release overlay: {target}")
    return {"version": 1, "sources": dict(raw.get("sources") or {}),
            "consumers": dict(raw.get("consumers") or {}),
            "product_pins": dict(raw.get("product_pins") or {}),
            "history": list(raw.get("history") or [])}


def overlay_mode(kind: str, target_id: str, *, path: str | Path | None = None) -> str:
    plural = "sources" if kind == "source" else "consumers"
    value = load_release_overlay(path).get(plural, {}).get(target_id, "")
    return str(value).lower() if value else ""


def pinned_product_version(product_id: str, *, path: str | Path | None = None) -> str:
    """Return an explicit historical read pin, never an inferred fallback."""
    return str(load_release_overlay(path)['product_pins'].get(product_id) or '')


def _write_overlay(raw: dict, path: str | Path) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    body = yaml.safe_dump(raw, sort_keys=False, allow_unicode=True)
    with tempfile.NamedTemporaryFile(
            "w", encoding="utf-8", dir=target.parent, delete=False) as handle:
        handle.write(body)
        temporary = Path(handle.name)
    os.replace(temporary, target)


class ReleaseManager:
    def __init__(self, repository, *, catalog: StructuredCatalog | None = None,
                 path: str | Path | None = None):
        self.repository = repository
        self.catalog = catalog or StructuredCatalog.load()
        self.path = Path(path) if path else default_release_path()

    def check_source(self, source_id: str, *, mode: str = "platform") -> dict:
        checks: list[dict] = []

        def check(name: str, passed: bool, detail="") -> None:
            checks.append({"check": name, "passed": bool(passed), "detail": detail})

        if mode not in SOURCE_RELEASE_MODES:
            raise ValueError(f"invalid release mode: {mode}")
        registration = validate_source_registration(source_id, catalog=self.catalog)
        check("registration", registration["valid"], registration["reason_codes"])
        source = self.repository.source(source_id)
        check("repository_registration", source is not None, "source_not_bootstrapped")
        datasets = registration.get("datasets", [])
        health = next((row for row in self.repository.source_health()
                       if row["source_id"] == source_id), {})
        last_status = health.get("last_status") or "no_run"
        check("latest_ingestion", last_status in SAFE_INGESTION_STATES, last_status)
        for dataset_id in datasets:
                # A company-financial source is usable when the selected latest
                # report package passes the domain's data-only audit.  The generic
                # dataset report intentionally includes every historical source and
                # conflict (for example MRVL) and therefore is not an appropriate
                # gate for the configured AMZN/MSFT/KLAC/TSM acceptance package.
                if dataset_id == "company_financials":
                    from .financial_release import company_financial_release_check

                    package_check = company_financial_release_check(self.repository)
                    check("data_package:company_financials", package_check["ready"],
                          {"scope": package_check["scope"],
                           "entities": package_check["entities"]})
                    continue
                try:
                    report = build_quality_report(self.repository)
                except Exception as exc:
                    report = {"datasets": []}
                    check("quality_report", False, f"{type(exc).__name__}:{exc}")
                by_dataset = {row["dataset_id"]: row for row in report["datasets"]}
                quality = by_dataset.get(dataset_id)
                check(f"quality:{dataset_id}",
                      bool(quality and quality["overall_status"] == "passed"),
                      (quality or {}).get("overall_status", "missing_quality_report"))
        return {"kind": "source", "target_id": source_id, "requested_mode": mode,
                "current_overlay_mode": overlay_mode("source", source_id, path=self.path),
                "last_ingestion_status": last_status, "ready": all(
                    row["passed"] for row in checks), "checks": checks}

    def check_consumer(self, consumer: str, *, mode: str = "platform") -> dict:
        """Validate a reversible consumer-routing change without touching data."""
        if mode not in CONSUMER_MODES:
            raise ValueError(f"invalid consumer mode: {mode}")
        flags = dict((self.catalog.raw or {}).get("feature_flags") or {})
        registered = consumer in (flags.get("consumers") or {})
        approved = registered and str((flags.get("consumers") or {}).get(consumer)) == mode
        checks = [
            {"check": "consumer_registration", "passed": registered,
             "detail": "registered" if registered else "unknown_consumer"},
            {"check": "consumer_platform_approval", "passed": approved,
             "detail": ("consumer_approved_for_platform_in_checked_config" if approved
                        else "consumer_not_approved_for_platform_in_checked_config")},
        ]
        return {
            "kind": "consumer", "target_id": consumer, "requested_mode": mode,
            "current_overlay_mode": overlay_mode("consumer", consumer, path=self.path),
            "ready": all(row["passed"] for row in checks), "checks": checks,
        }

    def apply(self, check: dict, *, actor: str = "cli") -> dict:
        if not check.get("ready"):
            raise ValueError("release check failed; overlay was not changed")
        raw = load_release_overlay(self.path)
        if check["kind"] not in {"source", "consumer"}:
            raise ValueError(f"unsupported release kind: {check['kind']}")
        plural = "sources" if check["kind"] == "source" else "consumers"
        previous = raw[plural].get(check["target_id"], "")
        raw[plural][check["target_id"]] = check["requested_mode"]
        raw["history"].append({
            "at": datetime.now(timezone.utc).isoformat(), "actor": actor,
            "kind": check["kind"], "target_id": check["target_id"],
            "previous_mode": previous, "mode": check["requested_mode"],
            "action": "publish" if check["requested_mode"] == "platform" else "set_mode",
        })
        _write_overlay(raw, self.path)
        return {**check, "applied": True, "previous_mode": previous,
                "release_file": str(self.path)}

    def rollback(self, *, kind: str, target_id: str, mode: str = "legacy",
                 actor: str = "cli") -> dict:
        """Route one source/consumer back without deleting governed data."""
        if kind not in {"source", "consumer"}:
            raise ValueError(f"unsupported rollback kind: {kind}")
        allowed = SOURCE_RELEASE_MODES if kind == "source" else CONSUMER_MODES
        if mode not in allowed:
            raise ValueError(f"invalid {kind} rollback mode: {mode}")
        raw = load_release_overlay(self.path)
        plural = "sources" if kind == "source" else "consumers"
        previous = raw[plural].get(target_id, "")
        raw[plural][target_id] = mode
        raw["history"].append({
            "at": datetime.now(timezone.utc).isoformat(), "actor": actor,
            "kind": kind, "target_id": target_id,
            "previous_mode": previous, "mode": mode, "action": "rollback",
        })
        _write_overlay(raw, self.path)
        return {"kind": kind, "target_id": target_id, "mode": mode,
                "previous_mode": previous, "applied": True,
                "release_file": str(self.path)}

    def pin_factset_product(self, version_id: str, *, actor: str = "cli") -> dict:
        """Pin a released Index version; consumer checks still fail closed."""
        if not version_id.strip():
            raise ValueError('factset_product_version_required')
        releases = self.repository.release_manifests(
            dataset_id='sp500_earnings_insight', partition='index_core',
            passed_only=False, limit=10000)
        selected = next((row for row in releases if row['version_id'] == version_id), None)
        if selected is None or not selected['passed'] or selected['status'] != 'platform':
            raise ValueError('factset_product_version_not_published')
        raw = load_release_overlay(self.path)
        previous = raw['product_pins'].get('factset_earnings_insight', '')
        raw['product_pins']['factset_earnings_insight'] = version_id
        raw['history'].append({
            'at': datetime.now(timezone.utc).isoformat(), 'actor': actor,
            'kind': 'product', 'target_id': 'factset_earnings_insight',
            'previous_version': previous, 'version_id': version_id,
            'action': 'pin',
        })
        _write_overlay(raw, self.path)
        return {'product': 'factset_earnings_insight', 'version_id': version_id,
                'previous_version': previous, 'release_file': str(self.path)}

    def clear_factset_product_pin(self, *, actor: str = "cli") -> dict:
        raw = load_release_overlay(self.path)
        previous = raw['product_pins'].pop('factset_earnings_insight', '')
        raw['history'].append({
            'at': datetime.now(timezone.utc).isoformat(), 'actor': actor,
            'kind': 'product', 'target_id': 'factset_earnings_insight',
            'previous_version': previous, 'version_id': '',
            'action': 'unpin',
        })
        _write_overlay(raw, self.path)
        return {'product': 'factset_earnings_insight', 'version_id': '',
                'previous_version': previous, 'release_file': str(self.path)}
