"""PEAD earnings-event workflow (LangGraph) — 基本面事件模式 (Phase D).

    START → load → ┬ prep:  fetch → framework → narrative → expectations → signal_chain → persist_prep → END
                   └ score: fetch → actuals → scorecard → review → persist_score → END

Phase D (agent/fundamental-pead): the score branch produces a NON-EXECUTABLE
event review — direction / magnitude / confidence / rationale / falsifiable
conditions, published as a `FundamentalEventReview` projection. No risk engine,
no guardrails, no pre-trade checks, no quantities, no portfolio reads: the
action-and-size decision belongs to the chief and the risk officer inside the
approval chain.
"""

from __future__ import annotations

from ats.workflow.evaluation_clock import now as evaluation_now

import logging
from datetime import datetime, timezone

from langgraph.graph import END, START, StateGraph

from ..agents.pead import prep as prep_agents
from ..agents.pead import score as score_agents
from ..config import load_pead_config
from ..schemas.market import Ticker
from ..schemas.pead import (
    Actuals,
    ExpectationSet,
    FundamentalBackground,
    MarketSetup,
    PeadDossier,
    Scorecard,
    ScorecardLine,
)
from .pead_state import PeadState

log = logging.getLogger("ats.graph.pead")


def _now() -> datetime:
    return evaluation_now(timezone.utc)


def _published_event_date(package) -> str:
    """Prefer the accepted release date once score reads an event-bound package.

    ``prep_fetch`` legitimately records the *next* calendar event so option expiry can
    be selected before earnings.  A later score, however, is anchored to immutable
    documents for a completed event.  Carrying that future calendar date into the
    score dossier makes the report header and score ledger describe a different event
    from the release/filing/transcript they actually consumed.
    """
    for role in ("earnings_release", "regulatory_filing", "earnings_transcript"):
        item = next((doc for doc in package.documents if doc.role == role), None)
        if item is None or not item.published_at:
            continue
        try:
            return datetime.fromisoformat(item.published_at.replace("Z", "+00:00")).date().isoformat()
        except ValueError:
            continue
    return ""


# --------------------------------------------------------------------------- #
# Shared
# --------------------------------------------------------------------------- #
def load(state: PeadState) -> dict:
    cfg = load_pead_config(state.symbol)
    fiscal = state.fiscal_label or cfg.fiscal_label
    out: dict = {"config": cfg, "fiscal_label": fiscal}

    # Phase D: no portfolio read here. The event review never sizes positions,
    # so there is nothing a portfolio snapshot could be used for in this graph.

    if state.phase in ("score", "prep"):
        from ..memory import get_store

        prior = get_store().get_dossier(state.symbol, fiscal)
        if prior and prior.expectation_set:
            if state.phase == "score":
                out["expectation_set"] = prior.expectation_set
                out["market_setup"] = prior.market_setup
                # carry the prep-phase framework/chain into the score dossier so the
                # re-save doesn't drop them
                out["fundamental_background"] = prior.fundamental_background
                out["signal_chain"] = prior.signal_chain
                out["signal_chain_summary"] = prior.signal_chain_summary
                out["earnings_date"] = prior.earnings_date
            else:  # prep: carry the accumulated monitor narrative forward (don't reset to seed)
                out["prior_narrative"] = prior.expectation_set.narrative
    return out


def route(state: PeadState) -> str:
    return state.phase


# --------------------------------------------------------------------------- #
# PREP
# --------------------------------------------------------------------------- #
def prep_fetch(state: PeadState) -> dict:
    cfg = state.config
    out: dict = {}
    if not state.live_data:
        return {"fundamentals_text": "(offline)", "consensus": {}, "peer_rows": []}

    from ..agents.fundamental.inputs import governed_company_inputs

    governed = governed_company_inputs(state.symbol)
    if governed is not None:
        # Runtime price/options are not declared Fundamental inputs. Candidate
        # research consumes the persistent packet, never a hidden provider fetch.
        return {"fundamentals_text": governed["fundamentals_text"],
                "consensus": governed["consensus"], "peer_rows": [],
                "industry_context": governed["industry_context"],
                "input_refs": governed["input_refs"]}

    from ..data import consensus as consensus_src
    from ..data import earnings_calendar, industry, market_data
    from ..data import fundamentals as fund_src
    from ..data import options as opt_src
    from ..data import runup as runup_src

    fd = fund_src.fetch(state.symbol)
    out["fundamentals_text"] = fd.to_context()
    out["consensus"] = consensus_src.fetch(state.symbol)
    # Phase D (5.8): the sector-review / macro-review prep-block injection is GONE,
    # along with its `inject_prep` switches. Analysts' conclusions never enter the
    # fundamental context — only the static chain notes (shared facts) below.
    out["industry_context"] = industry.as_context(industry.fetch_notes())

    ru = runup_src.compute(state.symbol, cfg.sector_etf, cfg.benchmark)
    # Pass the earnings date so options picks the post-earnings expiration (the one
    # whose Expected Move / IV actually prices the event).
    target_earnings = earnings_calendar.next_earnings_date(state.symbol)
    out["earnings_date"] = target_earnings.isoformat() if target_earnings else ""
    opt = opt_src.fetch(state.symbol, target_earnings)
    out["market_setup"] = MarketSetup(
        symbol=state.symbol, as_of=state.as_of,
        pre_earnings_close=ru.get("pre_earnings_close"),
        run_up_vs_sector_pct=ru.get("run_up_vs_sector_pct"),
        run_up_vs_bench_pct=ru.get("run_up_vs_bench_pct"),
        dist_to_ath_pct=ru.get("dist_to_ath_pct"),
        expected_move_pct=opt.get("expected_move_pct"), atm_iv=opt.get("atm_iv"),
        iv_skew=opt.get("iv_skew"),
        notes=[f"options source: {opt.get('source')}"] if opt.get("source") else ["options: n/a"])

    rows = []
    for sc in cfg.signal_chain:
        snap = market_data.fetch_snapshot(Ticker(symbol=sc.symbol))
        chg = None
        if len(snap.history) >= 21:
            chg = round((snap.history[-1].close / snap.history[-21].close - 1) * 100, 2)
        row = {"symbol": sc.symbol, "role": sc.role, "price_chg_pct": chg,
               "earnings_date": earnings_calendar.next_earnings_date(sc.symbol),
               "reported": False}
        # Cross-ticker read-through: if this peer already reported and we scored it,
        # carry its fundamental read (guidance/capacity + verdict) into the target's
        # signal-chain analysis — e.g. TSM's CoWoS capacity feeding NVDA's supply thesis.
        row.update(_peer_report(sc.symbol))
        rows.append(row)
    out["peer_rows"] = rows
    return out


def _peer_report(symbol: str) -> dict:
    """Neutral-fact read-through for a signal-chain peer (Phase D task 5.10).

    跨标的信号只以中性事实进入：已报实际值取自 fundamentals 数据产品，近期事实
    变化取自该标的的 InformationBrief 投影。评审结论（decision_summary）、
    Scorecard 分档（band）与自由文本指引一律不读——那是另一个标的的基本面观点，
    而判断界线按取数入口执行：数据产品与 information_brief 投影 = 中性事实；
    dossier / fundamental_* 投影 = 观点。

    Returns {} fields when the peer has nothing reportable yet (leaves reported=False).
    """
    out: dict = {"reported": False}

    # 已报实际值：fundamentals 数据产品（结构化口径，非模型产出）。
    try:
        from ..data import fundamentals as fund_src

        fd = fund_src.fetch(symbol, consumer="pead_peer_report")
    except Exception as exc:  # noqa: BLE001 - 数据产品不可得时按未报处理
        log.info("peer report fundamentals unavailable for %s: %s", symbol, exc)
        fd = None
    if fd is not None and fd.statements and fd.statements.lines:
        out["reported"] = True
        out["peer_fiscal"] = fd.statements.period
        for line in fd.statements.lines:
            if line.label == "Diluted EPS" and line.value is not None:
                out["peer_reported_eps"] = line.value
                out["peer_reported_eps_yoy"] = line.yoy
            elif line.label == "Revenue" and line.value is not None:
                out["peer_reported_revenue"] = line.value
                out["peer_reported_revenue_yoy"] = line.yoy

    # 近期事实变化：该标的自己的 InformationBrief 投影（information_brief 角色，
    # 允许的跨角色读取）。只取事实列表，不取任何评审结论。
    try:
        from ..memory import get_store

        rows = get_store().task_projection_envelopes(
            agent_role="information_brief", scope_kind="entity", scope_id=symbol, limit=1)
        if rows:
            out["peer_brief_facts"] = list(
                (rows[0].get("payload") or {}).get("fact_changes") or [])[:5]
    except Exception as exc:  # noqa: BLE001 - 无简报时信号链照常输出价格与日期
        log.info("peer brief unavailable for %s: %s", symbol, exc)
    return out


def prep_framework(state: PeadState) -> dict:
    """Stable company framework (background / peers / catalysts / risks / valuation band)."""
    if not state.use_llm:
        return {}
    view = prep_agents.framework(state.config, state.fundamentals_text, state.consensus)
    fb = FundamentalBackground(
        background=view.background, peer_comparison=view.peer_comparison,
        watch_metrics=view.watch_metrics,
        catalysts=view.catalysts, key_risks=view.key_risks, valuation=view.valuation)
    return {"fundamental_background": fb}


def prep_narrative(state: PeadState) -> dict:
    cfg = state.config
    c = state.consensus or {}
    consensus_kwargs = _consensus_kwargs(c)
    if not state.use_llm:
        return {"expectation_set": ExpectationSet(
            symbol=state.symbol, fiscal_label=state.fiscal_label, as_of=state.as_of,
            narrative=state.prior_narrative or cfg.narrative_seed,
            **consensus_kwargs)}
    nv = prep_agents.narrative(cfg, state.fundamentals_text, state.consensus,
                               prior_narrative=state.prior_narrative,
                               industry_context=state.industry_context,
                               market_setup=state.market_setup)
    es = ExpectationSet(
        symbol=state.symbol, fiscal_label=state.fiscal_label, as_of=state.as_of,
        narrative=nv.narrative, focus_ranking=nv.focus_ranking, valuation=nv.valuation,
        **consensus_kwargs)
    return {"expectation_set": es}


def _consensus_kwargs(c: dict) -> dict:
    """Extract all consensus fields from the raw consensus dict for ExpectationSet."""
    rating_parts = []
    sb = c.get("rating_strong_buy", 0) or 0
    b = c.get("rating_buy", 0) or 0
    h = c.get("rating_hold", 0) or 0
    s = c.get("rating_sell", 0) or 0
    if sb or b or h or s:
        rating_parts = [f"强买{sb}", f"买{b}", f"持有{h}", f"卖{s}"]
    actions = []
    for up in (c.get("upgrades_downgrades") or [])[:3]:
        actions.append(f"{up.get('date','')} {up.get('firm','')} → {up.get('to_grade','')}")
    return {
        "consensus_eps": c.get("eps"),
        "consensus_eps_low": c.get("eps_low"),
        "consensus_eps_high": c.get("eps_high"),
        "consensus_revenue": c.get("revenue"),
        "consensus_revenue_low": c.get("revenue_low"),
        "consensus_revenue_high": c.get("revenue_high"),
        "consensus_target_price": c.get("target_mean"),
        "consensus_rating_summary": "/".join(rating_parts),
        "consensus_recent_actions": actions,
    }


def prep_expectations(state: PeadState) -> dict:
    if not state.use_llm:
        return {}
    from ..agents.pead.outputs import NarrativeView

    es = state.expectation_set
    nv = NarrativeView(narrative=es.narrative, focus_ranking=es.focus_ranking, valuation=es.valuation)
    es.expectations = prep_agents.expectations(state.config, nv, state.fundamentals_text,
                                               state.consensus)
    return {"expectation_set": es}


def prep_signal_chain(state: PeadState) -> dict:
    if not state.use_llm:
        return {"signal_chain": prep_agents._fallback_chain(state.peer_rows),
                "signal_chain_summary": ""}
    items, summary = prep_agents.signal_chain(state.config, state.peer_rows)
    return {"signal_chain": items, "signal_chain_summary": summary}


def prep_persist(state: PeadState) -> dict:
    from ..agents.pead import report as pead_report
    from ..memory import get_store

    store = get_store()
    # A prep run AFTER a score already exists — a post-hoc backfill, which until the
    # 2026-07-29 same-day-amc routing fix could never happen in normal operation —
    # must not silently discard that score. `load()`'s score branch already carries
    # prep fields forward for the opposite (score-after-prep) direction; this mirrors
    # it for prep-after-score, which was previously unhandled (found via KLAC:
    # backfilling prep wiped the already-persisted actuals/scorecard/decision_summary).
    prior = store.get_dossier(state.symbol, state.fiscal_label)
    already_scored = bool(prior and prior.actuals)
    dossier = PeadDossier(
        symbol=state.symbol, fiscal_label=state.fiscal_label,
        phase="score" if already_scored else "prep", updated_at=_now(),
        earnings_date=state.earnings_date,
        fundamental_background=state.fundamental_background,
        expectation_set=state.expectation_set, market_setup=state.market_setup,
        signal_chain=state.signal_chain, signal_chain_summary=state.signal_chain_summary,
        fundamentals_context=state.fundamentals_text or "",
        scorecard_dims=state.config.scorecard_dims,
        scorecard_weights={d.key: d.weight for d in state.config.scorecard_dims},
        long_threshold=state.config.long_threshold,
        run_up_warn_pct=state.config.run_up_warn_pct,
        actuals=prior.actuals if already_scored else None,
        scorecard=prior.scorecard if already_scored else None,
        decision_summary=(prior.decision_summary if already_scored else "") or "")
    store.save_dossier(dossier)
    path = pead_report.write_report(dossier)
    if path:
        print(f"   📝 {path}")
    return {}


# --------------------------------------------------------------------------- #
# SCORE
# --------------------------------------------------------------------------- #
def score_fetch(state: PeadState) -> dict:
    out: dict = {}
    from ..agents.fundamental.inputs import governed_company_inputs
    from ..data import fundamentals as fund_src
    from ..data import transcript as transcript_src

    governed = governed_company_inputs(state.symbol) if state.live_data else None
    if governed:
        out["input_refs"] = governed["input_refs"]
        if state.transcript_source:
            from ..workflow.cutover_routing import RouteUnavailable

            raise RouteUnavailable("governed event input requires an admitted document version")
    out["fundamentals_text"] = (governed["fundamentals_text"] if governed else
                                fund_src.fetch(state.symbol).to_context()
                                if state.live_data else "(offline)")
    # An explicit operator-supplied transcript remains authoritative.  Otherwise
    # platform/fallback modes read the event-bound immutable package first; they do
    # not trigger a new SEC, transcript, RSS, or web fetch inside a scoring run.
    # Legacy/shadow retain the established discovery path until PEAD's own shadow
    # reconciliation is completed in task 10.1.
    package = None
    package_mode = "legacy"
    if state.live_data and not state.transcript_source:
        from ..data.structured import read_mode

        package_mode = "platform" if governed else read_mode("pead_graph")
        if package_mode in {"platform", "fallback", "shadow"}:
            from ..data.products.unstructured import platform_earnings_document_package

            package = platform_earnings_document_package(
                entity=state.symbol, period=state.fiscal_label,
                **({"as_of": governed["as_of"]} if governed else {}))

    if governed and not state.transcript_source and (package is None or not package.scoreable):
        from ..workflow.cutover_routing import RouteUnavailable

        raise RouteUnavailable("governed earnings documents unavailable; provider fallback forbidden")

    use_package = bool(package and package.scoreable and package_mode in {"platform", "fallback"})
    if use_package:
        transcript = package.transcript
        text = transcript.text if transcript else ""
        src = (f"platform:{transcript.source}:{transcript.version_id}"
               if transcript else "platform:no_transcript")
        out["documents_text"] = package.official_text()
        out["document_lineage"] = [item.lineage for item in package.documents]
        if governed:
            from ..workflow.consumer_reads import record_read

            doc_refs = [f"{item.document_id}@{item.version_id}" for item in package.documents]
            out["input_refs"] = out.get("input_refs", []) + doc_refs
            record_read("fundamental", "platform_earnings_document_package", refs=doc_refs)
        if event_date := _published_event_date(package):
            out["earnings_date"] = event_date
    elif state.transcript_source or state.live_data:
        text, src = transcript_src.fetch(state.symbol, state.fiscal_label,
                                         state.transcript_source,
                                         company_name=state.config.company_name)
    else:
        text, src = "", "offline"

    # Period guard: refuse to score a transcript that reports a DIFFERENT quarter
    # than the target (a stale/wrong-quarter transcript scored against this
    # quarter's expectations yields a spurious miss). Confirmed mismatch aborts;
    # undetectable period proceeds with a flagged note.
    if text:
        from ..data import fiscal

        ok, why = fiscal.verify_transcript(state.fiscal_label, text, src)
        if not ok:
            raise ValueError(
                f"[period-guard] {state.symbol} score 已中止：{why}。transcript source={src}。"
                f" 请用正确季度的 --transcript 重跑，或等待目标季 transcript 就绪（宁可不打分也不错季）。")
        out["transcript_period_note"] = why

        # Strip page furniture AFTER the period guard: verify_transcript's body
        # fallback reads text[:2500], so trimming first would move that window off
        # the header where the quarter is usually stated.
        text, strip_note = transcript_src.extract_body(text, src)
        if strip_note:
            out["transcript_period_note"] = f"{why}；{strip_note}"

        # Body-quality guard: a scraper may hand back nav chrome / a truncated
        # stub (right URL, wrong content) — that silently zeroes the guidance /
        # backlog / tone dims. Refuse rather than emit a misleading partial score.
        ok_body, why_body = transcript_src.looks_like_transcript(text)
        if not ok_body:
            raise ValueError(
                f"[transcript-guard] {state.symbol} score 已中止：{why_body}。transcript source={src}。"
                f" 请换完整 transcript 源（investing.com/fool.com）用 --transcript 重跑，"
                f"或把全文放到 var/transcripts/（宁可不打分也不喂残缺正文）。")

    out["transcript_text"] = text
    out["transcript_resolved_source"] = src
    if not text:
        log.info("%s: 无纪要，按 v1（仅财报稿/8-K）打分，权重将重新归一，"
                 "评审置信度下调", state.symbol)

    # Legacy/shadow still use the compatibility collector.  Platform/fallback already
    # has the selected immutable release/filing versions above.
    if state.live_data and not use_package:
        from ..data import documents

        docs = documents.gather(
            state.symbol, period=state.fiscal_label, report_date=state.earnings_date)
        out["documents_text"] = "\n\n".join(f"### {label}\n{txt[:25000]}" for label, txt in docs)

    # Minimum-evidence guard: with neither a transcript nor an earnings release there
    # is nothing this quarter to score. yfinance's quarterly statements lag the print
    # by days, so scoring off them alone would grade the quarter against last
    # quarter's numbers — a fabricated surprise. Refuse instead.
    if state.live_data and not text and not out.get("documents_text", "").strip():
        raise ValueError(
            f"[evidence-guard] {state.symbol} score 已中止：既无电话会纪要，也没取到"
            f"财报稿/8-K。仅凭滞后的季度报表打分会把上一季的数字当本季，宁可不打分。"
            f" 待纪要或 8-K 就位后重试（下一个打分窗口会自动重试）。")

    # Need run-up for the decision; recompute if the prep dossier lacked it.
    if state.market_setup is None and state.live_data and governed is None:
        from ..data import runup as runup_src

        ru = runup_src.compute(state.symbol, state.config.sector_etf, state.config.benchmark)
        out["market_setup"] = MarketSetup(symbol=state.symbol, as_of=state.as_of,
                                          run_up_vs_sector_pct=ru.get("run_up_vs_sector_pct"))
    return out


def score_actuals(state: PeadState) -> dict:
    if not state.use_llm:
        return {"actuals": Actuals(symbol=state.symbol, fiscal_label=state.fiscal_label,
                                   as_of=state.as_of, guidance="(no-llm)")}
    from ..config import load_pead_global

    score_cfg = load_pead_global().get("score", {})
    actuals = score_agents.extract_actuals(
        state.config, state.expectation_set, state.transcript_text,
        state.fundamentals_text, state.as_of, state.transcript_resolved_source,
        documents_text=state.documents_text,
        transcript_chars=score_cfg.get("transcript_chars", 120_000),
        documents_chars=score_cfg.get("documents_chars", 40_000))
    return {"actuals": actuals}


def score_scorecard(state: PeadState) -> dict:
    if not state.use_llm:
        cfg = state.config
        lines = [ScorecardLine(dim_key=d.key, label=d.label, weight=d.weight, score=0.0,
                               weighted=0.0, note="(no-llm)") for d in cfg.scorecard_dims]
        return {"scorecard": Scorecard(symbol=state.symbol, fiscal_label=state.fiscal_label,
                                       as_of=state.as_of, lines=lines, total=0.0,
                                       threshold=cfg.long_threshold,
                                       band=score_agents._band(0.0, cfg.long_threshold))}
    return {"scorecard": score_agents.score(
        state.config, state.expectation_set, state.actuals, state.as_of,
        has_transcript=bool((state.transcript_text or "").strip()))}


def score_review(state: PeadState) -> dict:
    """Event review, NOT a decision (Phase D tasks 5.6/5.7).

    The score branch no longer touches the risk engine, guardrail review or the
    pre-trade gate, and no longer converts recommendations into trade decisions.
    The fundamental event review is a non-executable view (direction, magnitude,
    confidence, rationale, falsifiable conditions). Risk conclusions live only
    in the risk officer's deterministic review inside the approval chain.
    """
    from ..agents.fundamental import event as fundamental_event

    run_up = state.market_setup.run_up_vs_sector_pct if state.market_setup else None
    view = score_agents.event_view(state.config, state.scorecard, run_up)
    # 三类差异：对冻结基线（以 prep 产出的 expectation_set 为当期基线）、
    # Consensus 与市场隐含预期分别计算，分列保留、不取平均。
    from ..memory import get_store

    frozen = fundamental_event.load_frozen_baseline(
        get_store(), symbol=state.symbol, fiscal_label=state.fiscal_label)
    tri = fundamental_event.compute_tri_diffs(
        frozen_baseline=frozen, expectation_set=state.expectation_set,
        actuals=state.actuals, market_setup=state.market_setup)
    return {"event_view": view, "tri_diffs": tri,
            "decision_band": state.scorecard.band if state.scorecard else ""}


def score_persist(state: PeadState) -> dict:
    """Persist the dossier + publish the FundamentalEventReview projection (5.9)."""
    from ..agents.fundamental import event as fundamental_event
    from ..agents.pead import report as pead_report
    from ..memory import get_store

    view = state.event_view or {}
    direction = int(view.get("direction", 0))
    summary_parts = [
        f"{state.decision_band}",
        "事件评审（非可执行，方向供 Chief 综合裁决）: "
        f"{fundamental_event.direction_word(direction)}",
    ]
    if view.get("magnitude") is not None:
        summary_parts.append(f"幅度 {view.get('magnitude'):+.2f}")
    if view.get("confidence") is not None:
        summary_parts.append(f"信心 {view.get('confidence'):.2f}")
    tri = state.tri_diffs or {}
    if tri.get("note"):
        summary_parts.append(tri["note"])
    summary = " | ".join(p for p in summary_parts if p)
    dossier = PeadDossier(
        symbol=state.symbol, fiscal_label=state.fiscal_label, phase="score", updated_at=_now(),
        earnings_date=state.earnings_date,
        fundamental_background=state.fundamental_background,
        expectation_set=state.expectation_set, market_setup=state.market_setup,
        signal_chain=state.signal_chain, signal_chain_summary=state.signal_chain_summary,
        fundamentals_context=state.fundamentals_text or "",
        scorecard_dims=state.config.scorecard_dims,
        scorecard_weights={d.key: d.weight for d in state.config.scorecard_dims},
        long_threshold=state.config.long_threshold,
        run_up_warn_pct=state.config.run_up_warn_pct,
        actuals=state.actuals, scorecard=state.scorecard,
        decision_summary=summary)
    store = get_store()
    store.save_dossier(dossier)

    # Publish the non-executable event review as a projection. Late materials
    # (e.g. a transcript arriving days later) produce a NEW version; earlier
    # versions stay queryable (5.5).
    try:
        payload = fundamental_event.build_event_review_payload(
            symbol=state.symbol, period=state.fiscal_label, event="earnings",
            scorecard=state.scorecard, event_view=view, tri_diffs=tri,
            actuals=state.actuals,
            narrative=state.expectation_set.narrative if state.expectation_set else "")
        fundamental_event.publish_event_review(store, payload, input_refs=state.input_refs)
    except Exception as exc:  # noqa: BLE001 - dossier 已落库，投影失败显式留痕
        log.warning("event review projection failed for %s: %s", state.symbol, exc)

    # Ledger the run. This — not dossier.updated_at, which the daily monitor bumps —
    # is what tells the score windows "already done", so a print whose session is
    # unknown can be attempted in both daily windows without being scored twice.
    try:
        has_tx = bool((state.transcript_text or "").strip())
        store.record_score_run(
            symbol=state.symbol, fiscal_label=state.fiscal_label,
            version=store.next_score_version(state.symbol, state.fiscal_label),
            earnings_date=state.earnings_date, has_transcript=has_tx,
            transcript_source=state.transcript_resolved_source or "",
            total=state.scorecard.total if state.scorecard else None,
            band=state.decision_band or "", decision_summary=summary)
    except Exception as exc:  # noqa: BLE001 - the score itself is already persisted
        log.warning("score-run ledger write failed for %s: %s", state.symbol, exc)

    pead_report.write_report(dossier)
    return {"event_summary": {
        "direction": direction,
        "magnitude": view.get("magnitude"),
        "confidence": view.get("confidence"),
        "band": state.decision_band,
        "directions_agree": tri.get("directions_agree"),
    }}


# --------------------------------------------------------------------------- #
# Build
# --------------------------------------------------------------------------- #
def build_pead_graph(checkpointer=None):
    g = StateGraph(PeadState)
    for name, fn in [
        ("load", load),
        ("prep_fetch", prep_fetch), ("prep_framework", prep_framework),
        ("prep_narrative", prep_narrative),
        ("prep_expectations", prep_expectations), ("prep_signal_chain", prep_signal_chain),
        ("prep_persist", prep_persist),
        ("score_fetch", score_fetch), ("score_actuals", score_actuals),
        ("score_scorecard", score_scorecard), ("score_review", score_review),
        ("score_persist", score_persist),
    ]:
        g.add_node(name, fn)

    g.add_edge(START, "load")
    g.add_conditional_edges("load", route, {"prep": "prep_fetch", "score": "score_fetch"})

    g.add_edge("prep_fetch", "prep_framework")
    g.add_edge("prep_framework", "prep_narrative")
    g.add_edge("prep_narrative", "prep_expectations")
    g.add_edge("prep_expectations", "prep_signal_chain")
    g.add_edge("prep_signal_chain", "prep_persist")
    g.add_edge("prep_persist", END)

    g.add_edge("score_fetch", "score_actuals")
    g.add_edge("score_actuals", "score_scorecard")
    g.add_edge("score_scorecard", "score_review")
    g.add_edge("score_review", "score_persist")
    g.add_edge("score_persist", END)

    return g.compile(checkpointer=checkpointer)
