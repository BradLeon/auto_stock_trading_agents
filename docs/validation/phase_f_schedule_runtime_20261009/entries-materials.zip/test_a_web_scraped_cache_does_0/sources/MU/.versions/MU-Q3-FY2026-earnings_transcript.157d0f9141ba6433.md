---
symbol: MU
period: Q3 FY2026
doc_type: earnings_transcript
document_key: Q3 FY2026
source: defeatbeta
source_url: ''
fetched_at: '2026-10-09T01:04:56+00:00'
sha256: 157d0f9141ba64331331515b58ebca536e07ddc02944d5ea927e3cc9e12ba225
chars: 2630
external_id: defeatbeta:MU:2026-06-24
title: MU Q3 FY2026 earnings call transcript
published_at: '2026-06-24'
related_entities: MU
completeness: full
truncation_reason: ''
carrier_format: structured_text
mime_source: ''
---

## Prepared Remarks

**Operator:** Welcome to the Micron Q3 2026 earnings call. Welcome to the Micron Q3 2026 earnings call. Welcome to the Micron Q3 2026 earnings call. Welcome to the Micron Q3 2026 earnings call. Welcome to the Micron Q3 2026 earnings call. Welcome to the Micron Q3 2026 earnings call. Welcome to the Micron Q3 2026 earnings call. Welcome to the Micron Q3 2026 earnings call.

**Chief Executive Officer:** These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks. These are our prepared remarks.

**Chief Financial Officer:** Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved. Revenue and margin improved.

## Questions and Answers

**Operator:** We will now begin the question-and-answer session. We will now begin the question-and-answer session. We will now begin the question-and-answer session. We will now begin the question-and-answer session. We will now begin the question-and-answer session. We will now begin the question-and-answer session. We will now begin the question-and-answer session. We will now begin the question-and-answer session.

**Analyst:** Could you discuss AI demand and capacity? Could you discuss AI demand and capacity? Could you discuss AI demand and capacity? Could you discuss AI demand and capacity? Could you discuss AI demand and capacity? Could you discuss AI demand and capacity? Could you discuss AI demand and capacity? Could you discuss AI demand and capacity?

**Chief Executive Officer:** AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust. AI demand remains robust.

**Operator:** Thank you. This concludes the call. Thank you. This concludes the call. Thank you. This concludes the call. Thank you. This concludes the call. Thank you. This concludes the call. Thank you. This concludes the call. Thank you. This concludes the call. Thank you. This concludes the call.